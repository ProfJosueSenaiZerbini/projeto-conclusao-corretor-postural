import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import mongoose, { Schema, Document, model } from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt, { JwtPayload } from 'jsonwebtoken';
import cors from 'cors';

const app = express();

// ─── CORS ────────────────────────────────────────────────────────────────────
const allowedOrigins = process.env.FRONTEND_URL
  ? process.env.FRONTEND_URL.split(',').map((o) => o.trim())
  : ['http://localhost:5173', 'http://localhost:4173'];

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV !== 'production') {
        callback(null, true);
      } else {
        callback(new Error(`CORS: origem '${origin}' não permitida`));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

app.use(express.json({ limit: '1mb' }));

// ─── DATABASE ─────────────────────────────────────────────────────────────────
const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
  console.error('❌  MONGO_URI não definida no .env');
  process.exit(1);
}

mongoose
  .connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(() => console.log('✅  MongoDB conectado'))
  .catch((err: Error) => {
    console.error('❌  Falha ao conectar no MongoDB:', err.message);
    process.exit(1);
  });

// ─── USER MODEL ───────────────────────────────────────────────────────────────
interface IUser extends Document {
  name: string;
  email: string;
  passwordHash: string;
  createdAt: Date;
  updatedAt: Date;
}

const userSchema = new Schema<IUser>(
  {
    name:         { type: String, required: true, trim: true },
    email:        { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
  },
  { timestamps: true }
);

userSchema.index({ email: 1 });

const User = model<IUser>('User', userSchema);

// ─── JWT ──────────────────────────────────────────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET ?? '';
if (JWT_SECRET.length < 32) {
  console.error('❌  JWT_SECRET ausente ou muito curta (mín. 32 chars). Defina no .env');
  process.exit(1);
}

interface TokenPayload {
  id: string;
  email: string;
  name: string;
}

function createToken(user: IUser): string {
  const payload: TokenPayload = {
    id:    String(user._id),
    email: user.email,
    name:  user.name,
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d', algorithm: 'HS256' });
}

function buildUserDTO(user: IUser) {
  return {
    id:        String(user._id),
    name:      user.name,
    email:     user.email,
    createdAt: user.createdAt.toISOString(),
  };
}

// ─── AUTH MIDDLEWARE ──────────────────────────────────────────────────────────
interface AuthRequest extends Request {
  tokenPayload?: TokenPayload;
}

function requireAuth(req: AuthRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Token de autenticação ausente.' });
    return;
  }
  try {
    req.tokenPayload = jwt.verify(header.slice(7), JWT_SECRET) as TokenPayload;
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido ou expirado. Faça login novamente.' });
  }
}

// ─── ROTAS ────────────────────────────────────────────────────────────────────

/**
 * POST /api/auth/register
 * Body: { name, email, password }
 * Cria uma conta nova com senha criptografada via bcrypt.
 */
app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body ?? {};

    if (!name?.trim() || !email?.trim() || !password) {
      res.status(400).json({ error: 'Preencha todos os campos.' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'E-mail inválido.' });
      return;
    }
    if (String(password).length < 6) {
      res.status(400).json({ error: 'Senha deve ter pelo menos 6 caracteres.' });
      return;
    }
    if (String(name).trim().length < 2) {
      res.status(400).json({ error: 'Nome muito curto.' });
      return;
    }

    const exists = await User.exists({ email: String(email).toLowerCase().trim() });
    if (exists) {
      res.status(409).json({ error: 'E-mail já cadastrado. Faça login.' });
      return;
    }

    // Hash da senha (custo 12 = bom equilíbrio segurança/performance)
    const passwordHash = await bcrypt.hash(String(password), 12);

    const user = await User.create({
      name:  String(name).trim(),
      email: String(email).toLowerCase().trim(),
      passwordHash,
    });

    const token = createToken(user);
    res.status(201).json({ token, user: buildUserDTO(user) });
  } catch (err) {
    console.error('Erro em POST /api/auth/register:', err);
    res.status(500).json({ error: 'Erro interno. Tente novamente.' });
  }
});

/**
 * POST /api/auth/login
 * Body: { email, password }
 * Valida as credenciais e retorna um JWT.
 */
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body ?? {};

    if (!email?.trim() || !password) {
      res.status(400).json({ error: 'Preencha e-mail e senha.' });
      return;
    }

    // Busca incluindo passwordHash (excluído por padrão no schema)
    const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+passwordHash');
    if (!user) {
      // Mensagem genérica previne enumeração de e-mails
      res.status(401).json({ error: 'E-mail ou senha incorretos.' });
      return;
    }

    const valid = await bcrypt.compare(String(password), user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: 'E-mail ou senha incorretos.' });
      return;
    }

    const token = createToken(user);
    res.json({ token, user: buildUserDTO(user) });
  } catch (err) {
    console.error('Erro em POST /api/auth/login:', err);
    res.status(500).json({ error: 'Erro interno. Tente novamente.' });
  }
});

/**
 * POST /api/auth/reset-password
 * Body: { email }
 * Simula envio de e-mail de recuperação (integre com SendGrid/Nodemailer).
 */
app.post('/api/auth/reset-password', async (req: Request, res: Response) => {
  try {
    const { email } = req.body ?? {};
    if (!email?.trim()) {
      res.status(400).json({ error: 'Informe o e-mail.' });
      return;
    }

    const user = await User.findOne({ email: String(email).toLowerCase().trim() });

    // Resposta idêntica para não revelar se o e-mail existe (segurança)
    const message = 'Se o e-mail estiver cadastrado, você receberá as instruções em breve.';

    if (user) {
      // TODO: integrar provedor de e-mail (SendGrid, Nodemailer, AWS SES...)
      console.log(`[reset-password] Solicitação para: ${user.email}`);
    }

    res.json({ message });
  } catch (err) {
    console.error('Erro em POST /api/auth/reset-password:', err);
    res.status(500).json({ error: 'Erro interno.' });
  }
});

/**
 * GET /api/auth/me
 * Header: Authorization: Bearer <token>
 * Retorna dados do usuário autenticado.
 */
app.get('/api/auth/me', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.tokenPayload!.id);
    if (!user) {
      res.status(404).json({ error: 'Usuário não encontrado.' });
      return;
    }
    res.json({ user: buildUserDTO(user) });
  } catch (err) {
    console.error('Erro em GET /api/auth/me:', err);
    res.status(500).json({ error: 'Erro interno.' });
  }
});

/** GET /api/health — verificação de status */
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status:    'ok',
    timestamp: new Date().toISOString(),
    mongodb:   mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
  });
});

// ─── 404 ──────────────────────────────────────────────────────────────────────
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: `Rota '${req.method} ${req.path}' não encontrada.` });
});

// ─── GLOBAL ERROR ─────────────────────────────────────────────────────────────
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Erro não tratado:', err.message);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

// ─── START ────────────────────────────────────────────────────────────────────
const PORT = Number(process.env.PORT) || 3001;
app.listen(PORT, () => {
  console.log(`\n🚀  PostureCare API → http://localhost:${PORT}`);
  console.log(`\n📋  Endpoints:`);
  console.log(`    POST  /api/auth/register`);
  console.log(`    POST  /api/auth/login`);
  console.log(`    POST  /api/auth/reset-password`);
  console.log(`    GET   /api/auth/me        (requer Bearer token)`);
  console.log(`    GET   /api/health\n`);
});
