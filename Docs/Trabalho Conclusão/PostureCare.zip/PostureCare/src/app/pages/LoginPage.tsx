import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlignVerticalJustifyCenter, ArrowRight, CheckCircle2,
  Eye, EyeOff, Loader2, Lock, Mail, Server, User, WifiOff,
} from 'lucide-react';
import { Card, CardContent } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Badge } from '@/app/components/ui/badge';
import { useAuth } from '../components/auth/AuthContext';
import { toast } from 'sonner';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, register, sendPasswordReset, usingApi } = useAuth();

  const [tab, setTab]               = useState<'login' | 'register'>('login');
  const [showForgot, setShowForgot]  = useState(false);
  const [isLoading, setIsLoading]    = useState(false);
  const [showPassword, setShowPass]  = useState(false);
  const [forgotSent, setForgotSent]  = useState(false);

  const [loginForm, setLogin]   = useState({ email: '', password: '' });
  const [regForm, setReg]       = useState({ name: '', email: '', password: '', confirm: '' });
  const [forgotEmail, setForgotEmail] = useState('');

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const result = await login(loginForm.email, loginForm.password);
    setIsLoading(false);
    if (result.success) {
      toast.success('Bem-vindo de volta!');
      navigate('/dashboard');
    } else {
      toast.error(result.error ?? 'Erro ao fazer login.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (regForm.password !== regForm.confirm) {
      toast.error('As senhas não coincidem.');
      return;
    }
    setIsLoading(true);
    const result = await register(regForm.email, regForm.password, regForm.name);
    setIsLoading(false);
    if (result.success) {
      toast.success('Conta criada! Bem-vindo ao PostureCare!');
      navigate('/dashboard');
    } else {
      toast.error(result.error ?? 'Erro ao criar conta.');
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const result = await sendPasswordReset(forgotEmail);
    setIsLoading(false);
    if (result.success) {
      setForgotSent(true);
    } else {
      toast.error(result.error ?? 'Erro ao enviar e-mail.');
    }
  };

  // ── UI ─────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 220 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-secondary mb-4 shadow-xl shadow-primary/25"
          >
            <AlignVerticalJustifyCenter className="w-8 h-8 text-white" />
          </motion.div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            PostureCare
          </h1>
          <p className="text-muted-foreground mt-2 text-sm">Sua saúde postural em primeiro lugar</p>

          {/* Indicador de modo de autenticação */}
          <div className="flex justify-center mt-3">
            <Badge
              variant="outline"
              className={`text-xs gap-1.5 ${
                usingApi
                  ? 'border-green-400 text-green-700 bg-green-50'
                  : 'border-amber-400 text-amber-700 bg-amber-50'
              }`}
            >
              {usingApi ? (
                <><Server className="w-3 h-3" /> API conectada</>
              ) : (
                <><WifiOff className="w-3 h-3" /> Modo offline — dados locais</>
              )}
            </Badge>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {showForgot ? (
            <motion.div
              key="forgot"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-none shadow-2xl">
                <CardContent className="p-8">
                  {forgotSent ? (
                    <div className="text-center py-4">
                      <CheckCircle2 className="w-14 h-14 text-green-500 mx-auto mb-4" />
                      <h3 className="text-xl font-bold mb-2">E-mail enviado!</h3>
                      <p className="text-muted-foreground text-sm mb-6">
                        {usingApi
                          ? 'Verifique sua caixa de entrada e siga as instruções para recuperar sua senha.'
                          : 'No modo offline, a recuperação de senha não envia e-mail real.'}
                      </p>
                      <Button
                        className="w-full"
                        onClick={() => { setShowForgot(false); setForgotSent(false); setForgotEmail(''); }}
                      >
                        Voltar ao login
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleForgot} className="space-y-4">
                      <div className="mb-6">
                        <h3 className="text-xl font-bold mb-1">Recuperar senha</h3>
                        <p className="text-muted-foreground text-sm">
                          Informe seu e-mail para receber as instruções de recuperação.
                        </p>
                      </div>
                      <div>
                        <Label htmlFor="forgot-email">E-mail</Label>
                        <div className="relative mt-1.5">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            id="forgot-email"
                            type="email"
                            placeholder="seu@email.com"
                            className="pl-9"
                            value={forgotEmail}
                            onChange={e => setForgotEmail(e.target.value)}
                            required
                          />
                        </div>
                      </div>
                      <Button type="submit" className="w-full h-11" disabled={isLoading}>
                        {isLoading
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : 'Enviar link de recuperação'}
                      </Button>
                      <Button type="button" variant="ghost" className="w-full" onClick={() => setShowForgot(false)}>
                        Voltar ao login
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              key="auth"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <Card className="border-none shadow-2xl">
                <CardContent className="p-8">
                  <Tabs value={tab} onValueChange={v => setTab(v as 'login' | 'register')}>
                    <TabsList className="grid w-full grid-cols-2 mb-6">
                      <TabsTrigger value="login">Entrar</TabsTrigger>
                      <TabsTrigger value="register">Criar conta</TabsTrigger>
                    </TabsList>

                    {/* ── LOGIN ─────────────────────────────────────────── */}
                    <TabsContent value="login">
                      <form onSubmit={handleLogin} className="space-y-4">
                        <div>
                          <Label htmlFor="email">E-mail</Label>
                          <div className="relative mt-1.5">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="email"
                              type="email"
                              placeholder="seu@email.com"
                              className="pl-9"
                              value={loginForm.email}
                              onChange={e => setLogin(f => ({ ...f, email: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <Label htmlFor="password">Senha</Label>
                            <button
                              type="button"
                              onClick={() => setShowForgot(true)}
                              className="text-xs text-primary hover:underline"
                            >
                              Esqueceu a senha?
                            </button>
                          </div>
                          <div className="relative mt-1.5">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="password"
                              type={showPassword ? 'text' : 'password'}
                              placeholder="••••••••"
                              className="pl-9 pr-10"
                              value={loginForm.password}
                              onChange={e => setLogin(f => ({ ...f, password: e.target.value }))}
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowPass(s => !s)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </div>

                        <Button type="submit" className="w-full h-11 mt-2" disabled={isLoading}>
                          {isLoading
                            ? <Loader2 className="w-4 h-4 animate-spin" />
                            : <><span>Entrar</span><ArrowRight className="w-4 h-4 ml-2" /></>}
                        </Button>

                        {/* Separador */}
                        <div className="relative my-4">
                          <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-border" />
                          </div>
                          <div className="relative flex justify-center text-xs uppercase">
                            <span className="bg-card px-2 text-muted-foreground">Ou</span>
                          </div>
                        </div>

                        {/* Botão Google — desabilitado até integração OAuth real */}
                        <div>
                          <Button
                            type="button"
                            variant="outline"
                            className="w-full h-11 opacity-60 cursor-not-allowed"
                            disabled
                            aria-label="Login com Google indisponível"
                          >
                            <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" aria-hidden>
                              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                            </svg>
                            Continuar com Google
                          </Button>
                          <p className="text-center text-xs text-muted-foreground mt-2">
                            Login social disponível após configurar OAuth no backend
                          </p>
                        </div>
                      </form>
                    </TabsContent>

                    {/* ── REGISTER ──────────────────────────────────────── */}
                    <TabsContent value="register">
                      <form onSubmit={handleRegister} className="space-y-4">
                        <div>
                          <Label htmlFor="reg-name">Nome completo</Label>
                          <div className="relative mt-1.5">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="reg-name"
                              placeholder="Seu nome"
                              className="pl-9"
                              value={regForm.name}
                              onChange={e => setReg(f => ({ ...f, name: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="reg-email">E-mail</Label>
                          <div className="relative mt-1.5">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="reg-email"
                              type="email"
                              placeholder="seu@email.com"
                              className="pl-9"
                              value={regForm.email}
                              onChange={e => setReg(f => ({ ...f, email: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="reg-password">Senha</Label>
                          <div className="relative mt-1.5">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="reg-password"
                              type={showPassword ? 'text' : 'password'}
                              placeholder="Mínimo 6 caracteres"
                              className="pl-9 pr-10"
                              value={regForm.password}
                              onChange={e => setReg(f => ({ ...f, password: e.target.value }))}
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowPass(s => !s)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="reg-confirm">Confirmar senha</Label>
                          <div className="relative mt-1.5">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              id="reg-confirm"
                              type={showPassword ? 'text' : 'password'}
                              placeholder="Repita a senha"
                              className="pl-9"
                              value={regForm.confirm}
                              onChange={e => setReg(f => ({ ...f, confirm: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <Button type="submit" className="w-full h-11 mt-2" disabled={isLoading}>
                          {isLoading
                            ? <Loader2 className="w-4 h-4 animate-spin" />
                            : <><span>Criar minha conta</span><ArrowRight className="w-4 h-4 ml-2" /></>}
                        </Button>

                        {usingApi && (
                          <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1.5">
                            <Server className="w-3 h-3 text-green-600" />
                            Dados salvos com segurança no MongoDB
                          </p>
                        )}
                      </form>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <p className="text-center text-xs text-muted-foreground mt-4">
          Ao continuar, você concorda com os Termos de Uso e Política de Privacidade
        </p>
      </motion.div>
    </div>
  );
}
