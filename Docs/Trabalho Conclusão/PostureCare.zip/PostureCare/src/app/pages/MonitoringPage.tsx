import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Bell, Clock, Pause, Play, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { useAppData } from '../components/AppContext';
import { toast } from 'sonner';

type Region = 'cervical' | 'toracica' | 'lombar';

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'success';
  timestamp: Date;
}

const ALERT_POOL: Array<{ message: string; type: Alert['type'] }> = [
  { message: 'Endireite a postura — cabeça inclinada para frente detectada', type: 'warning' },
  { message: 'Você está sentado há muito tempo. Faça uma pausa!', type: 'info' },
  { message: 'Tensão detectada nos ombros. Faça a rotação de ombros.', type: 'warning' },
  { message: 'Postura cervical corrigida! Bom trabalho!', type: 'success' },
  { message: 'Lembre-se de alongar a cada 45 minutos.', type: 'info' },
  { message: 'Curvatura lombar excessiva detectada. Ajuste o assento.', type: 'warning' },
  { message: 'Ótima manutenção postural nos últimos 10 minutos!', type: 'success' },
  { message: 'Incline levemente o monitor para cima para aliviar a cervical.', type: 'info' },
  { message: 'Contração na região torácica detectada. Respire fundo.', type: 'warning' },
];

function SpineVisualization({ activeRegion, scores }: {
  activeRegion: Region | null;
  scores: { cervical: number; toracica: number; lombar: number };
}) {
  const regionColor = (region: Region, activeColor: string, inactiveColor: string) =>
    activeRegion === region ? activeColor : inactiveColor;

  return (
    <div className="relative w-full flex items-center justify-center py-4">
      <div className="relative">
        <svg width="120" height="300" viewBox="0 0 120 300">
          <circle cx="60" cy="20" r="16" fill="#E5E7EB" stroke="#9CA3AF" strokeWidth="1.5" />
          <motion.g animate={{ opacity: activeRegion === 'cervical' ? 1 : 0.45 }}>
            {[0, 1, 2].map(i => (
              <rect
                key={`c${i}`}
                x={52 + i * 2} y={38 + i * 18}
                width={16 - i * 2} height={14}
                rx="3"
                fill={regionColor('cervical', '#EF4444', '#4F46E5')}
              />
            ))}
          </motion.g>
          <motion.g animate={{ opacity: activeRegion === 'toracica' ? 1 : 0.45 }}>
            {Array.from({ length: 12 }, (_, i) => (
              <rect
                key={`t${i}`}
                x="47" y={92 + i * 12}
                width="26" height="9"
                rx="2"
                fill={regionColor('toracica', '#F59E0B', '#A78BFA')}
              />
            ))}
          </motion.g>
          <motion.g animate={{ opacity: activeRegion === 'lombar' ? 1 : 0.45 }}>
            {[0, 1, 2, 3, 4].map(i => (
              <rect
                key={`l${i}`}
                x="44" y={238 + i * 13}
                width="32" height="11"
                rx="3"
                fill={regionColor('lombar', '#EF4444', '#10B981')}
              />
            ))}
          </motion.g>
        </svg>

        <div className="absolute -right-16 top-10 space-y-12 text-xs text-muted-foreground">
          <span className="block font-medium">Cervical</span>
          <span className="block font-medium mt-8">Torácica</span>
          <span className="block font-medium mt-10">Lombar</span>
        </div>
      </div>
    </div>
  );
}

function formatTime(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function MonitoringPage() {
  const { getTodayRecord, updateTodayScore } = useAppData();
  const todayRecord = getTodayRecord();

  const [isMonitoring, setIsMonitoring] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [activeRegion, setActiveRegion] = useState<Region>('cervical');
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [alertCount, setAlertCount] = useState(todayRecord.alerts);
  const [scores, setScores] = useState({
    current: todayRecord.score,
    cervical: todayRecord.cervical,
    toracica: todayRecord.toracica,
    lombar: todayRecord.lombar,
  });

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const scoreRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const alertRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearIntervals = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (scoreRef.current) clearInterval(scoreRef.current);
    if (alertRef.current) clearInterval(alertRef.current);
  }, []);

  const addAlert = useCallback(() => {
    const pool = ALERT_POOL[Math.floor(Math.random() * ALERT_POOL.length)];
    const newAlert: Alert = {
      id: crypto.randomUUID(),
      message: pool.message,
      type: pool.type,
      timestamp: new Date(),
    };
    setAlerts(prev => [newAlert, ...prev].slice(0, 8));
    setAlertCount(c => c + 1);
    if (pool.type === 'warning') toast.warning(pool.message, { duration: 4000 });
  }, []);

  const startMonitoring = useCallback(() => {
    setIsMonitoring(true);
    toast.success('Monitoramento iniciado! Mantenha boa postura.');

    timerRef.current = setInterval(() => setElapsedSeconds(s => s + 1), 1000);

    scoreRef.current = setInterval(() => {
      const delta = Math.random() > 0.4 ? Math.floor(Math.random() * 3) + 1 : -(Math.floor(Math.random() * 2) + 1);
      setScores(prev => {
        const newScore = Math.min(99, Math.max(40, prev.current + delta));
        const newCervical = Math.min(99, Math.max(35, prev.cervical + (Math.random() > 0.5 ? 1 : -1)));
        const newToracica = Math.min(99, Math.max(35, prev.toracica + (Math.random() > 0.6 ? 1 : -1)));
        const newLombar = Math.min(99, Math.max(35, prev.lombar + (Math.random() > 0.4 ? 1 : -1)));
        return { current: newScore, cervical: newCervical, toracica: newToracica, lombar: newLombar };
      });
      const regions: Region[] = ['cervical', 'toracica', 'lombar'];
      setActiveRegion(regions[Math.floor(Math.random() * regions.length)]);
    }, 8000);

    alertRef.current = setInterval(addAlert, 35000);

    setTimeout(addAlert, 5000);
  }, [addAlert]);

  const stopMonitoring = useCallback(() => {
    clearIntervals();
    setIsMonitoring(false);
    updateTodayScore(scores.current, alertCount);
    toast.info(`Monitoramento encerrado. Score salvo: ${scores.current}`);
  }, [clearIntervals, scores.current, alertCount, updateTodayScore]);

  useEffect(() => {
    return () => clearIntervals();
  }, [clearIntervals]);

  const getRegionStatus = (score: number) => {
    if (score >= 80) return { label: 'Excelente', color: 'bg-green-100 text-green-700', dot: 'bg-green-500' };
    if (score >= 60) return { label: 'Normal', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' };
    return { label: 'Atenção', color: 'bg-red-100 text-red-700', dot: 'bg-red-500' };
  };

  const cervicalStatus = getRegionStatus(scores.cervical);
  const toracicaStatus = getRegionStatus(scores.toracica);
  const lombarStatus = getRegionStatus(scores.lombar);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold mb-1">Monitoramento em Tempo Real</h1>
          <p className="text-muted-foreground">
            {isMonitoring ? `Ativo há ${formatTime(elapsedSeconds)}` : 'Inicie o monitoramento para acompanhar sua postura'}
          </p>
        </div>
        <Button
          size="lg"
          variant={isMonitoring ? 'destructive' : 'default'}
          onClick={isMonitoring ? stopMonitoring : startMonitoring}
          className="shadow-lg"
        >
          {isMonitoring ? (
            <><Pause className="w-5 h-5 mr-2" /> Pausar</>
          ) : (
            <><Play className="w-5 h-5 mr-2" /> Iniciar Monitoramento</>
          )}
        </Button>
      </div>

      <AnimatePresence>
        {isMonitoring && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <Card className="border-2 border-green-400 bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <motion.div
                    animate={{ scale: [1, 1.4, 1], opacity: [1, 0.6, 1] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="w-3 h-3 rounded-full bg-green-500 shrink-0"
                  />
                  <span className="font-semibold text-green-800">Monitoramento Ativo</span>
                  <div className="ml-auto flex items-center gap-3">
                    <Badge className="bg-green-600 text-white">IA Ativada</Badge>
                    <div className="flex items-center gap-1.5 text-sm font-mono text-green-700">
                      <Clock className="w-4 h-4" />
                      {formatTime(elapsedSeconds)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Visualização da Coluna</span>
              <div className="text-right">
                <p className="text-xs text-muted-foreground font-normal">Score atual</p>
                <p className="text-2xl font-bold text-primary">{scores.current}</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SpineVisualization activeRegion={isMonitoring ? activeRegion : null} scores={scores} />
          </CardContent>
        </Card>

        <div className="space-y-4">
          {[
            { region: 'cervical' as Region, label: 'Região Cervical', score: scores.cervical, status: cervicalStatus, desc: scores.cervical < 60 ? 'Leve inclinação para frente detectada' : 'Postura cervical adequada' },
            { region: 'toracica' as Region, label: 'Região Torácica', score: scores.toracica, status: toracicaStatus, desc: scores.toracica < 60 ? 'Tensão torácica detectada' : 'Alinhamento torácico adequado' },
            { region: 'lombar' as Region, label: 'Região Lombar', score: scores.lombar, status: lombarStatus, desc: scores.lombar < 60 ? 'Curvatura lombar excessiva' : 'Ótimo alinhamento lombar' },
          ].map(({ region, label, score, status, desc }) => (
            <motion.div key={region} animate={{ scale: isMonitoring && activeRegion === region ? 1.01 : 1 }}>
              <Card
                className={`cursor-pointer transition-all border-2 ${
                  isMonitoring && activeRegion === region ? 'border-primary shadow-md' : 'border-transparent hover:border-border'
                }`}
                onClick={() => setActiveRegion(region)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-2.5 h-2.5 rounded-full ${status.dot}`} />
                      <h3 className="font-semibold text-sm">{label}</h3>
                    </div>
                    <Badge className={status.color} variant="secondary">{status.label}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{desc}</p>
                  <div className="flex items-center gap-3">
                    <Progress value={score} className="h-2 flex-1" />
                    <span className="text-sm font-bold w-8 text-right">{score}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          <Card className="bg-muted/30">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-amber-600">{alertCount}</p>
                  <p className="text-xs text-muted-foreground">Alertas totais</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">{formatTime(elapsedSeconds)}</p>
                  <p className="text-xs text-muted-foreground">Tempo monitorado</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            Alertas Inteligentes
            {alertCount > 0 && <Badge variant="secondary" className="ml-auto">{alertCount} total</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {alerts.length === 0 ? (
            <div className="text-center py-8">
              <Zap className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">
                {isMonitoring ? 'Aguardando análise da postura...' : 'Inicie o monitoramento para receber alertas.'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <AnimatePresence>
                {alerts.map(alert => (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, x: -16, height: 0 }}
                    animate={{ opacity: 1, x: 0, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`flex items-start gap-3 p-3 rounded-lg border ${
                      alert.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                      alert.type === 'success' ? 'bg-green-50 border-green-200' :
                      'bg-blue-50 border-blue-200'
                    }`}
                  >
                    <AlertCircle className={`w-4 h-4 mt-0.5 shrink-0 ${
                      alert.type === 'warning' ? 'text-yellow-600' :
                      alert.type === 'success' ? 'text-green-600' :
                      'text-blue-600'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {alert.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
