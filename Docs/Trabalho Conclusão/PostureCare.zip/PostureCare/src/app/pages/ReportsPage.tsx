import React, { useMemo } from 'react';
import { AlertCircle, Award, BarChart3, Calendar, Target, TrendingDown, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Skeleton } from '@/app/components/ui/skeleton';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart,
  ResponsiveContainer, XAxis, YAxis, Tooltip, Legend
} from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/app/components/ui/chart';
import { useAppData } from '../components/AppContext';

const DAY_NAMES = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export default function ReportsPage() {
  const { userData, isLoading, getWeeklyData, getMonthlyData, getTotalExercisesCompleted } = useAppData();

  const weeklyData = getWeeklyData();
  const monthlyData = getMonthlyData();

  const weekChartData = useMemo(() => weeklyData.map(r => ({
    day: DAY_NAMES[new Date(r.date + 'T12:00:00').getDay()],
    score: r.score,
    cervical: r.cervical,
    toracica: r.toracica,
    lombar: r.lombar,
    alerts: r.alerts,
  })), [weeklyData]);

  const monthChartData = useMemo(() => monthlyData.map(r => ({
    week: r.date,
    cervical: r.cervical,
    lombar: r.lombar,
    toracica: r.toracica,
    score: r.score,
  })), [monthlyData]);

  const alertsChartData = useMemo(() => weeklyData.map(r => ({
    day: DAY_NAMES[new Date(r.date + 'T12:00:00').getDay()],
    alertas: r.alerts,
  })), [weeklyData]);

  const weekScores = weeklyData.filter(r => r.score > 0).map(r => r.score);
  const weekAvg = weekScores.length ? Math.round(weekScores.reduce((a, b) => a + b, 0) / weekScores.length) : 0;
  const weekFirst = weekScores[0] ?? 0;
  const weekLast = weekScores[weekScores.length - 1] ?? 0;
  const improvement = weekFirst > 0 ? Math.round(((weekLast - weekFirst) / weekFirst) * 100) : 0;
  const totalAlerts = weeklyData.reduce((s, r) => s + r.alerts, 0);

  const allScores = userData?.postureHistory.filter(r => r.score > 0).map(r => r.score) ?? [];
  const peakScore = allScores.length ? Math.max(...allScores) : 0;
  const avgScore30 = allScores.length ? Math.round(allScores.slice(-30).reduce((a, b) => a + b, 0) / Math.min(allScores.length, 30)) : 0;

  const achievements = [
    { icon: '🏆', title: '7 dias seguidos', achieved: (userData?.postureHistory.filter(r => r.score > 0).length ?? 0) >= 7 },
    { icon: '⭐', title: 'Score 80+', achieved: peakScore >= 80 },
    { icon: '🎯', title: '10 exercícios', achieved: getTotalExercisesCompleted() >= 10 },
    { icon: '💪', title: '30 dias ativos', achieved: (userData?.postureHistory.filter(r => r.score > 0).length ?? 0) >= 30 },
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid md:grid-cols-3 gap-4">
          {[1,2,3].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <Skeleton className="h-72 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-1">Relatórios e Estatísticas</h1>
        <p className="text-muted-foreground">Análise completa do seu progresso postural</p>
      </div>

      <Tabs defaultValue="week">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="week">Semanal</TabsTrigger>
          <TabsTrigger value="month">Mensal</TabsTrigger>
          <TabsTrigger value="all">Geral</TabsTrigger>
        </TabsList>

        <TabsContent value="week" className="space-y-6 mt-6">
          <div className="grid md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Target className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Score Médio</p>
                    <p className="text-2xl font-bold">{weekAvg}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${improvement >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                    {improvement >= 0
                      ? <TrendingUp className="w-5 h-5 text-green-600" />
                      : <TrendingDown className="w-5 h-5 text-red-600" />}
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Melhoria</p>
                    <p className={`text-2xl font-bold ${improvement >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {improvement >= 0 ? '+' : ''}{improvement}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-amber-500/10 flex items-center justify-center">
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Alertas</p>
                    <p className="text-2xl font-bold">{totalAlerts}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Score Diário — Última Semana</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer config={{ score: { label: 'Score', color: '#4F46E5' } }} className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={weekChartData}>
                    <defs>
                      <linearGradient id="scoreGrad2" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#4F46E5" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                    <XAxis dataKey="day" stroke="#9CA3AF" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#9CA3AF" domain={[0, 100]} tick={{ fontSize: 11 }} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area type="monotone" dataKey="score" stroke="#4F46E5" strokeWidth={2.5} fill="url(#scoreGrad2)" dot={{ r: 4, fill: '#4F46E5' }} />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Alertas por Dia</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer config={{ alertas: { label: 'Alertas', color: '#F59E0B' } }} className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={alertsChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                    <XAxis dataKey="day" stroke="#9CA3AF" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#9CA3AF" tick={{ fontSize: 11 }} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="alertas" fill="#F59E0B" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="month" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Evolução por Região — Últimas 4 Semanas</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  cervical: { label: 'Cervical', color: '#EF4444' },
                  lombar: { label: 'Lombar', color: '#10B981' },
                  toracica: { label: 'Torácica', color: '#A78BFA' },
                }}
                className="h-72"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                    <XAxis dataKey="week" stroke="#9CA3AF" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#9CA3AF" domain={[0, 100]} tick={{ fontSize: 11 }} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line type="monotone" dataKey="cervical" stroke="#EF4444" strokeWidth={2.5} dot={{ r: 5 }} />
                    <Line type="monotone" dataKey="lombar" stroke="#10B981" strokeWidth={2.5} dot={{ r: 5 }} />
                    <Line type="monotone" dataKey="toracica" stroke="#A78BFA" strokeWidth={2.5} dot={{ r: 5 }} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-4">
            {[
              { label: 'Score Médio Mensal', value: avgScore30, icon: Target, color: 'text-primary' },
              { label: 'Score Máximo', value: peakScore, icon: TrendingUp, color: 'text-green-600' },
              { label: 'Total de Exercícios', value: getTotalExercisesCompleted(), icon: Award, color: 'text-secondary' },
            ].map((s, i) => (
              <Card key={i}>
                <CardContent className="p-5 text-center">
                  <s.icon className={`w-6 h-6 mx-auto mb-2 ${s.color}`} />
                  <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="all" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Award className="w-4 h-4 text-primary" />
                Conquistas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {achievements.map((a, i) => (
                  <div
                    key={i}
                    className={`p-4 rounded-xl border-2 text-center transition-all ${
                      a.achieved ? 'border-primary bg-primary/5 shadow-sm' : 'border-border opacity-40 grayscale'
                    }`}
                  >
                    <div className="text-4xl mb-2">{a.icon}</div>
                    <p className="text-xs font-medium">{a.title}</p>
                    {a.achieved && <p className="text-[10px] text-green-600 mt-1 font-semibold">✓ Conquistado</p>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Histórico de Score — 30 dias</CardTitle>
            </CardHeader>
            <CardContent>
              {userData && userData.postureHistory.length > 0 ? (
                <ChartContainer config={{ score: { label: 'Score', color: '#4F46E5' } }} className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={userData.postureHistory.slice(-30).map((r, i) => ({ day: i + 1, score: r.score }))}>
                      <defs>
                        <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10B981" stopOpacity={0.2} />
                          <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                      <XAxis dataKey="day" stroke="#9CA3AF" tick={{ fontSize: 10 }} label={{ value: 'Dia', position: 'insideBottomRight', offset: -5, fontSize: 11 }} />
                      <YAxis stroke="#9CA3AF" domain={[0, 100]} tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(v: number) => [v, 'Score']} />
                      <Area type="monotone" dataKey="score" stroke="#10B981" strokeWidth={2} fill="url(#histGrad)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </ChartContainer>
              ) : (
                <div className="text-center py-10">
                  <BarChart3 className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground">Sem dados suficientes ainda.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
