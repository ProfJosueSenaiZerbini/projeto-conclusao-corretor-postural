import React, { useState, useRef } from 'react';
import {
  Bell, Camera, CheckCircle2, ChevronRight, Heart, Loader2,
  LogOut, Save, Settings, Shield, Target, User
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Progress } from '@/app/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/app/components/ui/dialog';
import { Switch } from '@/app/components/ui/switch';
import { Separator } from '@/app/components/ui/separator';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { useAuth } from '../components/auth/AuthContext';
import { useAppData, AppSettings } from '../components/AppContext';
import { toast } from 'sonner';
import { useNavigate } from 'react-router';

type ModalType = 'editProfile' | 'notifications' | 'privacy' | 'health' | null;

function EditProfileModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { userData, updateProfile } = useAppData();
  const [form, setForm] = useState({
    name: userData?.profile.name ?? '',
    weight: String(userData?.profile.weight ?? '70'),
    height: String(userData?.profile.height ?? '1.70'),
    age: String(userData?.profile.age ?? '30'),
    goal: userData?.profile.goal ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | undefined>(userData?.profile.avatarImage);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { toast.error('Imagem muito grande. Máximo 2MB.'); return; }
    const reader = new FileReader();
    reader.onload = ev => setAvatarPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Nome é obrigatório.'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 600));
    updateProfile({
      name: form.name.trim(),
      weight: parseFloat(form.weight) || 70,
      height: parseFloat(form.height) || 1.70,
      age: parseInt(form.age) || 30,
      goal: form.goal.trim(),
      avatarImage: avatarPreview,
    });
    setSaving(false);
    toast.success('Perfil atualizado com sucesso!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Perfil</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center mb-4">
          <div className="relative">
            <Avatar className="w-20 h-20">
              {avatarPreview ? (
                <img src={avatarPreview} alt="avatar" className="object-cover w-full h-full rounded-full" />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-xl">
                  {form.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              )}
            </Avatar>
            <button
              onClick={() => fileRef.current?.click()}
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
          <p className="text-xs text-muted-foreground mt-2">Clique no ícone para alterar a foto</p>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="edit-name">Nome completo</Label>
            <Input id="edit-name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="mt-1.5" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="edit-weight">Peso (kg)</Label>
              <Input id="edit-weight" type="number" value={form.weight} onChange={e => setForm(f => ({ ...f, weight: e.target.value }))} className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="edit-height">Altura (m)</Label>
              <Input id="edit-height" type="number" step="0.01" value={form.height} onChange={e => setForm(f => ({ ...f, height: e.target.value }))} className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="edit-age">Idade</Label>
              <Input id="edit-age" type="number" value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} className="mt-1.5" />
            </div>
          </div>

          <div>
            <Label htmlFor="edit-goal">Objetivo principal</Label>
            <Input id="edit-goal" value={form.goal} onChange={e => setForm(f => ({ ...f, goal: e.target.value }))} placeholder="ex: Melhorar postura" className="mt-1.5" />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4 mr-2" /> Salvar</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function NotificationsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { userData, updateSettings } = useAppData();
  const settings = userData?.settings;
  const [form, setForm] = useState<Partial<AppSettings>>({
    notificationsEnabled: settings?.notificationsEnabled ?? true,
    notifFrequency: settings?.notifFrequency ?? 'media',
    stretchReminders: settings?.stretchReminders ?? true,
    wellbeingReminders: settings?.wellbeingReminders ?? true,
  });

  const handleSave = () => {
    updateSettings(form);
    toast.success('Notificações atualizadas!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Configurar Notificações</DialogTitle></DialogHeader>
        <div className="space-y-5 py-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">Ativar notificações</p>
              <p className="text-xs text-muted-foreground">Alertas de postura e lembretes</p>
            </div>
            <Switch checked={form.notificationsEnabled} onCheckedChange={v => setForm(f => ({ ...f, notificationsEnabled: v }))} />
          </div>
          <Separator />
          {form.notificationsEnabled && (
            <>
              <div>
                <p className="font-medium text-sm mb-2">Frequência dos alertas</p>
                <div className="grid grid-cols-3 gap-2">
                  {(['baixa', 'media', 'alta'] as const).map(freq => (
                    <button
                      key={freq}
                      onClick={() => setForm(f => ({ ...f, notifFrequency: freq }))}
                      className={`py-2 rounded-lg border-2 text-sm font-medium transition-all capitalize ${
                        form.notifFrequency === freq ? 'border-primary bg-primary/10 text-primary' : 'border-border'
                      }`}
                    >
                      {freq === 'baixa' ? 'Baixa' : freq === 'media' ? 'Média' : 'Alta'}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm">Lembrete de alongamento</p>
                <Switch checked={form.stretchReminders} onCheckedChange={v => setForm(f => ({ ...f, stretchReminders: v }))} />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm">Lembretes de bem-estar</p>
                <Switch checked={form.wellbeingReminders} onCheckedChange={v => setForm(f => ({ ...f, wellbeingReminders: v }))} />
              </div>
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PrivacyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { userData, updateSettings } = useAppData();
  const [dataSharing, setDataSharing] = useState(userData?.settings.dataSharing ?? false);

  const handleSave = () => {
    updateSettings({ dataSharing });
    toast.success('Configurações de privacidade salvas!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Privacidade e Dados</DialogTitle></DialogHeader>
        <div className="space-y-5 py-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-medium text-sm">Compartilhar dados anônimos</p>
              <p className="text-xs text-muted-foreground mt-1">Ajuda a melhorar as recomendações de postura para todos os usuários. Nenhuma informação pessoal é compartilhada.</p>
            </div>
            <Switch checked={dataSharing} onCheckedChange={setDataSharing} />
          </div>
          <Separator />
          <div className="rounded-lg bg-muted/40 p-3">
            <p className="text-xs text-muted-foreground">Todos os seus dados são armazenados localmente no seu dispositivo e pertencem somente a você.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function HealthModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { userData, updateSettings } = useAppData();
  const [form, setForm] = useState({
    wellbeingReminders: userData?.settings.wellbeingReminders ?? true,
    stretchReminders: userData?.settings.stretchReminders ?? true,
  });

  const handleSave = () => {
    updateSettings(form);
    toast.success('Configurações de saúde salvas!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Saúde e Bem-estar</DialogTitle></DialogHeader>
        <div className="space-y-5 py-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">Lembretes de bem-estar</p>
              <p className="text-xs text-muted-foreground">Pausas ativas e lembretes de hidratação</p>
            </div>
            <Switch checked={form.wellbeingReminders} onCheckedChange={v => setForm(f => ({ ...f, wellbeingReminders: v }))} />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">Lembretes de alongamento</p>
              <p className="text-xs text-muted-foreground">Alertas para alongar a cada 45 min</p>
            </div>
            <Switch checked={form.stretchReminders} onCheckedChange={v => setForm(f => ({ ...f, stretchReminders: v }))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { userData, isLoading, getTotalExercisesCompleted, getStreakDays } = useAppData();
  const [modal, setModal] = useState<ModalType>(null);

  const handleLogout = () => {
    logout();
    toast.success('Sessão encerrada.');
    navigate('/login');
  };

  if (isLoading || !userData) {
    return (
      <div className="space-y-6">
        {[1,2,3].map(i => <div key={i} className="h-32 bg-muted/30 rounded-2xl animate-pulse" />)}
      </div>
    );
  }

  const profile = userData.profile;
  const totalEx = getTotalExercisesCompleted();
  const streak = getStreakDays();
  const avgScore = userData.postureHistory.length
    ? Math.round(userData.postureHistory.slice(-7).reduce((s, r) => s + r.score, 0) / Math.min(userData.postureHistory.length, 7))
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-1">Perfil</h1>
        <p className="text-muted-foreground">Gerencie suas informações e configurações</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-5 mb-6">
            <div className="relative">
              <Avatar className="w-20 h-20">
                {profile.avatarImage ? (
                  <img src={profile.avatarImage} alt="avatar" className="object-cover w-full h-full rounded-full" />
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-2xl">
                    {profile.avatarInitials}
                  </AvatarFallback>
                )}
              </Avatar>
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold truncate">{profile.name}</h2>
              <p className="text-muted-foreground text-sm truncate">{user?.email}</p>
              <p className="text-xs text-muted-foreground mt-1">Membro desde {profile.memberSince}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setModal('editProfile')}>
              <User className="w-4 h-4 mr-2" /> Editar
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Peso', value: `${profile.weight} kg` },
              { label: 'Altura', value: `${profile.height} m` },
              { label: 'Idade', value: `${profile.age} anos` },
              { label: 'IMC', value: (profile.weight / (profile.height * profile.height)).toFixed(1) },
            ].map(item => (
              <div key={item.label} className="bg-muted/30 rounded-xl p-3">
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className="font-semibold mt-0.5">{item.value}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="w-4 h-4 text-primary" /> Objetivo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground italic">"{profile.goal}"</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Progresso Geral</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div>
            <div className="flex justify-between mb-1.5">
              <span className="text-sm font-medium">Score Médio (7d)</span>
              <span className="text-sm text-muted-foreground">{avgScore}/100</span>
            </div>
            <Progress value={avgScore} className="h-2.5" />
          </div>
          <div>
            <div className="flex justify-between mb-1.5">
              <span className="text-sm font-medium">Exercícios concluídos</span>
              <span className="text-sm text-muted-foreground">{totalEx}/50</span>
            </div>
            <Progress value={(totalEx / 50) * 100} className="h-2.5" />
          </div>
          <div>
            <div className="flex justify-between mb-1.5">
              <span className="text-sm font-medium">Dias consecutivos</span>
              <span className="text-sm text-muted-foreground">{streak}/30</span>
            </div>
            <Progress value={(streak / 30) * 100} className="h-2.5" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Settings className="w-4 h-4 text-primary" /> Configurações
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {[
            { icon: Bell, label: 'Notificações', desc: userData.settings.notificationsEnabled ? 'Ativadas' : 'Desativadas', modal: 'notifications' as ModalType },
            { icon: Shield, label: 'Privacidade', desc: 'Gerencie seus dados', modal: 'privacy' as ModalType },
            { icon: Heart, label: 'Saúde e Bem-estar', desc: 'Lembretes e metas', modal: 'health' as ModalType },
          ].map(item => (
            <button
              key={item.label}
              onClick={() => setModal(item.modal)}
              className="w-full flex items-center gap-4 px-5 py-4 hover:bg-muted/50 transition-colors text-left border-b border-border last:border-0 first:rounded-t-none"
            >
              <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                <item.icon className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
            </button>
          ))}
        </CardContent>
      </Card>

      <Button
        variant="outline"
        className="w-full text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/30"
        onClick={handleLogout}
      >
        <LogOut className="w-4 h-4 mr-2" /> Sair da conta
      </Button>

      <EditProfileModal open={modal === 'editProfile'} onClose={() => setModal(null)} />
      <NotificationsModal open={modal === 'notifications'} onClose={() => setModal(null)} />
      <PrivacyModal open={modal === 'privacy'} onClose={() => setModal(null)} />
      <HealthModal open={modal === 'health'} onClose={() => setModal(null)} />
    </div>
  );
}
