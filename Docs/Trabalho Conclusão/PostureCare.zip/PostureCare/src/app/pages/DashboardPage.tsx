import React from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  Activity, AlertCircle, Clock, Flame, LineChart, Play,
  Sparkles, TrendingUp, Zap, CheckCircle2, Target
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Skeleton } from '@/app/components/ui/skeleton';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/app/components/ui/chart';
import { useAuth } from '../components/auth/AuthContext';
import { useAppData } from '../components/AppContext';

function ScoreRing({ score }: { score: number }) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - score / 100);
  const color = score >= 80 ? '#10B981' : score >= 60 ? '#F59E0B' : '#EF4444';
  return (
    <div className="relative w-24 h-24">
      <svg className="transform -rotate-90 w-24 h-24">
        <circle cx="48" cy="48" r={radius} stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted/20" />
        <circle
          cx="48" cy="48" r={radius}
          stroke={color} strokeWidth="8" fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <Sparkles className="w-7 h-7 text-primary" />
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { userData, isLoading, getTodayRecord, getWeeklyData, getTotalExercisesCompleted, getStreakDays } = useAppData();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-40 w-full rounded-2xl" />
        <div className="grid grid-cols-2 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }

  const todayRecord = getTodayRecord();
  const weeklyData = getWeeklyData();
  const totalExercises = getTotalExercisesCompleted();
  const streakDays = getStreakDays();
  const firstName = (userData?.profile.name ?? user?.name ?? 'Usuário').split(' ')[0];

  const chartData = weeklyData.map(r => ({
    day: new Date(r.date + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''),
    score: r.score,
  }));

  const scoreLabel = todayRecord.score >= 80 ? 'Excelente! Continue assim!' : todayRecord.score >= 60 ? 'Bom! Você pode melhorar mais.' : 'Atenção à sua postura hoje.';
  const weekImprovement = weeklyData.length >= 2
    ? Math.round(((weeklyData[weeklyData.length - 1].score - weeklyData[0].score) / Math.max(weeklyData[0].score, 1)) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-1">
          Olá, {firstName}! 👋
        </h1>
        <p className="text-muted-foreground">{scoreLabel}</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Score da Postura — Hoje</p>
                <h2 className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  {todayRecord.score}
                </h2>
                <p className="text-xs text-muted-foreground mt-1">/100 pontos</p>
              </div>
              <ScoreRing score={todayRecord.score} />
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge
                variant="secondary"
                className={`${weekImprovement >= 0 ? 'bg-accent/10 text-accent border-accent/20' : 'bg-destructive/10 text-destructive'}`}
              >
                <TrendingUp className="w-3 h-3 mr-1" />
                {weekImprovement >= 0 ? '+' : ''}{weekImprovement}% esta semana
              </Badge>
              <span className="text-sm text-muted-foreground">
                {weekImprovement >= 5 ? 'Ótimo progresso!' : weekImprovement >= 0 ? 'Mantenha o ritmo!' : 'Foque nos exercícios.'}
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        {[
          {
            icon: Clock, color: 'blue', value: `${todayRecord.sittingTime.toFixed(1)}h`,
            label: 'Tempo sentado', bg: 'bg-blue-500/10', text: 'text-blue-600'
          },
          {
            icon: AlertCircle, color: 'red', value: todayRecord.alerts.toString(),
            label: 'Alertas hoje', bg: 'bg-red-500/10', text: 'text-red-600'
          },
          {
            icon: CheckCircle2, color: 'green', value: todayRecord.exercises.toString(),
            label: 'Exercícios hoje', bg: 'bg-green-500/10', text: 'text-green-600'
          },
          {
            icon: Flame, color: 'amber', value: `${streakDays}d`,
            label: 'Sequência', bg: 'bg-amber-500/10', text: 'text-amber-600'
          },
        ].map((stat, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center shrink-0`}>
                    <stat.icon className={`w-5 h-5 ${stat.text}`} />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <LineChart className="w-4 h-4 text-primary" />
            Evolução dos Últimos 7 Dias
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{ score: { label: 'Score', color: 'hsl(var(--primary))' } }} className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#4F46E5" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="day" stroke="#9CA3AF" tick={{ fontSize: 11 }} />
                <YAxis stroke="#9CA3AF" domain={[0, 100]} tick={{ fontSize: 11 }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="score" stroke="#4F46E5" strokeWidth={2.5} fill="url(#scoreGrad)" dot={{ r: 4, fill: '#4F46E5' }} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="border-2 border-primary bg-gradient-to-r from-primary to-secondary text-white">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold mb-1">Monitoramento ao Vivo</h3>
                <p className="text-white/80 text-sm">Acompanhe sua postura agora</p>
              </div>
              <Button
                size="sm"
                variant="secondary"
                className="bg-white text-primary hover:bg-white/90 shadow"
                onClick={() => navigate('/monitoramento')}
              >
                <Play className="w-4 h-4 mr-1" /> Iniciar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-secondary/30 bg-gradient-to-r from-secondary/5 to-accent/5">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold mb-1">Exercícios de Hoje</h3>
                <p className="text-muted-foreground text-sm">{totalExercises} concluídos no total</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => navigate('/exercicios')}
              >
                <Zap className="w-4 h-4 mr-1" /> Ver todos
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardContent className="p-5">
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Resumo Geral</h3>
          </div>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-primary">{totalExercises}</p>
              <p className="text-xs text-muted-foreground">Exercícios feitos</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-secondary">{Math.round(weeklyData.reduce((s, r) => s + r.score, 0) / Math.max(weeklyData.filter(r => r.score > 0).length, 1))}</p>
              <p className="text-xs text-muted-foreground">Score médio</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-accent">{streakDays}</p>
              <p className="text-xs text-muted-foreground">Dias seguidos</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
