import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, ChevronRight, Pause, Play, RotateCcw, Timer, Award } from 'lucide-react';
import { Card, CardContent } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/app/components/ui/dialog';
import { Separator } from '@/app/components/ui/separator';
import { exercisesData, ExerciseData } from '../components/exercises-data';
import { useAppData } from '../components/AppContext';
import { toast } from 'sonner';

const CATEGORIES = ['Todos', 'Cervical', 'Lombar', 'Torácica'];

const difficultyColor: Record<string, string> = {
  'Fácil': 'border-green-500 text-green-700 bg-green-50',
  'Médio': 'border-amber-500 text-amber-700 bg-amber-50',
  'Difícil': 'border-red-500 text-red-700 bg-red-50',
};

function formatTime(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function ExerciseTimer({ exercise, onComplete }: { exercise: ExerciseData; onComplete: () => void }) {
  const [remaining, setRemaining] = useState(exercise.durationSeconds);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const progress = ((exercise.durationSeconds - remaining) / exercise.durationSeconds) * 100;

  useEffect(() => {
    if (running && remaining > 0) {
      intervalRef.current = setInterval(() => {
        setRemaining(r => {
          if (r <= 1) {
            clearInterval(intervalRef.current!);
            setRunning(false);
            setDone(true);
            return 0;
          }
          return r - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [running]);

  const reset = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setRemaining(exercise.durationSeconds);
    setRunning(false);
    setDone(false);
  };

  if (done) {
    return (
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-6">
        <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: 2, duration: 0.4 }}>
          <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
        </motion.div>
        <h3 className="text-xl font-bold text-green-700 mb-2">Exercício Concluído!</h3>
        <p className="text-muted-foreground text-sm mb-6">
          Parabéns! Você completou {exercise.name}.
        </p>
        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={reset}>
            <RotateCcw className="w-4 h-4 mr-2" /> Repetir
          </Button>
          <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700 text-white">
            Salvar progresso
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="text-center">
        <p className="text-6xl font-bold font-mono text-primary mb-2">{formatTime(remaining)}</p>
        <p className="text-sm text-muted-foreground">de {formatTime(exercise.durationSeconds)} restante</p>
      </div>
      <Progress value={progress} className="h-3" />
      <div className="flex gap-3 justify-center">
        <Button variant="outline" size="icon" onClick={reset} disabled={remaining === exercise.durationSeconds && !running}>
          <RotateCcw className="w-4 h-4" />
        </Button>
        <Button size="lg" onClick={() => setRunning(r => !r)} className="px-10">
          {running ? <><Pause className="w-5 h-5 mr-2" /> Pausar</> : <><Play className="w-5 h-5 mr-2" /> {remaining === exercise.durationSeconds ? 'Iniciar' : 'Continuar'}</>}
        </Button>
      </div>
    </div>
  );
}

function ExerciseModal({ exercise, onClose }: { exercise: ExerciseData | null; onClose: () => void }) {
  const { completeExercise, userData } = useAppData();
  const [tab, setTab] = useState<'info' | 'timer'>('info');
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    if (exercise) {
      setTab('info');
      setCompleted(false);
    }
  }, [exercise?.id]);

  if (!exercise) return null;

  const completedCount = userData?.completedExercises.filter(c => c.exerciseId === exercise.id).length ?? 0;

  const handleComplete = () => {
    completeExercise(exercise.id, exercise.durationSeconds);
    setCompleted(true);
    toast.success(`${exercise.name} salvo! +1 exercício concluído hoje.`);
    setTimeout(onClose, 1800);
  };

  return (
    <Dialog open={!!exercise} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <span className="text-3xl">{exercise.icon}</span>
            <div>
              <p className="text-lg font-bold">{exercise.name}</p>
              <div className="flex gap-2 mt-1">
                <Badge variant="secondary" className="text-xs">{exercise.category}</Badge>
                <Badge variant="outline" className={`text-xs ${difficultyColor[exercise.difficulty]}`}>{exercise.difficulty}</Badge>
                <Badge variant="outline" className="text-xs">
                  <Timer className="w-3 h-3 mr-1" />
                  {Math.round(exercise.durationSeconds / 60)} min
                </Badge>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-2 mb-4">
          <Button variant={tab === 'info' ? 'default' : 'outline'} size="sm" onClick={() => setTab('info')}>Detalhes</Button>
          <Button variant={tab === 'timer' ? 'default' : 'outline'} size="sm" onClick={() => setTab('timer')}>
            <Play className="w-3 h-3 mr-1" /> Iniciar Exercício
          </Button>
          {completedCount > 0 && (
            <Badge variant="secondary" className="ml-auto bg-green-100 text-green-700">
              <Award className="w-3 h-3 mr-1" /> {completedCount}x feito
            </Badge>
          )}
        </div>

        {completed && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-green-50 border border-green-200 rounded-lg p-4 text-center mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="font-semibold text-green-800">Progresso salvo com sucesso!</p>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {tab === 'info' ? (
            <motion.div key="info" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground leading-relaxed">{exercise.description}</p>
              </div>

              <div>
                <h4 className="font-semibold text-sm mb-2">Benefícios</h4>
                <div className="space-y-1.5">
                  {exercise.benefits.map((b, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                      <span>{b}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold text-sm mb-2">Músculos trabalhados</h4>
                <div className="flex flex-wrap gap-1.5">
                  {exercise.muscles.map((m, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">{m}</Badge>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold text-sm mb-2">Como fazer — passo a passo</h4>
                <ol className="space-y-2">
                  {exercise.steps.map((step, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <Button className="w-full" onClick={() => setTab('timer')}>
                <Play className="w-4 h-4 mr-2" /> Iniciar com Cronômetro
              </Button>
            </motion.div>
          ) : (
            <motion.div key="timer" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              <ExerciseTimer exercise={exercise} onComplete={handleComplete} />
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}

export default function ExercisesPage() {
  const { userData, getTotalExercisesCompleted, getStreakDays } = useAppData();
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedExercise, setSelectedExercise] = useState<ExerciseData | null>(null);

  const filtered = selectedCategory === 'Todos'
    ? exercisesData
    : exercisesData.filter(e => e.category === selectedCategory);

  const totalCompleted = getTotalExercisesCompleted();
  const streak = getStreakDays();
  const totalMinutes = Math.round((userData?.completedExercises.reduce((s, c) => s + c.durationSeconds, 0) ?? 0) / 60);

  const isCompletedToday = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    return userData?.completedExercises.some(c => c.exerciseId === id && c.completedAt.startsWith(today)) ?? false;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-1">Exercícios e Alongamentos</h1>
        <p className="text-muted-foreground">Exercícios personalizados para sua saúde postural</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {CATEGORIES.map(cat => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(cat)}
            className="whitespace-nowrap shrink-0"
          >
            {cat}
          </Button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {filtered.map((exercise, index) => {
            const completedToday = isCompletedToday(exercise.id);
            return (
              <motion.div
                key={exercise.id}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: index * 0.04 }}
              >
                <Card
                  className={`cursor-pointer transition-all hover:shadow-lg h-full border-2 ${
                    completedToday ? 'border-green-400 bg-green-50/40' : 'border-transparent hover:border-primary/20'
                  }`}
                  onClick={() => setSelectedExercise(exercise)}
                >
                  <CardContent className="p-5 flex flex-col h-full">
                    <div className="flex items-start justify-between mb-3">
                      <span className="text-4xl">{exercise.icon}</span>
                      {completedToday && (
                        <Badge className="bg-green-600 text-white text-xs">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Feito hoje
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-semibold text-base mb-1.5">{exercise.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4 flex-1 line-clamp-2">{exercise.description}</p>
                    <div className="flex items-center gap-2 mb-4">
                      <Badge variant="secondary" className="text-xs">{exercise.category}</Badge>
                      <Badge variant="outline" className={`text-xs ${difficultyColor[exercise.difficulty]}`}>
                        {exercise.difficulty}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between mt-auto">
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <Timer className="w-3.5 h-3.5" />
                        {Math.round(exercise.durationSeconds / 60)} min
                      </div>
                      <Button size="sm" onClick={e => { e.stopPropagation(); setSelectedExercise(exercise); }}>
                        <Play className="w-3.5 h-3.5 mr-1" />
                        {completedToday ? 'Repetir' : 'Iniciar'}
                        <ChevronRight className="w-3.5 h-3.5 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardContent className="p-6">
          <div className="grid grid-cols-3 gap-6 text-center">
            <div>
              <p className="text-3xl font-bold text-primary">{totalCompleted}</p>
              <p className="text-sm text-muted-foreground mt-1">Exercícios feitos</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-secondary">{totalMinutes}m</p>
              <p className="text-sm text-muted-foreground mt-1">Tempo total</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-accent">{streak}</p>
              <p className="text-sm text-muted-foreground mt-1">Dias seguidos</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <ExerciseModal exercise={selectedExercise} onClose={() => setSelectedExercise(null)} />
    </div>
  );
}
