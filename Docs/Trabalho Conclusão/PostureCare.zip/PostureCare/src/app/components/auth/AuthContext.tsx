import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  API_BASE_URL, JWT_STORAGE_KEY, apiUrl, decodeJWTPayload,
  isTokenValid, isApiConfigured, API_TIMEOUT_MS,
} from '../../config/api';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  usingApi: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | null>(null);

// ─── FALLBACK: autenticação local via localStorage ────────────────────────────
const LOCAL_USERS_KEY = 'pc_users_local';
const LOCAL_SESSION_KEY = 'pc_session_local';

interface LocalUser extends AuthUser {
  passwordHash: string;
}

function hashLocal(password: string): string {
  return btoa(password + '_posturecare_local_2024');
}

function getLocalUsers(): LocalUser[] {
  try { return JSON.parse(localStorage.getItem(LOCAL_USERS_KEY) || '[]'); } catch { return []; }
}
function saveLocalUsers(users: LocalUser[]): void {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

// ─── API HELPERS ─────────────────────────────────────────────────────────────
interface ApiAuthResponse {
  token: string;
  user: AuthUser;
}
interface ApiErrorResponse {
  error: string;
}

async function apiFetch<T>(path: string, body: object): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  try {
    const res = await fetch(apiUrl(path), {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
      signal:  controller.signal,
    });
    const data = await res.json();
    if (!res.ok) throw Object.assign(new Error((data as ApiErrorResponse).error), { status: res.status });
    return data as T;
  } finally {
    clearTimeout(timer);
  }
}

function storeToken(token: string): void {
  localStorage.setItem(JWT_STORAGE_KEY, token);
}

function clearToken(): void {
  localStorage.removeItem(JWT_STORAGE_KEY);
}

// ─── PROVIDER ─────────────────────────────────────────────────────────────────
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser]       = useState<AuthUser | null>(null);
  const [isLoading, setLoading] = useState(true);
  const [usingApi]            = useState(isApiConfigured());

  // Restaura sessão ao montar
  useEffect(() => {
    if (usingApi) {
      // Modo API — lê o JWT salvo
      const token = localStorage.getItem(JWT_STORAGE_KEY);
      if (token && isTokenValid(token)) {
        const payload = decodeJWTPayload(token);
        if (payload) {
          setUser({ id: payload.id, email: payload.email, name: payload.name, createdAt: '' });
        }
      }
    } else {
      // Modo local — lê a sessão localStorage
      const sessionId = localStorage.getItem(LOCAL_SESSION_KEY);
      if (sessionId) {
        const found = getLocalUsers().find(u => u.id === sessionId);
        if (found) {
          const { passwordHash: _ph, ...userData } = found;
          setUser(userData);
        } else {
          localStorage.removeItem(LOCAL_SESSION_KEY);
        }
      }
    }
    setLoading(false);
  }, [usingApi]);

  // ── LOGIN ──────────────────────────────────────────────────────────────────
  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (!email.trim() || !password) {
      return { success: false, error: 'Preencha e-mail e senha.' };
    }

    if (usingApi) {
      try {
        const data = await apiFetch<ApiAuthResponse>('/api/auth/login', { email, password });
        storeToken(data.token);
        setUser(data.user);
        return { success: true };
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Erro ao conectar com o servidor.';
        // Se foi timeout/rede, informe claramente
        if (err instanceof DOMException && err.name === 'AbortError') {
          return { success: false, error: 'Servidor não respondeu. Verifique a conexão.' };
        }
        return { success: false, error: msg };
      }
    }

    // Fallback local
    await new Promise(r => setTimeout(r, 600));
    const users = getLocalUsers();
    const stored = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!stored) return { success: false, error: 'Usuário não encontrado. Crie uma conta primeiro.' };
    if (stored.passwordHash !== hashLocal(password)) return { success: false, error: 'Senha incorreta. Tente novamente.' };

    const { passwordHash: _ph, ...userData } = stored;
    setUser(userData);
    localStorage.setItem(LOCAL_SESSION_KEY, stored.id);
    return { success: true };
  };

  // ── REGISTER ───────────────────────────────────────────────────────────────
  const register = async (email: string, password: string, name: string): Promise<{ success: boolean; error?: string }> => {
    if (!name.trim() || !email.trim() || !password) return { success: false, error: 'Preencha todos os campos.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return { success: false, error: 'E-mail inválido.' };
    if (password.length < 6) return { success: false, error: 'Senha deve ter pelo menos 6 caracteres.' };

    if (usingApi) {
      try {
        const data = await apiFetch<ApiAuthResponse>('/api/auth/register', { name, email, password });
        storeToken(data.token);
        setUser(data.user);
        return { success: true };
      } catch (err: unknown) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return { success: false, error: 'Servidor não respondeu. Verifique a conexão.' };
        }
        const msg = err instanceof Error ? err.message : 'Erro ao criar conta.';
        return { success: false, error: msg };
      }
    }

    // Fallback local
    await new Promise(r => setTimeout(r, 800));
    const users = getLocalUsers();
    if (users.find(u => u.email.toLowerCase() === email.trim().toLowerCase())) {
      return { success: false, error: 'E-mail já cadastrado. Faça login.' };
    }
    const newUser: LocalUser = {
      id:           crypto.randomUUID(),
      email:        email.trim().toLowerCase(),
      name:         name.trim(),
      createdAt:    new Date().toISOString(),
      passwordHash: hashLocal(password),
    };
    saveLocalUsers([...users, newUser]);
    const { passwordHash: _ph, ...userData } = newUser;
    setUser(userData);
    localStorage.setItem(LOCAL_SESSION_KEY, newUser.id);
    return { success: true };
  };

  // ── LOGOUT ─────────────────────────────────────────────────────────────────
  const logout = () => {
    setUser(null);
    if (usingApi) {
      clearToken();
    } else {
      localStorage.removeItem(LOCAL_SESSION_KEY);
    }
  };

  // ── RESET PASSWORD ─────────────────────────────────────────────────────────
  const sendPasswordReset = async (email: string): Promise<{ success: boolean; error?: string }> => {
    if (!email.trim()) return { success: false, error: 'Informe o e-mail.' };

    if (usingApi) {
      try {
        await apiFetch('/api/auth/reset-password', { email });
        return { success: true };
      } catch (err: unknown) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return { success: false, error: 'Servidor não respondeu.' };
        }
        const msg = err instanceof Error ? err.message : 'Erro ao enviar e-mail.';
        return { success: false, error: msg };
      }
    }

    // Fallback local
    await new Promise(r => setTimeout(r, 1000));
    const found = getLocalUsers().find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!found) return { success: false, error: 'E-mail não encontrado.' };
    return { success: true };
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, usingApi, login, register, logout, sendPasswordReset }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
