export interface ExerciseData {
  id: string;
  name: string;
  category: 'Cervical' | 'Lombar' | 'Torácica';
  durationSeconds: number;
  difficulty: 'Fácil' | 'Médio' | 'Difícil';
  icon: string;
  description: string;
  benefits: string[];
  muscles: string[];
  steps: string[];
}

export const exercisesData: ExerciseData[] = [
  {
    id: 'cervical-stretch',
    name: 'Alongamento Cervical',
    category: 'Cervical',
    durationSeconds: 300,
    difficulty: 'Fácil',
    icon: '🧘‍♀️',
    description: 'Exercício suave para relaxar a região do pescoço e aliviar a tensão acumulada durante o dia de trabalho.',
    benefits: ['Reduz tensão no pescoço', 'Melhora mobilidade cervical', 'Alivia dores de cabeça tensionais', 'Relaxa a musculatura profunda'],
    muscles: ['Esternocleidomastóideo', 'Trapézio superior', 'Escalenos', 'Suboccipitais'],
    steps: [
      'Sente-se com a coluna ereta e os pés apoiados no chão',
      'Lentamente incline a cabeça para o lado direito, aproximando a orelha ao ombro',
      'Mantenha a posição por 20-30 segundos, sentindo o alongamento',
      'Retorne ao centro devagar e sem pressa',
      'Repita para o lado esquerdo',
      'Faça 3 repetições para cada lado',
    ],
  },
  {
    id: 'shoulder-rotation',
    name: 'Rotação de Ombros',
    category: 'Cervical',
    durationSeconds: 180,
    difficulty: 'Fácil',
    icon: '💆‍♂️',
    description: 'Movimento circular para aliviar tensão nos ombros e parte superior das costas, ideal após longas horas na mesa.',
    benefits: ['Alivia tensão nos ombros', 'Melhora circulação local', 'Reduz rigidez muscular', 'Previne lesões por esforço repetitivo'],
    muscles: ['Trapézio', 'Deltoides', 'Romboides', 'Serrátil anterior'],
    steps: [
      'Fique em pé ou sentado com a coluna ereta',
      'Role os ombros para frente em círculos amplos e lentos por 30 segundos',
      'Pause e respire profundamente por 5 segundos',
      'Role os ombros para trás por 30 segundos',
      'Repita o ciclo 3 vezes completas',
    ],
  },
  {
    id: 'lumbar-bridge',
    name: 'Ponte Lombar',
    category: 'Lombar',
    durationSeconds: 480,
    difficulty: 'Médio',
    icon: '🏋️‍♀️',
    description: 'Exercício de fortalecimento para a região inferior das costas e glúteos, essencial para a saúde da coluna lombar.',
    benefits: ['Fortalece região lombar', 'Ativa e fortalece glúteos', 'Estabiliza a coluna', 'Reduz dor lombar crônica'],
    muscles: ['Glúteo máximo', 'Isquiotibiais', 'Eretor da espinha', 'Transverso abdominal'],
    steps: [
      'Deite-se de costas com os joelhos dobrados e pés no chão',
      'Posicione os pés na largura do quadril, próximos ao glúteo',
      'Contraia o abdômen e os glúteos simultaneamente',
      'Eleve o quadril até formar uma linha reta do ombro ao joelho',
      'Mantenha por 3-5 segundos no topo da contração',
      'Desça lentamente e repita 12-15 vezes',
    ],
  },
  {
    id: 'cat-cow',
    name: 'Cat-Cow Stretch',
    category: 'Lombar',
    durationSeconds: 360,
    difficulty: 'Fácil',
    icon: '🐱',
    description: 'Movimento fluido que melhora a flexibilidade e mobilidade de toda a coluna vertebral, perfeito para iniciar o dia.',
    benefits: ['Mobiliza toda a coluna', 'Melhora flexibilidade geral', 'Alivia tensão lombar', 'Aquece a musculatura paravertebral'],
    muscles: ['Eretor da espinha', 'Multífido', 'Reto abdominal', 'Iliopsoas'],
    steps: [
      'Posicione-se em quatro apoios: mãos e joelhos no chão',
      'Mãos diretamente abaixo dos ombros, joelhos abaixo do quadril',
      'Inspire: arqueie as costas para baixo, levante a cabeça e o cóccix (posição Vaca)',
      'Expire: curve as costas para cima, abaixe a cabeça (posição Gato)',
      'Mova-se suavemente e de forma controlada entre as duas posições',
      'Repita 10-15 ciclos completos respirando profundamente',
    ],
  },
  {
    id: 'thoracic-rotation',
    name: 'Torção Sentada',
    category: 'Torácica',
    durationSeconds: 420,
    difficulty: 'Médio',
    icon: '🌀',
    description: 'Rotação controlada para melhorar a mobilidade da coluna torácica e aliviar tensão nas costas.',
    benefits: ['Melhora rotação torácica', 'Alivia tensão nas costas', 'Melhora postura global', 'Aumenta amplitude de movimento'],
    muscles: ['Oblíquos abdominais', 'Multífido torácico', 'Romboides', 'Serrátil anterior'],
    steps: [
      'Sente-se ereto em uma cadeira firme ou no chão com pernas cruzadas',
      'Coloque a mão direita no joelho esquerdo para apoio',
      'A mão esquerda atrás de você, levemente apoiada no chão',
      'Gire o tronco para a esquerda lentamente ao expirar',
      'Mantenha por 20-30 segundos, respirando normalmente',
      'Retorne ao centro e repita para o lado direito — 3 séries cada',
    ],
  },
  {
    id: 'thoracic-extension',
    name: 'Extensão Torácica',
    category: 'Torácica',
    durationSeconds: 300,
    difficulty: 'Fácil',
    icon: '⬆️',
    description: 'Abertura do peito e extensão da coluna torácica para combater o encurvamento postural causado pelo uso de computadores.',
    benefits: ['Abre e expande o peito', 'Corrige postura cifótica', 'Reduz dor torácica', 'Melhora respiração'],
    muscles: ['Romboides', 'Trapézio médio e inferior', 'Eretores torácicos', 'Peitoral maior'],
    steps: [
      'Sente-se na beira de uma cadeira com o encosto firme atrás de você',
      'Entrelace os dedos atrás da cabeça com os cotovelos abertos',
      'Lentamente incline-se para trás, arqueando suavemente as costas na cadeira',
      'Mantenha por 15-20 segundos, respirando profundamente pelo peito',
      'Retorne à posição inicial com controle',
      'Repita 5-8 vezes',
    ],
  },
];
