import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { useAuth } from './auth/AuthContext';

export interface UserProfile {
  name: string;
  email: string;
  weight: number;
  height: number;
  age: number;
  goal: string;
  avatarInitials: string;
  memberSince: string;
  avatarImage?: string;
}

export interface PostureRecord {
  date: string;
  score: number;
  cervical: number;
  toracica: number;
  lombar: number;
  alerts: number;
  exercises: number;
  sittingTime: number;
}

export interface CompletedExercise {
  exerciseId: string;
  completedAt: string;
  durationSeconds: number;
}

export interface AppSettings {
  notificationsEnabled: boolean;
  notifFrequency: 'baixa' | 'media' | 'alta';
  dataSharing: boolean;
  wellbeingReminders: boolean;
  stretchReminders: boolean;
}

export interface UserData {
  profile: UserProfile;
  postureHistory: PostureRecord[];
  completedExercises: CompletedExercise[];
  settings: AppSettings;
}

interface AppContextType {
  userData: UserData | null;
  isLoading: boolean;
  updateProfile: (profile: Partial<UserProfile>) => void;
  completeExercise: (exerciseId: string, durationSeconds: number) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  getTodayRecord: () => PostureRecord;
  updateTodayScore: (score: number, alerts?: number) => void;
  getWeeklyData: () => PostureRecord[];
  getMonthlyData: () => PostureRecord[];
  getTotalExercisesCompleted: () => number;
  getStreakDays: () => number;
}

const AppContext = createContext<AppContextType | null>(null);

function getDataKey(userId: string) {
  return `pc_data_${userId}`;
}

function generateInitialHistory(): PostureRecord[] {
  const history: PostureRecord[] = [];
  const today = new Date();
  for (let i = 29; i >= 1; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const progress = (30 - i) / 30;
    const base = 52 + progress * 30;
    const jitter = () => Math.round(Math.random() * 12 - 6);
    history.push({
      date: d.toISOString().split('T')[0],
      score: Math.min(95, Math.max(38, Math.round(base + jitter()))),
      cervical: Math.min(95, Math.max(38, Math.round(base - 8 + jitter()))),
      toracica: Math.min(95, Math.max(38, Math.round(base + 6 + jitter()))),
      lombar: Math.min(95, Math.max(38, Math.round(base + jitter()))),
      alerts: Math.max(0, Math.round(16 - progress * 12 + Math.random() * 6)),
      exercises: Math.round(Math.random() * 3),
      sittingTime: Math.round((3.5 + Math.random() * 4.5) * 10) / 10,
    });
  }
  return history;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .slice(0, 2)
    .map(n => n[0])
    .join('')
    .toUpperCase();
}

const defaultSettings: AppSettings = {
  notificationsEnabled: true,
  notifFrequency: 'media',
  dataSharing: false,
  wellbeingReminders: true,
  stretchReminders: true,
};

export function AppProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setUserData(null);
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    const key = getDataKey(user.id);
    const stored = localStorage.getItem(key);
    if (stored) {
      try {
        setUserData(JSON.parse(stored));
      } catch {
        localStorage.removeItem(key);
      }
    } else {
      const initial: UserData = {
        profile: {
          name: user.name,
          email: user.email,
          weight: 70,
          height: 1.70,
          age: 30,
          goal: 'Melhorar postura e reduzir dores nas costas',
          avatarInitials: getInitials(user.name),
          memberSince: new Date().toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }),
        },
        postureHistory: generateInitialHistory(),
        completedExercises: [],
        settings: defaultSettings,
      };
      localStorage.setItem(key, JSON.stringify(initial));
      setUserData(initial);
    }
    setIsLoading(false);
  }, [user]);

  const save = useCallback((data: UserData) => {
    if (!user) return;
    localStorage.setItem(getDataKey(user.id), JSON.stringify(data));
    setUserData({ ...data });
  }, [user]);

  const updateProfile = useCallback((profile: Partial<UserProfile>) => {
    if (!userData) return;
    const updated = { ...userData, profile: { ...userData.profile, ...profile } };
    if (profile.name) updated.profile.avatarInitials = getInitials(profile.name);
    save(updated);
  }, [userData, save]);

  const completeExercise = useCallback((exerciseId: string, durationSeconds: number) => {
    if (!userData) return;
    const today = new Date().toISOString().split('T')[0];
    const newRecord: CompletedExercise = {
      exerciseId,
      completedAt: new Date().toISOString(),
      durationSeconds,
    };
    const updatedHistory = userData.postureHistory.map(r =>
      r.date === today ? { ...r, exercises: r.exercises + 1 } : r
    );
    if (!updatedHistory.find(r => r.date === today)) {
      updatedHistory.push({ date: today, score: 75, cervical: 65, toracica: 82, lombar: 78, alerts: 0, exercises: 1, sittingTime: 0 });
    }
    save({ ...userData, completedExercises: [...userData.completedExercises, newRecord], postureHistory: updatedHistory });
  }, [userData, save]);

  const updateSettings = useCallback((settings: Partial<AppSettings>) => {
    if (!userData) return;
    save({ ...userData, settings: { ...userData.settings, ...settings } });
  }, [userData, save]);

  const getTodayRecord = useCallback((): PostureRecord => {
    const today = new Date().toISOString().split('T')[0];
    const fallback: PostureRecord = { date: today, score: 75, cervical: 65, toracica: 82, lombar: 78, alerts: 0, exercises: 0, sittingTime: 0 };
    if (!userData) return fallback;
    return userData.postureHistory.find(r => r.date === today) ?? fallback;
  }, [userData]);

  const updateTodayScore = useCallback((score: number, alerts?: number) => {
    if (!userData) return;
    const today = new Date().toISOString().split('T')[0];
    const existing = userData.postureHistory.find(r => r.date === today);
    let updatedHistory: PostureRecord[];
    if (existing) {
      updatedHistory = userData.postureHistory.map(r =>
        r.date === today ? { ...r, score, ...(alerts !== undefined ? { alerts } : {}) } : r
      );
    } else {
      updatedHistory = [...userData.postureHistory, { date: today, score, cervical: 65, toracica: 82, lombar: 78, alerts: alerts ?? 0, exercises: 0, sittingTime: 0 }];
    }
    save({ ...userData, postureHistory: updatedHistory });
  }, [userData, save]);

  const getWeeklyData = useCallback((): PostureRecord[] => {
    if (!userData) return [];
    const today = new Date();
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });
    return days.map(date => userData.postureHistory.find(r => r.date === date) ?? { date, score: 0, cervical: 0, toracica: 0, lombar: 0, alerts: 0, exercises: 0, sittingTime: 0 });
  }, [userData]);

  const getMonthlyData = useCallback((): PostureRecord[] => {
    if (!userData) return [];
    const today = new Date();
    const weeks: PostureRecord[][] = [[], [], [], []];
    for (let i = 27; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const date = d.toISOString().split('T')[0];
      const record = userData.postureHistory.find(r => r.date === date);
      if (record) weeks[Math.floor((27 - i) / 7)].push(record);
    }
    return weeks.map((week, i) => {
      if (week.length === 0) return { date: `Sem ${i + 1}`, score: 0, cervical: 0, toracica: 0, lombar: 0, alerts: 0, exercises: 0, sittingTime: 0 };
      const avg = (arr: number[]) => Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
      return {
        date: `Sem ${i + 1}`,
        score: avg(week.map(r => r.score)),
        cervical: avg(week.map(r => r.cervical)),
        toracica: avg(week.map(r => r.toracica)),
        lombar: avg(week.map(r => r.lombar)),
        alerts: week.reduce((s, r) => s + r.alerts, 0),
        exercises: week.reduce((s, r) => s + r.exercises, 0),
        sittingTime: avg(week.map(r => r.sittingTime)),
      };
    });
  }, [userData]);

  const getTotalExercisesCompleted = useCallback(() => {
    return userData?.completedExercises.length ?? 0;
  }, [userData]);

  const getStreakDays = useCallback((): number => {
    if (!userData) return 0;
    let streak = 0;
    const today = new Date();
    for (let i = 0; i < 30; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const date = d.toISOString().split('T')[0];
      const record = userData.postureHistory.find(r => r.date === date);
      if (record && (record.exercises > 0 || record.score > 0)) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  }, [userData]);

  return (
    <AppContext.Provider value={{
      userData, isLoading, updateProfile, completeExercise, updateSettings,
      getTodayRecord, updateTodayScore, getWeeklyData, getMonthlyData,
      getTotalExercisesCompleted, getStreakDays
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppData() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppData must be used within AppProvider');
  return ctx;
}
