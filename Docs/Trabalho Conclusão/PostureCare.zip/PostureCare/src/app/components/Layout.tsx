import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Activity, Home, Zap, LineChart, User, Settings,
  AlignVerticalJustifyCenter, LogOut, Bell
} from 'lucide-react';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Button } from '@/app/components/ui/button';
import { useAuth } from './auth/AuthContext';
import { useAppData } from './AppContext';
import { toast } from 'sonner';

const navItems = [
  { path: '/dashboard', icon: Home, label: 'Início' },
  { path: '/monitoramento', icon: Activity, label: 'Monitorar' },
  { path: '/exercicios', icon: Zap, label: 'Exercícios' },
  { path: '/relatorios', icon: LineChart, label: 'Relatórios' },
  { path: '/perfil', icon: User, label: 'Perfil' },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const { userData } = useAppData();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  const handleLogout = () => {
    logout();
    toast.success('Sessão encerrada com sucesso.');
    navigate('/login');
  };

  const avatarInitials = userData?.profile.avatarInitials ?? user?.name?.slice(0, 2).toUpperCase() ?? 'PC';
  const displayName = userData?.profile.name ?? user?.name ?? 'Usuário';

  if (isMobile) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <header className="bg-card border-b border-border sticky top-0 z-30">
          <div className="px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <AlignVerticalJustifyCenter className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg">PostureCare</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="w-9 h-9">
                <Bell className="w-4 h-4" />
              </Button>
              <Avatar
                className="w-9 h-9 cursor-pointer"
                onClick={() => navigate('/perfil')}
              >
                {userData?.profile.avatarImage ? (
                  <img src={userData.profile.avatarImage} alt="avatar" className="object-cover w-full h-full rounded-full" />
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-sm">
                    {avatarInitials}
                  </AvatarFallback>
                )}
              </Avatar>
            </div>
          </div>
        </header>

        <main className="p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.18 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>

        <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-30 safe-area-pb">
          <div className="flex items-center justify-around px-2 py-2">
            {navItems.map(item => {
              const active = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all ${
                    active ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  <motion.div animate={{ scale: active ? 1.15 : 1 }} transition={{ type: 'spring', stiffness: 300 }}>
                    <item.icon className="w-5 h-5" />
                  </motion.div>
                  <span className="text-[10px] font-medium">{item.label}</span>
                  {active && (
                    <motion.div
                      layoutId="mobile-indicator"
                      className="absolute bottom-1 w-1 h-1 rounded-full bg-primary"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-64 bg-card border-r border-border flex flex-col fixed h-full z-20">
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg shadow-primary/20">
              <AlignVerticalJustifyCenter className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">PostureCare</h1>
              <p className="text-[11px] text-muted-foreground">Premium Health</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all relative group ${
                  active
                    ? 'bg-primary text-primary-foreground shadow-md shadow-primary/25'
                    : 'hover:bg-muted text-foreground'
                }`}
              >
                {active && (
                  <motion.div
                    layoutId="sidebar-indicator"
                    className="absolute inset-0 bg-primary rounded-xl"
                    style={{ zIndex: -1 }}
                  />
                )}
                <item.icon className="w-5 h-5 shrink-0" />
                <span className="font-medium text-sm">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border space-y-2">
          <button
            onClick={() => navigate('/perfil')}
            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted transition-colors cursor-pointer"
          >
            <Avatar className="w-9 h-9">
              {userData?.profile.avatarImage ? (
                <img src={userData.profile.avatarImage} alt="avatar" className="object-cover w-full h-full rounded-full" />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-sm">
                  {avatarInitials}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="flex-1 min-w-0 text-left">
              <p className="font-medium text-sm truncate">{displayName}</p>
              <p className="text-[11px] text-muted-foreground truncate">{user?.email}</p>
            </div>
          </button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="w-full justify-start gap-3 text-muted-foreground hover:text-destructive"
          >
            <LogOut className="w-4 h-4" />
            Sair da conta
          </Button>
        </div>
      </aside>

      <main className="flex-1 ml-64 overflow-auto">
        <div className="max-w-6xl mx-auto p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
