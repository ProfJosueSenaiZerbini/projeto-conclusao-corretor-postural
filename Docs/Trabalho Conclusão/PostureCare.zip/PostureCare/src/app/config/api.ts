/**
 * URL base da API PostureCare.
 *
 * Para desenvolvimento local com o backend rodando:
 *   VITE_API_URL=http://localhost:3001  (no arquivo .env da raiz do frontend)
 *
 * Para produção:
 *   VITE_API_URL=https://api.seu-dominio.com
 *
 * Se VITE_API_URL não estiver definida, o app usa autenticação local (localStorage)
 * como fallback — útil para demonstração sem backend.
 */
export const API_BASE_URL: string | null = import.meta.env.VITE_API_URL ?? null;

export const API_TIMEOUT_MS = 8000;

export function isApiConfigured(): boolean {
  return typeof API_BASE_URL === 'string' && API_BASE_URL.trim().length > 0;
}

/** Monta a URL completa de uma rota da API */
export function apiUrl(path: string): string {
  const base = (API_BASE_URL ?? '').replace(/\/$/, '');
  return `${base}${path}`;
}

/** Chave do token JWT no localStorage */
export const JWT_STORAGE_KEY = 'pc_jwt';

/** Decodifica o payload do JWT sem verificar assinatura (validação é no backend) */
export function decodeJWTPayload(token: string): { id: string; email: string; name: string; exp: number } | null {
  try {
    const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(base64));
  } catch {
    return null;
  }
}

/** Verifica se o token ainda é válido (não expirado) */
export function isTokenValid(token: string): boolean {
  const payload = decodeJWTPayload(token);
  if (!payload) return false;
  return payload.exp * 1000 > Date.now();
}
