
PostureCare 🧍‍♂️📡

Faixa Corretora de Postura Inteligente — Trabalho de Conclusão de Curso (TCC) em Desenvolvimento de Sistemas, desenvolvido para apresentação em feira científica (FEBRACE).

Somos um grupo de alunos e este é o sistema web que acompanha o nosso protótipo físico: uma faixa vestível com sensor de ângulo que identifica, em tempo real, se a postura da pessoa está correta ou incorreta, dispara alertas e gera histórico/relatórios de uso.

Este README explica, passo a passo, como instalar e rodar o projeto — tanto para quem só quer ver a tela funcionando (modo offline, sem precisar configurar nada) quanto para quem quer rodar o sistema completo com o backend real e banco de dados.

📚 Sumário
Visão geral da arquitetura
O que você precisa ter instalado
Modo rápido: só o frontend (offline)
Modo completo: frontend + backend + banco de dados
Estrutura de pastas
Scripts disponíveis
Variáveis de ambiente
Gerando a versão de produção (build)
Problemas comuns (troubleshooting)
Tecnologias usadas
🏗 Visão geral da arquitetura

O projeto é dividido em duas partes que rodam separadamente:

PostureCare/
├── src/            ← FRONTEND (React + TypeScript + Vite + Tailwind)
├── backend/         ← BACKEND (Node.js + Express + MongoDB + JWT)
└── ...
O frontend é quem você vê na tela: login, dashboard, monitoramento, exercícios, relatórios.
O backend é uma API que guarda os usuários cadastrados no banco de dados (MongoDB) e cuida do login/autenticação com JWT.

O ponto mais importante para quem vai rodar o projeto: o frontend funciona sozinho, mesmo sem o backend ligado. Ele foi feito com um "modo offline" — se a variável VITE_API_URL não estiver configurada, ele salva tudo (usuários, sessão) no localStorage do próprio navegador. Isso foi pensado para facilitar demonstrações na feira, caso não tenhamos internet ou o servidor esteja fora do ar no dia da apresentação.

✅ O que você precisa ter instalado
Ferramenta	Para quê	Link
Node.js (versão 18 ou superior)	Rodar o frontend e o backend	https://nodejs.org
npm (já vem junto com o Node)	Instalar as dependências	—
MongoDB (só se for rodar o backend real)	Guardar os usuários cadastrados	Local: https://www.mongodb.com/try/download/community
Ou na nuvem (grátis): https://www.mongodb.com/cloud/atlas
Git (opcional)	Clonar/versionar o projeto	https://git-scm.com

Para conferir se o Node está instalado, abra o terminal e digite:

bash
node -v
npm -v

Se aparecer um número de versão, está tudo certo.

⚡ Modo rápido: só o frontend (offline)

Esse é o jeito mais rápido de ver o sistema rodando — sem precisar instalar banco de dados nem configurar nada. É o modo que recomendamos para testar a interface rapidamente.

Passo 1 — Extrair/abrir a pasta do projeto

Extraia o .zip do projeto (ou clone o repositório) e abra a pasta no terminal:

bash
cd PostureCare
Passo 2 — Instalar as dependências
bash
npm install

Isso vai baixar todos os pacotes que o frontend usa (React, Tailwind, componentes de UI, etc.). Pode demorar alguns minutos na primeira vez.

Passo 3 — Rodar o servidor de desenvolvimento
bash
npm run dev

O terminal vai mostrar algo parecido com:

  VITE v6.x.x  ready in 400 ms

  ➜  Local:   http://localhost:5173/
Passo 4 — Abrir no navegador

Acesse http://localhost:5173 no navegador. A tela de login vai aparecer com o aviso "Modo offline — dados locais" — isso é esperado e significa que o sistema está funcionando 100% pelo navegador.

Você pode clicar em "Criar conta", preencher os dados e entrar normalmente. Tudo fica salvo no localStorage do navegador que você está usando.

💡 Dica: se você limpar os dados de navegação do navegador (ou testar em uma aba anônima), a conta criada no modo offline vai "desaparecer", porque ela só existe naquele navegador.

🔗 Modo completo: frontend + backend + banco de dados

Esse é o modo "de verdade" — com a API rodando, os usuários salvos no MongoDB e senhas protegidas com criptografia (bcrypt), exatamente como o sistema funcionaria em produção.

Passo 1 — Preparar o banco de dados MongoDB

Você tem duas opções:

Opção A — MongoDB local (instalado no seu computador) Instale o MongoDB Community Server e deixe o serviço rodando. Por padrão, ele fica disponível em mongodb://127.0.0.1:27017.

Opção B — MongoDB Atlas (nuvem, mais fácil e gratuito)

Crie uma conta em https://www.mongodb.com/cloud/atlas
Crie um cluster gratuito (M0)
Em "Database Access", crie um usuário com senha
Em "Network Access", libere o seu IP (ou 0.0.0.0/0 para testes)
Clique em "Connect" → "Drivers" e copie a connection string (algo como mongodb+srv://usuario:senha@cluster0.xxxxx.mongodb.net/)
Passo 2 — Configurar as variáveis de ambiente do backend

Dentro da pasta backend/, copie o arquivo de exemplo:

bash
cd backend
cp .env.example .env

Abra o arquivo .env recém-criado e preencha:

env
MONGO_URI=mongodb://127.0.0.1:27017/posturecare
JWT_SECRET=uma_string_bem_grande_e_aleatoria_com_32_caracteres_ou_mais
PORT=3001
FRONTEND_URL=http://localhost:5173

⚠️ Importante: o JWT_SECRET precisa ter pelo menos 32 caracteres, senão o servidor recusa iniciar (é uma proteção de segurança que colocamos de propósito). Para gerar um valor aleatório rapidamente, rode:

bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

e cole o resultado no JWT_SECRET.

Passo 3 — Instalar as dependências do backend e iniciar

Ainda dentro da pasta backend/:

bash
npm install
npm run dev

Se tudo estiver certo, o terminal mostra:

✅  MongoDB conectado

🚀  PostureCare API → http://localhost:3001

📋  Endpoints:
    POST  /api/auth/register
    POST  /api/auth/login
    POST  /api/auth/reset-password
    GET   /api/auth/me        (requer Bearer token)
    GET   /api/health

Deixe esse terminal aberto — o backend precisa continuar rodando.

Passo 4 — Configurar o frontend para falar com o backend

Volte para a pasta raiz do projeto (saia da pasta backend):

bash
cd ..

Copie o arquivo de exemplo de variáveis de ambiente do frontend:

bash
cp .env.example .env

O conteúdo já vem certo por padrão:

env
VITE_API_URL=http://localhost:3001

Isso diz ao frontend: "existe uma API rodando em localhost:3001, use ela em vez do modo offline".

Passo 5 — Instalar dependências do frontend e rodar

Em outro terminal (deixe o backend rodando no primeiro):

bash
npm install
npm run dev

Acesse http://localhost:5173. Agora a tela de login deve mostrar o selo "API conectada" (verde) em vez de "Modo offline". Ao criar uma conta, ela será salva de verdade no MongoDB, com a senha protegida por criptografia.

Resumindo os dois terminais que precisam ficar abertos:
Terminal	Pasta	Comando	Porta
1	backend/	npm run dev	3001
2	raiz do projeto	npm run dev	5173
📁 Estrutura de pastas
PostureCare/
├── backend/
│   ├── server.ts          ← toda a API (rotas de login/cadastro, conexão Mongo, JWT)
│   ├── .env.example        ← modelo das variáveis de ambiente do backend
│   └── package.json
│
├── src/
│   ├── main.tsx             ← ponto de entrada do React
│   ├── app/
│   │   ├── App.tsx           ← rotas da aplicação
│   │   ├── config/
│   │   │   └── api.ts          ← URL base da API, JWT, funções auxiliares
│   │   ├── components/
│   │   │   ├── auth/
│   │   │   │   └── AuthContext.tsx  ← login, cadastro, logout, recuperação de senha
│   │   │   ├── Layout.tsx        ← menu/navegação do sistema logado
│   │   │   └── ui/               ← biblioteca de componentes visuais (botão, card, input...)
│   │   └── pages/
│   │       ├── LoginPage.tsx       ← tela de login/cadastro
│   │       ├── DashboardPage.tsx   ← painel principal com status da postura
│   │       ├── MonitoringPage.tsx  ← leitura em tempo real do sensor
│   │       ├── ExercisesPage.tsx   ← exercícios recomendados
│   │       ├── ReportsPage.tsx     ← relatórios e exportação
│   │       └── ProfilePage.tsx     ← dados do usuário
│   └── styles/                  ← tema de cores, tipografia (Tailwind)
│
├── .env.example              ← modelo das variáveis de ambiente do frontend
├── package.json
└── vite.config.ts
🧰 Scripts disponíveis

Na raiz do projeto (frontend):

Comando	O que faz
npm run dev	Inicia o frontend em modo desenvolvimento (localhost:5173)
npm run build	Gera a versão de produção otimizada, na pasta dist/

Dentro de backend/:

Comando	O que faz
npm run dev	Inicia a API em modo desenvolvimento, reiniciando sozinha a cada alteração
npm run build	Compila o TypeScript da API para JavaScript, na pasta dist/
npm run start	Roda a API já compilada (usado em produção, depois do build)
🔐 Variáveis de ambiente
Frontend (.env na raiz)
Variável	Obrigatória?	O que é
VITE_API_URL	Não	URL da API backend. Se estiver vazia/ausente, o app usa o modo offline (localStorage).
Backend (backend/.env)
Variável	Obrigatória?	O que é
MONGO_URI	Sim	String de conexão do MongoDB
JWT_SECRET	Sim	Chave secreta para assinar os tokens de login (mín. 32 caracteres)
PORT	Não (padrão 3001)	Porta onde a API vai rodar
FRONTEND_URL	Não	Endereço(s) do frontend liberados no CORS, separados por vírgula

Os arquivos .env nunca devem ser enviados para o GitHub — eles já devem estar listados no .gitignore. Só o .env.example (sem valores reais/sensíveis) deve ser versionado.

📦 Gerando a versão de produção (build)

Quando o projeto estiver pronto para ser apresentado/publicado (ex.: em um servidor da escola, Vercel, Render etc.), gere a versão final assim:

Frontend:

bash
npm run build

Isso cria a pasta dist/ com os arquivos otimizados (HTML, CSS, JS minificados), prontos para serem hospedados em qualquer servidor de arquivos estáticos.

Backend:

bash
cd backend
npm run build
npm run start

Isso compila o server.ts para JavaScript puro (pasta backend/dist/) e inicia a API a partir do código já compilado — mais rápido e mais adequado para produção do que rodar com tsx watch.

🛠 Problemas comuns (troubleshooting)

"❌ MONGO_URI não definida no .env" Você esqueceu de criar o arquivo backend/.env (copie o backend/.env.example e preencha).

"❌ JWT_SECRET ausente ou muito curta" O JWT_SECRET no backend/.env precisa ter 32 caracteres ou mais. Gere um novo com o comando mostrado no Passo 2 do modo completo.

A tela de login mostra "Modo offline" mesmo com o backend rodando Confira se você criou o arquivo .env na raiz do projeto (não dentro de backend/) com VITE_API_URL=http://localhost:3001, e reinicie o npm run dev do frontend (o Vite só lê o .env quando o servidor inicia).

Erro de CORS no console do navegador Verifique se FRONTEND_URL no backend/.env inclui o endereço exato que o frontend está usando (ex.: http://localhost:5173).

"EADDRINUSE" ou "porta já em uso" Alguma outra aplicação já está usando a porta 3001 (backend) ou 5173 (frontend). Feche o processo que está usando a porta ou mude o valor de PORT no .env.

npm install muito lento ou travando Confira sua conexão com a internet — o projeto usa bastante biblioteca de UI (Radix, shadcn, MUI, etc.), então a primeira instalação pode levar alguns minutos.

🧪 Tecnologias usadas

Frontend

React 18 + TypeScript
Vite (build/dev server)
Tailwind CSS + shadcn/ui (componentes de interface)
Framer Motion (motion/react) — animações
React Router — navegação entre páginas
Recharts — gráficos do dashboard/relatórios
Sonner — notificações (toasts)
Lucide React — ícones

Backend

Node.js + Express
TypeScript
MongoDB + Mongoose (banco de dados)
JWT (jsonwebtoken) — autenticação
bcryptjs — criptografia de senha
CORS — controle de origem das requisições