#pragma once

// Servidor BLE com o contrato do app (mobile/src/services/bleService.js):
// nome SIME-WEARABLE, serviço e característica fixos, NOTIFY com JSON {"t":ms,"a":graus}.

#include <Arduino.h>

namespace bleSime {

void iniciar();

bool conectado();

// Notifica {"t":…,"a":…}; t = ms desde a conexão BLE atual, a com 1 casa decimal.
// Não faz nada sem conexão.
void publicar(float angulo);

}  // namespace bleSime
