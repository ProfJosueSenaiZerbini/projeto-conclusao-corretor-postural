#pragma once

// Lógica dos 30 s e acionamento do motor por PWM.
// Fora da faixa por 30 s seguidos → vibra 2 s → pausa 5 s → vibra 2 s → recomeça os 30 s.
// Ao voltar à faixa: zera a contagem e para o motor. Sem calibração: motor desligado.

#include <Arduino.h>

namespace vibracao {

// Configura o PWM com o motor desligado. Chamar primeiro no setup().
void iniciar();

// Chamada a cada amostra (100 Hz).
void atualizar(bool dentroDaFaixa, bool habilitado, uint32_t agoraMs);

}  // namespace vibracao
