#include <Wire.h>

#include "config.h"
#include "mpu6050.h"

namespace {

constexpr uint8_t REG_CONFIG = 0x1A;
constexpr uint8_t REG_GYRO_CONFIG = 0x1B;
constexpr uint8_t REG_ACCEL_CONFIG = 0x1C;
constexpr uint8_t REG_ACCEL_XOUT_H = 0x3B;
constexpr uint8_t REG_PWR_MGMT_1 = 0x6B;
constexpr uint8_t REG_WHO_AM_I = 0x75;

constexpr float LSB_POR_G = 16384.0f;     // escala ±2 g
constexpr float LSB_POR_GRAU_S = 131.0f;  // escala ±250 °/s

bool escrever(uint8_t reg, uint8_t valor) {
  Wire.beginTransmission(MPU_ENDERECO);
  Wire.write(reg);
  Wire.write(valor);
  return Wire.endTransmission() == 0;
}

bool lerBytes(uint8_t reg, uint8_t *destino, uint8_t quantidade) {
  Wire.beginTransmission(MPU_ENDERECO);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;  // repeated start
  if (Wire.requestFrom((uint8_t)MPU_ENDERECO, quantidade) != quantidade) return false;
  for (uint8_t i = 0; i < quantidade; i++) destino[i] = Wire.read();
  return true;
}

int16_t paraInt16(const uint8_t *bytes) {
  return (int16_t)((bytes[0] << 8) | bytes[1]);  // big-endian
}

}  // namespace

namespace mpu6050 {

bool iniciar() {
  Wire.begin(PINO_SDA, PINO_SCL);
  Wire.setClock(I2C_FREQUENCIA_HZ);

  bool ok = escrever(REG_PWR_MGMT_1, 0x01);       // sai do sleep; relógio = PLL do giroscópio X
  delay(100);
  ok = escrever(REG_CONFIG, 0x03) && ok;          // DLPF ~44 Hz
  ok = escrever(REG_GYRO_CONFIG, 0x00) && ok;     // ±250 °/s
  ok = escrever(REG_ACCEL_CONFIG, 0x00) && ok;    // ±2 g
  return ok;
}

uint8_t lerWhoAmI() {
  uint8_t valor = 0;
  if (!lerBytes(REG_WHO_AM_I, &valor, 1)) return 0;
  return valor;
}

bool ler(LeituraMpu &saida) {
  uint8_t b[14];  // ACCEL XYZ (6), TEMP (2), GYRO XYZ (6)
  if (!lerBytes(REG_ACCEL_XOUT_H, b, sizeof b)) return false;

  saida.ax = paraInt16(&b[0]) / LSB_POR_G;
  saida.ay = paraInt16(&b[2]) / LSB_POR_G;
  saida.az = paraInt16(&b[4]) / LSB_POR_G;
  saida.gx = paraInt16(&b[8]) / LSB_POR_GRAU_S;
  saida.gy = paraInt16(&b[10]) / LSB_POR_GRAU_S;
  saida.gz = paraInt16(&b[12]) / LSB_POR_GRAU_S;
  return true;
}

}  // namespace mpu6050
