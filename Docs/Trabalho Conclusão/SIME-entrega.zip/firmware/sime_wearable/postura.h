#pragma once

// Filtro complementar (α = 0,98), calibração pelo BOOT e ângulo de inclinação total
// em relação à postura de referência: acos entre o vetor de gravidade atual e o de referência.

#include <Arduino.h>

#include "mpu6050.h"

namespace postura {

void iniciar();

// Atualiza o filtro com uma amostra (dt em segundos) e, se estiver calibrando, acumula a média.
void atualizar(const LeituraMpu &medida, float dt, uint32_t agoraMs);

// Começa a calibração: a pessoa fica parada por DURACAO_CALIBRACAO_MS na postura de referência.
// Mede a referência de gravidade e o desvio do giroscópio.
void iniciarCalibracao(uint32_t agoraMs);

bool calibrando();
bool calibrado();

// Inclinação total em graus (0 a 180). Só tem sentido com calibrado() verdadeiro.
float angulo();

}  // namespace postura
