#include <math.h>

#include "config.h"
#include "postura.h"

namespace {

// Estado do filtro (graus)
float roll = 0.0f;
float pitch = 0.0f;
bool filtroIniciado = false;

// Desvio do giroscópio (°/s), medido na calibração
float desvioGx = 0.0f;
float desvioGy = 0.0f;

// Referência: vetor de gravidade unitário na postura calibrada
float refX = 0.0f;
float refY = 0.0f;
float refZ = 1.0f;
bool temReferencia = false;

float anguloAtual = 0.0f;

// Calibração em andamento
bool emCalibracao = false;
uint32_t calibracaoInicioMs = 0;
double somaAx, somaAy, somaAz, somaGx, somaGy;
uint32_t amostrasCalibracao = 0;

float rollDoAcelerometro(float ay, float az) {
  return atan2f(ay, az) * RAD_TO_DEG;
}

float pitchDoAcelerometro(float ax, float ay, float az) {
  return atan2f(-ax, sqrtf(ay * ay + az * az)) * RAD_TO_DEG;
}

void finalizarCalibracao() {
  emCalibracao = false;

  if (amostrasCalibracao == 0) {
    Serial.println("[POSTURA] calibração sem amostras; tente de novo");
    return;
  }

  const float ax = somaAx / amostrasCalibracao;
  const float ay = somaAy / amostrasCalibracao;
  const float az = somaAz / amostrasCalibracao;
  const float norma = sqrtf(ax * ax + ay * ay + az * az);
  if (norma < 0.5f) {  // em repouso deveria ser ~1 g
    Serial.printf("[POSTURA] calibração descartada: |a| = %.2f g\n", norma);
    return;
  }

  desvioGx = somaGx / amostrasCalibracao;
  desvioGy = somaGy / amostrasCalibracao;

  refX = ax / norma;
  refY = ay / norma;
  refZ = az / norma;

  // Parado, o acelerômetro dá a orientação: o filtro recomeça na referência
  roll = rollDoAcelerometro(ay, az);
  pitch = pitchDoAcelerometro(ax, ay, az);
  filtroIniciado = true;
  anguloAtual = 0.0f;
  temReferencia = true;

  Serial.printf("[POSTURA] calibrado: desvio gx=%.2f gy=%.2f °/s, |a|=%.2f g\n", desvioGx, desvioGy, norma);
}

}  // namespace

namespace postura {

void iniciar() {
  filtroIniciado = false;
  temReferencia = false;
  emCalibracao = false;
  desvioGx = 0.0f;
  desvioGy = 0.0f;
  anguloAtual = 0.0f;
}

void iniciarCalibracao(uint32_t agoraMs) {
  emCalibracao = true;
  calibracaoInicioMs = agoraMs;
  somaAx = somaAy = somaAz = somaGx = somaGy = 0.0;
  amostrasCalibracao = 0;
  Serial.println("[POSTURA] calibrando: fique parado na postura de referência");
}

bool calibrando() {
  return emCalibracao;
}

bool calibrado() {
  return temReferencia;
}

float angulo() {
  return anguloAtual;
}

void atualizar(const LeituraMpu &m, float dt, uint32_t agoraMs) {
  // ── Filtro complementar ──
  const float rollAcel = rollDoAcelerometro(m.ay, m.az);
  const float pitchAcel = pitchDoAcelerometro(m.ax, m.ay, m.az);

  if (!filtroIniciado) {
    roll = rollAcel;
    pitch = pitchAcel;
    filtroIniciado = true;
  } else {
    // roll vai de -180 a 180: evita misturar 179° com -179°
    const float diferenca = rollAcel - roll;
    if (diferenca > 180.0f) roll += 360.0f;
    else if (diferenca < -180.0f) roll -= 360.0f;

    roll = ALFA * (roll + (m.gx - desvioGx) * dt) + (1.0f - ALFA) * rollAcel;
    pitch = ALFA * (pitch + (m.gy - desvioGy) * dt) + (1.0f - ALFA) * pitchAcel;
  }

  // ── Calibração ──
  if (emCalibracao) {
    somaAx += m.ax;
    somaAy += m.ay;
    somaAz += m.az;
    somaGx += m.gx;
    somaGy += m.gy;
    amostrasCalibracao++;
    if (agoraMs - calibracaoInicioMs >= DURACAO_CALIBRACAO_MS) finalizarCalibracao();
  }

  // ── Inclinação total em relação à referência ──
  if (temReferencia && !emCalibracao) {
    const float r = roll * DEG_TO_RAD;
    const float p = pitch * DEG_TO_RAD;
    const float gx = -sinf(p);
    const float gy = sinf(r) * cosf(p);
    const float gz = cosf(r) * cosf(p);

    float produto = gx * refX + gy * refY + gz * refZ;
    if (produto > 1.0f) produto = 1.0f;
    if (produto < -1.0f) produto = -1.0f;
    anguloAtual = acosf(produto) * RAD_TO_DEG;
  }
}

}  // namespace postura
