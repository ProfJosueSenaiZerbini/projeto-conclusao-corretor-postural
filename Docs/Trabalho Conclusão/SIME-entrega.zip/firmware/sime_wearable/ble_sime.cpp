#include <BLE2902.h>
#include <BLEDevice.h>
#include <BLEServer.h>

#include "ble_sime.h"
#include "config.h"

namespace {

BLECharacteristic *caracteristica = nullptr;
volatile bool ligado = false;
volatile uint32_t conectadoEmMs = 0;

class CallbacksServidor : public BLEServerCallbacks {
  void onConnect(BLEServer *) override {
    conectadoEmMs = millis();  // t = 0 na conexão
    ligado = true;
    Serial.println("[BLE] conectado");
  }

  void onDisconnect(BLEServer *) override {
    ligado = false;
    Serial.println("[BLE] desconectado; anunciando de novo");
    BLEDevice::startAdvertising();
  }
};

}  // namespace

namespace bleSime {

void iniciar() {
  BLEDevice::init(BLE_NOME);
  BLEDevice::setMTU(BLE_MTU);

  BLEServer *servidor = BLEDevice::createServer();
  servidor->setCallbacks(new CallbacksServidor());

  BLEService *servico = servidor->createService(BLE_SERVICO_UUID);
  caracteristica = servico->createCharacteristic(BLE_CARACTERISTICA_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  caracteristica->addDescriptor(new BLE2902());  // CCCD: o app liga as notificações
  servico->start();

  BLEAdvertising *anuncio = BLEDevice::getAdvertising();
  anuncio->addServiceUUID(BLE_SERVICO_UUID);
  anuncio->setScanResponse(true);  // nome na resposta de scan (o app filtra pelo nome)
  BLEDevice::startAdvertising();

  Serial.println("[BLE] anunciando como " BLE_NOME);
}

bool conectado() {
  return ligado;
}

void publicar(float angulo) {
  if (!ligado || caracteristica == nullptr) return;

  char json[48];
  const unsigned long t = millis() - conectadoEmMs;
  const int tamanho = snprintf(json, sizeof json, "{\"t\":%lu,\"a\":%.1f}", t, angulo);
  if (tamanho <= 0 || tamanho >= (int)sizeof json) return;

  // Bytes do JSON em texto; o app recebe em base64 (react-native-ble-plx) e faz atob()
  caracteristica->setValue((uint8_t *)json, tamanho);
  caracteristica->notify();
}

}  // namespace bleSime
