#include "config.h"
#include "vibracao.h"

namespace {

enum class Estado { DENTRO, CONTANDO, VIBRA_1, PAUSA, VIBRA_2 };

Estado estado = Estado::DENTRO;
uint32_t marcoMs = 0;  // início da etapa atual
bool motorLigado = false;

void motor(bool ligar) {
  if (ligar == motorLigado) return;
  motorLigado = ligar;
  ledcWrite(PINO_MOTOR, ligar ? PWM_DUTY : 0);  // API do core ESP32 3.x
}

}  // namespace

namespace vibracao {

void iniciar() {
  ledcAttach(PINO_MOTOR, PWM_FREQUENCIA_HZ, PWM_RESOLUCAO_BITS);
  ledcWrite(PINO_MOTOR, 0);
  motorLigado = false;
  estado = Estado::DENTRO;
}

void atualizar(bool dentroDaFaixa, bool habilitado, uint32_t agoraMs) {
  // Sem calibração ou de volta à faixa: motor parado e contagem zerada
  if (!habilitado || dentroDaFaixa) {
    motor(false);
    estado = Estado::DENTRO;
    return;
  }

  switch (estado) {
    case Estado::DENTRO:  // acabou de sair da faixa
      estado = Estado::CONTANDO;
      marcoMs = agoraMs;
      break;

    case Estado::CONTANDO:
      if (agoraMs - marcoMs >= TEMPO_FORA_MS) {
        motor(true);
        estado = Estado::VIBRA_1;
        marcoMs = agoraMs;
      }
      break;

    case Estado::VIBRA_1:
      if (agoraMs - marcoMs >= DURACAO_VIBRACAO_MS) {
        motor(false);
        estado = Estado::PAUSA;
        marcoMs = agoraMs;  // pausa contada do fim do ciclo
      }
      break;

    case Estado::PAUSA:
      if (agoraMs - marcoMs >= PAUSA_MS) {
        motor(true);
        estado = Estado::VIBRA_2;
        marcoMs = agoraMs;
      }
      break;

    case Estado::VIBRA_2:
      if (agoraMs - marcoMs >= DURACAO_VIBRACAO_MS) {
        motor(false);
        estado = Estado::CONTANDO;  // continua fora: recomeça os 30 s a partir daqui
        marcoMs = agoraMs;
      }
      break;
  }
}

}  // namespace vibracao
