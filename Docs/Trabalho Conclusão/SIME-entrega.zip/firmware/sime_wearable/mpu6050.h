#pragma once

// MPU6050 lido por registradores via Wire (sem biblioteca externa).

#include <Arduino.h>

struct LeituraMpu {
  float ax, ay, az;  // aceleração, em g
  float gx, gy, gz;  // velocidade angular, em °/s
};

namespace mpu6050 {

// Configura o I2C e o sensor (±2 g, ±250 °/s, DLPF). false se o sensor não respondeu.
bool iniciar();

// Valor do registrador WHO_AM_I (0x68 no MPU6050; clones podem responder outro valor).
uint8_t lerWhoAmI();

// Lê acelerômetro e giroscópio em rajada. false se a leitura I2C falhou.
bool ler(LeituraMpu &saida);

}  // namespace mpu6050
