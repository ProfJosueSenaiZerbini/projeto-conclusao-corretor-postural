#pragma once

// Configuração do SIME-WEARABLE (ESP32 DevKit V1 + MPU6050 + motor pancake).
// Core ESP32 Arduino 3.x. Sem bibliotecas além do core (Wire e BLE).

#include <Arduino.h>

// ── Pinos ──────────────────────────────────────────────
constexpr uint8_t PINO_SDA = 21;
constexpr uint8_t PINO_SCL = 22;
constexpr uint8_t PINO_BOTAO = 0;   // BOOT (GPIO0), ativo em LOW; calibra a postura de referência
constexpr uint8_t PINO_MOTOR = 19;  // motor pancake 3 V direto no GPIO (sem MOSFET nem diodo)

// ── MPU6050 (GY-521) ───────────────────────────────────
constexpr uint8_t MPU_ENDERECO = 0x68;
constexpr uint32_t I2C_FREQUENCIA_HZ = 400000;

// ── Amostragem, filtro e calibração ────────────────────
constexpr uint32_t PERIODO_AMOSTRA_US = 10000;   // 100 Hz internos
constexpr uint8_t AMOSTRAS_POR_PUBLICACAO = 10;  // 10 Hz publicados por BLE
constexpr float ALFA = 0.98f;                    // filtro complementar
constexpr uint32_t DURACAO_CALIBRACAO_MS = 1000; // parado na postura de referência
constexpr uint32_t DEBOUNCE_MS = 50;

// ── Regra única (contada no firmware) ──────────────────
// Mesmos valores da regra criada por api/prisma/seed.js (a regra não é editável no sistema).
// Se mudar aqui, mude lá também, e vice-versa.
constexpr float ANGULO_MINIMO = 0.0f;
constexpr float ANGULO_MAXIMO = 20.0f;
constexpr uint32_t TEMPO_FORA_MS = 30000;        // 30 s seguidos fora da faixa
constexpr uint32_t DURACAO_VIBRACAO_MS = 2000;   // ciclo de vibração
constexpr uint32_t PAUSA_MS = 5000;              // contada do fim do 1º ciclo

// ── PWM do motor ───────────────────────────────────────
constexpr uint32_t PWM_FREQUENCIA_HZ = 5000;
constexpr uint8_t PWM_RESOLUCAO_BITS = 8;        // duty de 0 a 255
// definir na bancada. 0 = motor nunca liga (valor seguro até medir a corrente no GPIO19).
constexpr uint32_t PWM_DUTY = 0;

// ── BLE (contrato do app: mobile/src/services/bleService.js) ──
#define BLE_NOME "SIME-WEARABLE"
#define BLE_SERVICO_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CARACTERISTICA_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
// O JSON {"t":…,"a":…} passa de 20 bytes (MTU padrão 23 − 3); aceita negociar até 185.
constexpr uint16_t BLE_MTU = 185;
