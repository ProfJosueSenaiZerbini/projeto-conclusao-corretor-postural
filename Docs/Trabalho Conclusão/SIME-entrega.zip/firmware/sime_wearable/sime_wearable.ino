// SIME-WEARABLE — ESP32 DevKit V1 + MPU6050 + motor pancake no GPIO19.
// Amostra a 100 Hz, publica {"t":ms,"a":graus} por BLE a 10 Hz (só depois da calibração)
// e aciona a vibração pela regra única (0° a 20°, 30 s fora da faixa).
// Calibração: parado na postura de referência, apertar o BOOT (GPIO0).

#include "ble_sime.h"
#include "config.h"
#include "mpu6050.h"
#include "postura.h"
#include "vibracao.h"

uint32_t ultimaAmostraUs = 0;
uint8_t contadorPublicacao = 0;

// Botão BOOT com antirruído
bool botaoEstavel = HIGH;
bool botaoLido = HIGH;
uint32_t botaoMudouEmMs = 0;

// true só na borda de descida estável (apertou)
bool botaoApertado(uint32_t agoraMs) {
  const bool leitura = digitalRead(PINO_BOTAO);
  if (leitura != botaoLido) {
    botaoLido = leitura;
    botaoMudouEmMs = agoraMs;
  }
  if (agoraMs - botaoMudouEmMs >= DEBOUNCE_MS && leitura != botaoEstavel) {
    botaoEstavel = leitura;
    return botaoEstavel == LOW;
  }
  return false;
}

void setup() {
  vibracao::iniciar();  // primeiro: motor desligado o quanto antes

  Serial.begin(115200);
  pinMode(PINO_BOTAO, INPUT_PULLUP);

  if (!mpu6050::iniciar()) Serial.println("[MPU] sem resposta no I2C (confira SDA 21, SCL 22, 3V3)");
  Serial.printf("[MPU] WHO_AM_I = 0x%02X (esperado 0x68)\n", mpu6050::lerWhoAmI());

  postura::iniciar();
  bleSime::iniciar();

  Serial.println("[SIME] pronto. Parado na postura de referência, aperte BOOT para calibrar.");
  ultimaAmostraUs = micros();
}

void loop() {
  const uint32_t agoraUs = micros();
  if (agoraUs - ultimaAmostraUs < PERIODO_AMOSTRA_US) return;
  const float dt = (agoraUs - ultimaAmostraUs) / 1000000.0f;
  ultimaAmostraUs = agoraUs;
  const uint32_t agoraMs = millis();

  if (botaoApertado(agoraMs) && !postura::calibrando()) postura::iniciarCalibracao(agoraMs);

  LeituraMpu medida;
  if (!mpu6050::ler(medida)) {
    Serial.println("[MPU] falha de leitura");
    return;
  }
  postura::atualizar(medida, dt, agoraMs);

  // Sem calibração (ou calibrando): motor desligado e nada publicado
  const bool pronto = postura::calibrado() && !postura::calibrando();
  const float angulo = postura::angulo();
  vibracao::atualizar(angulo >= ANGULO_MINIMO && angulo <= ANGULO_MAXIMO, pronto, agoraMs);

  if (++contadorPublicacao >= AMOSTRAS_POR_PUBLICACAO) {
    contadorPublicacao = 0;
    if (pronto) bleSime::publicar(angulo);
  }
}
