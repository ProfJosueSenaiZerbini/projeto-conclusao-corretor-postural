# Firmware

Firmware do dispositivo vestível SIME-WEARABLE: mede a inclinação, decide e aciona a vibração
e publica as leituras por BLE para o app.

## Hardware

- ESP32 DevKit V1 (ESP-WROOM-32), gravada pelo micro-USB com o Arduino IDE.
- MPU6050 (GY-521): SDA GPIO21, SCL GPIO22, 3V3, endereço 0x68.
- Motor pancake 3 V 10 mm direto no GPIO19 (sem MOSFET nem diodo).
- Botão BOOT (GPIO0): calibra a postura de referência.
- LiPo 3,7 V 700 mAh + TP4056 ligado ao VIN.

## Gravar

1. Arduino IDE com o core ESP32 Arduino 3.x. Placa: "ESP32 Dev Module".
2. Abrir `sime_wearable/sime_wearable.ino` (a pasta tem o mesmo nome do sketch).
3. Sem bibliotecas além do core (Wire e BLE).
4. **Desconectar a bateria do VIN antes de ligar o USB** até confirmar no esquema da placa
   que o 5 V do USB não chega à saída do TP4056.
5. Monitor serial a 115200 baud: mostra o WHO_AM_I, a calibração e a conexão BLE.

## Uso

- Ao ligar, o firmware anuncia por BLE, mas não publica leituras e o motor não vibra.
- Parado na postura de referência, apertar o BOOT: por 1 s mede a referência de gravidade
  e o desvio do giroscópio. A confirmação é o app passar a receber leituras.
- Apertar o BOOT de novo refaz a calibração.

## Funcionamento

- Amostragem do MPU6050 a 100 Hz, por registradores (±2 g, ±250 °/s, DLPF).
- Filtro complementar com α = 0,98 (roll e pitch).
- Ângulo publicado: inclinação total em relação à referência, `acos` entre o vetor de gravidade
  atual e o de referência (0° a 180°, sem sinal).
- Regra única: dentro da faixa se 0° ≤ ângulo ≤ 20°. Fora por 30 s seguidos → vibra 2 s →
  pausa 5 s → vibra 2 s → recomeça os 30 s. Ao voltar à faixa, zera a contagem e para o motor.
  Sem calibração, o motor não vibra.
- Motor por PWM (5 kHz, 8 bits) com intensidade `PWM_DUTY`.

## Contrato BLE (o mesmo de `mobile/src/services/bleService.js`)

- Nome: `SIME-WEARABLE` (na resposta de scan).
- Serviço: `4fafc201-1fb5-459e-8fcc-c5c9c331914b`.
- Característica: `beb5483e-36e1-4688-b7f5-ea07361b26a8`, NOTIFY (com descritor 0x2902).
- Payload: JSON em texto `{"t":ms,"a":graus}` a 10 Hz, ângulo com 1 casa decimal.
  `t` conta a partir da conexão BLE atual; o servidor grava `iniciada_em + t`.
- O JSON passa de 20 bytes: o firmware aceita MTU até 185 (`BLEDevice::setMTU`).

## Valores da bancada (`sime_wearable/config.h`)

- `PWM_DUTY`: definir na bancada. Vem com 0 (motor nunca liga) até medir a corrente no GPIO19.

## Riscos para validar na bancada

- Motor direto no GPIO19: medir a corrente a 100% e no `PWM_DUTY` escolhido (o PWM reduz a
  média, não o pico), a tensão no GPIO19 e no 3V3, e observar reinícios ("Brownout detector")
  ou falhas de I2C/BLE durante a vibração. Sem diodo, o pico indutivo do motor volta ao pino.
- Bateria no VIN: o regulador de 3,3 V da placa precisa de folga na entrada; com a LiPo
  (3,7 V a 4,2 V) o 3V3 pode ficar abaixo de 3,3 V. Medir só com a bateria, com BLE e motor ligados.
- Vibração mexe com o acelerômetro: observar se o ângulo oscila perto de 20°.
- GY-521 de outro fabricante pode responder outro WHO_AM_I (ex.: 0x70).
- Conferir que o celular vê o nome SIME-WEARABLE e que as leituras chegam inteiras (MTU).
