# SIME — Base para o levantamento de requisitos

Este documento descreve o sistema SIME **como está implementado no código** (repositório `projeto_sime`,
26/11/2026). Serve de material de entrada para elaborar o documento de levantamento de requisitos.

> **Como usar com o Claude:** anexe este arquivo e peça, por exemplo:
> "Com base neste material, elabore o documento de levantamento de requisitos do SIME com: introdução e
> objetivo, escopo, partes interessadas e atores, requisitos funcionais, requisitos não funcionais, regras
> de negócio, casos de uso, modelo de dados, restrições e premissas. Mantenha os códigos RF/RNF/RN e não
> invente funções que não estão aqui."

---

## 1. Visão geral

- **Nome:** SIME — Sistema de monitoramento postural para prevenção de riscos ergonômicos no trabalho.
- **Problema:** trabalhadores passam longos períodos em postura inadequada (tronco inclinado), o que gera
  risco ergonômico. Não há medição contínua nem dados para o médico do trabalho e o gestor agirem.
- **Solução:** um dispositivo vestível mede a inclinação do tronco e vibra quando a pessoa fica fora da
  postura correta por tempo demais. As leituras vão por Bluetooth para um app no celular, que envia os dados
  para uma API na nuvem. O médico acompanha seus pacientes e emite laudos; o gestor vê indicadores
  agregados por setor.
- **Objetivos:**
  1. Alertar o trabalhador em tempo real (vibração) sobre postura inadequada prolongada.
  2. Registrar as leituras de postura e os alertas de cada sessão de trabalho.
  3. Permitir ao médico acompanhar os trabalhadores vinculados e emitir laudos AET (Análise Ergonômica do Trabalho).
  4. Permitir ao gestor ver indicadores por setor, sem acesso a dados individuais de saúde.
  5. Tratar os dados conforme a LGPD (Lei nº 13.709/2018).

## 2. Componentes do sistema

| Componente | Tecnologia | Quem usa |
|---|---|---|
| Dispositivo vestível (firmware) | ESP32 DevKit V1 + sensor MPU6050 + motor de vibração, Arduino (C++) | Trabalhador (veste) |
| App mobile | React Native (Expo), Bluetooth Low Energy (`react-native-ble-plx`) | Trabalhador |
| API | Node.js, Express 5, Prisma 7, autenticação JWT, senhas com bcrypt | Todos (via app e painel) |
| Banco de dados | PostgreSQL no Supabase (nuvem) | — |
| Painel web | React 19, Vite, Material UI, Recharts | Médico e gestor |
| Hospedagem | API no Render, painel na Vercel | — |

Fluxo: **dispositivo → (Bluetooth) → app → (internet, HTTPS) → API → banco ← API ← painel web**.

## 3. Atores (partes interessadas)

| Ator | Descrição | Onde acessa |
|---|---|---|
| **Trabalhador** | Usa o dispositivo durante o trabalho e acompanha a própria postura. | App mobile |
| **Médico** (do trabalho) | Acompanha os trabalhadores vinculados a ele e emite laudos AET. | Painel web |
| **Gestor** | Cadastra pessoas, cria vínculos médico–trabalhador e acompanha indicadores agregados por setor. | Painel web |
| Dispositivo vestível | Ator do sistema: mede a postura e aciona a vibração. | — |

Não há cadastro público: só o gestor cria contas (de médico e trabalhador). O gestor inicial vem da carga inicial do banco.

## 4. Requisitos funcionais

### 4.1 Conta e acesso (todos os perfis)
- **RF01 — Login:** o usuário entra com e-mail e senha. O e-mail não diferencia maiúsculas de minúsculas.
- **RF02 — Primeiro acesso:** o usuário pré-cadastrado entra com a senha temporária, define uma nova senha
  (diferente da temporária) e aceita a Política de Privacidade. Só então a conta fica ATIVA.
- **RF03 — Bloqueio de conta pendente:** usuário com status PENDENTE não consegue fazer login comum; o
  sistema o direciona ao primeiro acesso.
- **RF04 — Política de Privacidade:** o texto da política é exibido no app e no painel (fonte única na API).
- **RF05 — Sessão autenticada:** após o login, o usuário recebe um token (JWT) com validade configurável (padrão 24 h).

### 4.2 Dispositivo vestível
- **RF06 — Medir a inclinação:** o dispositivo mede a inclinação do tronco 100 vezes por segundo
  (acelerômetro + giroscópio com filtro complementar).
- **RF07 — Calibrar a postura de referência:** com a pessoa parada na postura correta, o botão do
  dispositivo grava essa postura como referência (0°). Pode ser refeita a qualquer momento.
- **RF08 — Alertar por vibração:** fora da faixa (0° a 20°) por 30 s seguidos, o motor vibra 2 s, pausa 5 s
  e vibra 2 s; se a pessoa continuar fora, a contagem de 30 s recomeça. Ao voltar à faixa, a contagem zera
  e o motor para. Sem calibração, o motor não vibra.
- **RF09 — Transmitir leituras:** o dispositivo envia o ângulo por Bluetooth 10 vezes por segundo.

### 4.3 Trabalhador (app mobile)
- **RF10 — Ver a regra de postura:** o app mostra a regra vigente (0° a 20°, 30 s), só leitura.
- **RF11 — Iniciar sessão de monitoramento:** cria uma sessão no servidor (exige regra ativa) e procura o
  dispositivo `SIME-WEARABLE` por Bluetooth.
- **RF12 — Acompanhar a postura em tempo real:** o app mostra o ângulo atual e "Postura correta" ou
  "Postura incorreta", com a cor de fundo correspondente.
- **RF13 — Registrar alertas:** o app registra um alerta a cada ciclo de vibração (mesma regra do RF08).
- **RF14 — Enviar dados em lotes:** a cada 30 s o app envia as leituras e os alertas para a API. Se o envio
  falhar, o lote é reenviado depois; a API descarta lotes repetidos.
- **RF15 — Encerrar sessão:** envia o último lote e grava o fim da sessão no servidor. Se falhar, o app
  oferece "Tentar de novo" ou "Encerrar sem enviar".
- **RF16 — Histórico de sessões:** lista as próprias sessões, com a data de cada uma.
- **RF17 — Ver laudos:** lista e abre os laudos que os médicos emitiram para ele.

### 4.4 Médico (painel web)
- **RF18 — Painel inicial:** resumo com os laudos emitidos por ele.
- **RF19 — Listar pacientes:** trabalhadores com vínculo ativo com ele, com setor, data do vínculo, score
  de postura e total de alertas, por período (semana, mês ou todo o histórico).
- **RF20 — Emitir laudo AET:** escreve um laudo (20 a 5 000 caracteres) para um trabalhador vinculado a ele.
- **RF21 — Assinar laudo:** assina os laudos de sua autoria (registra data e hora da assinatura).
- **RF22 — Listar e ver laudos:** vê os laudos que emitiu, mesmo após o fim do vínculo.
- **RF23 — Consultar a regra de postura:** vê a regra vigente e o histórico, só leitura.
- (A API também permite ao médico consultar as sessões de um paciente vinculado; o painel ainda não exibe essa tela.)

### 4.5 Gestor (painel web)
- **RF24 — Pré-cadastrar pessoas:** cadastra médico ou trabalhador com nome, e-mail, perfil, setor (só
  para trabalhador) e senha temporária. A conta nasce PENDENTE.
- **RF25 — Listar pessoas:** vê nome, e-mail, perfil, setor e situação (pendente/ativo) dos cadastrados.
- **RF26 — Vincular trabalhador a médico:** cria o vínculo médico–trabalhador; lista só trabalhadores sem vínculo ativo.
- **RF27 — Encerrar vínculo:** encerra um vínculo ativo (o registro é mantido, com data de encerramento).
- **RF28 — Listar vínculos:** ativos, encerrados ou todos.
- **RF29 — Painel por setor:** por setor, número de participantes ativos, total de alertas e score médio,
  por semana ou mês; setores de maior risco (menor score) primeiro.
- **RF30 — Relatório e exportação:** relatório por setor comparando semana e mês, com gráfico e exportação em CSV.
- **RF31 — Consultar a regra de postura:** só leitura.

## 5. Regras de negócio

- **RN01 — Perfis:** existem três perfis: TRABALHADOR, MEDICO e GESTOR. Cada usuário tem um só perfil.
- **RN02 — Setor:** só o trabalhador pertence a um setor; médico e gestor não têm setor.
- **RN03 — Regra de postura fixa:** a regra é única e fixa: 0° a 20°, alerta após 30 s seguidos fora da
  faixa. Ela é aplicada pelo firmware e não pode ser criada nem alterada pelo sistema. O valor existe em dois
  lugares (carga inicial do banco e firmware) e os dois devem ser iguais.
- **RN04 — Sessão exige regra ativa:** não é possível iniciar sessão sem regra ativa; a sessão guarda a
  versão da regra em uso.
- **RN05 — Vínculo único:** um trabalhador tem no máximo um vínculo ativo com médico por vez; vínculos
  encerrados ficam no histórico e nunca são apagados.
- **RN06 — Acesso do médico:** o médico só vê dados individuais (pacientes, sessões) de trabalhadores com
  vínculo ativo com ele, e só emite laudo para eles.
- **RN07 — Laudo:** só o médico autor assina o laudo; o médico continua vendo os laudos que emitiu após o
  fim do vínculo; o trabalhador vê só os próprios laudos.
- **RN08 — Acesso do gestor:** o gestor nunca vê leituras, sessões, alertas individuais ou laudos. Vê só
  dados agregados por setor e, para cadastro e vínculos, nome, e-mail, perfil, setor e situação.
- **RN09 — Acesso do trabalhador:** o trabalhador só vê os próprios dados (sessões e laudos).
- **RN10 — Score de postura:** % das leituras do período com ângulo dentro da faixa da regra (0 a 100). Sem
  leituras no período, o score fica vazio. Score do setor = média dos scores dos trabalhadores com leituras.
- **RN11 — Alerta:** um alerta = um ciclo de vibração (fora da faixa por 30 s seguidos). Os alertas são
  contados à parte do score.
- **RN12 — Aceite da política:** sem aceitar a Política de Privacidade não é possível ativar a conta nem entrar.
- **RN13 — Senha:** mínimo de 6 caracteres, com pelo menos 1 letra e 1 número; guardada só em forma de hash.
- **RN14 — E-mail único:** não pode haver dois usuários com o mesmo e-mail.
- **RN15 — Lotes sem duplicidade:** cada lote tem um número de sequência por sessão; um lote repetido é ignorado.
- **RN16 — Encerramento da sessão:** só o trabalhador dono encerra a própria sessão; encerrar de novo não muda a data.

## 6. Requisitos não funcionais

- **RNF01 — Segurança/autenticação:** todas as rotas, exceto login, primeiro acesso e política, exigem token JWT válido.
- **RNF02 — Autorização por perfil:** cada rota da API verifica o perfil do usuário (controle no servidor,
  não só na interface).
- **RNF03 — Senhas:** armazenadas com bcrypt; nunca retornadas pela API.
- **RNF04 — Privacidade (LGPD):** coleta mínima de dados, acesso restrito por perfil (RN06–RN09), aceite
  explícito da política, finalidade declarada (monitorar postura, alertar, laudos e indicadores por setor).
- **RNF05 — Proteção do banco:** RLS (Row Level Security) ligado em todas as tabelas do Supabase, bloqueando
  o acesso direto pela API pública do Supabase; só a API do SIME acessa os dados.
- **RNF06 — CORS:** a API só aceita chamadas de navegador vindas dos domínios configurados (o painel).
- **RNF07 — Tempo real:** o alerta por vibração não depende do celular nem da internet (é decidido no dispositivo).
- **RNF08 — Tolerância a falhas de rede:** o app guarda os dados não enviados e tenta de novo; a API não duplica lotes.
- **RNF09 — Frequência de dados:** 10 leituras por segundo transmitidas; envio ao servidor a cada 30 s.
- **RNF10 — Disponibilidade:** API em nuvem (Render, plano gratuito: pode levar ~30 s para responder após
  15 min sem uso); banco em nuvem (Supabase).
- **RNF11 — Usabilidade:** interface em português; status da postura por cor e texto; mensagens de erro claras.
- **RNF12 — Compatibilidade:** app Android (APK); painel em navegadores modernos.
- **RNF13 — Rastreabilidade:** histórico de versões da regra, datas de vínculo/encerramento, data de
  assinatura do laudo e data do aceite da política.

## 7. Modelo de dados (9 tabelas)

| Tabela | Finalidade | Campos principais |
|---|---|---|
| `setor` | Setores da empresa | id, nome |
| `usuario` | Pessoas do sistema | id, nome, email (único), senha_hash, role, setor_id (só trabalhador), status (PENDENTE/ATIVO), aceite_politica_em |
| `regra_parametrizacao` | Regra de postura (fixa) e suas versões | id, medico_id, angulo_minimo, angulo_maximo, tempo_minimo_segundos, ativo, criado_em, substitui_id |
| `sessao_monitoramento` | Uma sessão de uso do dispositivo | id, trabalhador_id, versao_regra_id, iniciada_em, finalizada_em |
| `leitura` | Ângulo medido | id, sessao_id, angulo, timestamp |
| `evento_feedback` | Alerta (ciclo de vibração) | id, sessao_id, leitura_id, regra_id, disparado_em |
| `lote_recebido` | Controle de lotes enviados pelo app | id, sessao_id, sequencia (único por sessão), recebido_em |
| `laudo_aet` | Laudo do médico | id, trabalhador_id, medico_id, conteudo, assinado, assinado_em, criado_em |
| `medico_paciente` | Vínculo médico–trabalhador | id, medico_id, trabalhador_id, vinculado_em, encerrado_em |

Relacionamentos: setor 1–N usuario; usuario (trabalhador) 1–N sessao; sessao 1–N leitura, evento e lote;
regra 1–N sessao e evento; usuario (médico) 1–N laudo e vínculo; usuario (trabalhador) 1–N laudo e vínculo;
regra 1–1 regra (versão que substitui).

Observação: o modelo foi desenhado em MySQL e implementado em PostgreSQL (Supabase) com a mesma estrutura.

## 8. Integração com o dispositivo (contrato Bluetooth)

- Nome anunciado: `SIME-WEARABLE`.
- Serviço: `4fafc201-1fb5-459e-8fcc-c5c9c331914b`; característica (notificação): `beb5483e-36e1-4688-b7f5-ea07361b26a8`.
- Mensagem: JSON `{"t": ms, "a": graus}` a 10 Hz (t = ms desde a conexão; ângulo com 1 casa decimal).
- O app pede MTU de 185 bytes ao conectar, porque a mensagem passa de 20 bytes.

## 9. Restrições e premissas

- O hardware é um protótipo: motor ligado direto ao pino do ESP32 (sem MOSFET/diodo), bateria LiPo 3,7 V
  700 mAh. A intensidade da vibração (`PWM_DUTY`) ainda precisa ser definida na bancada.
- A calibração depende de a pessoa estar na postura correta ao apertar o botão.
- O app precisa de Bluetooth ligado e permissões de Bluetooth/localização no Android.
- O envio de dados depende de internet no celular; sem internet, o alerta continua funcionando no dispositivo.
- Só o gestor cria contas; não há recuperação de senha, edição nem exclusão de pessoas.
- A regra de postura é fixa (decisão de projeto).

## 10. Limitações conhecidas / fora do escopo atual

- Não há recuperação de senha ("esqueci minha senha").
- Não há edição nem exclusão de usuários.
- O painel do médico não exibe as sessões detalhadas de um paciente (a API já permite).
- Se o app for fechado à força durante uma sessão, ela fica aberta no servidor (sem encerramento automático).
- O app não mostra o histórico de alertas nem gráficos ao trabalhador.
- Não há notificação ao médico quando um paciente acumula alertas.
