# Prompt para montar o backlog do SIME

Copie tudo abaixo da linha e cole no Claude. Se puder, anexe junto o arquivo `levantamento-requisitos-base.md`
(ele traz os requisitos RF/RN/RNF citados aqui). Antes de enviar, complete a seção "Informações que eu
vou completar" com o que só você sabe: sprints, responsáveis, cards do Trello.

---

Preciso montar o **backlog do projeto SIME**, incluindo as tarefas já feitas (históricas) e as pendentes.
Use só as informações abaixo e não invente tarefas, datas ou responsáveis. Quando faltar informação, deixe o
campo como "a definir" em vez de supor.

## Sobre o projeto

SIME é um sistema de monitoramento postural para prevenir riscos ergonômicos no trabalho:
- **Dispositivo vestível** (ESP32 + sensor MPU6050 + motor de vibração): mede a inclinação do tronco e vibra
  quando a pessoa fica fora da faixa de 0° a 20° por 30 s seguidos.
- **App mobile** (React Native/Expo) do trabalhador: recebe as leituras por Bluetooth, mostra a postura em
  tempo real e envia os dados para a API.
- **API** (Node.js, Express, Prisma, JWT) e **banco** (PostgreSQL no Supabase; antes era MySQL local).
- **Painel web** (React + Vite + Material UI) para o médico (pacientes, laudos AET) e o gestor (cadastro de
  pessoas, vínculos médico–trabalhador, indicadores por setor, relatório CSV).
- Perfis: TRABALHADOR, MEDICO e GESTOR. LGPD: aceite da política de privacidade; o gestor só vê dados agregados.

## Formato que eu quero

Uma tabela (e depois a mesma lista agrupada por épico) com as colunas:
**ID | Épico | Tarefa / história de usuário | Componente | Requisitos relacionados (RF/RN/RNF) | Prioridade
(Alta/Média/Baixa) | Estimativa (P/M/G) | Status (Concluída / Pendente) | Data de conclusão**

- Escreva as tarefas como histórias quando fizer sentido: "Como <perfil>, quero <ação> para <benefício>".
- Para tarefas técnicas, use o verbo no infinitivo ("Configurar…", "Criar…").
- Inclua critérios de aceite curtos (2 a 4) nas tarefas pendentes de prioridade Alta.
- Ordene por épico e, dentro do épico, pela data (concluídas primeiro, depois pendentes por prioridade).
- No fim, um resumo: total de tarefas, concluídas, pendentes e % concluído por épico.

Épicos sugeridos: Banco de dados e API base; Autenticação e LGPD; Sessões e coleta de dados; Laudos;
Gestão de pessoas e vínculos; Indicadores e relatórios; App mobile; Painel web; Firmware e hardware;
Infraestrutura e deploy.

## Tarefas concluídas (histórico)

As datas vêm do histórico de migrations do banco e dos commits. Onde não há data exata, use "até 26/11/2026".

**12/11/2026 — Banco de dados e API base**
1. Modelar o banco e criar as tabelas iniciais: setor, usuario, regra_parametrizacao, sessao_monitoramento,
   leitura, evento_feedback, laudo_aet (migration `init`).
2. Versionar a regra de postura: cada alteração cria uma nova versão ligada à anterior (`add_substitui_id`).
3. Evitar lotes duplicados enviados pelo app: tabela de lotes recebidos com sequência única por sessão
   (`add_lote_recebido`).
4. Ligar cada sessão à versão da regra usada (`add_versao_regra_and_nullable_leitura`).
5. Assinatura de laudo pelo médico: campos "assinado" e "assinado_em" (`add_assinado_to_laudo`).

**19/11/2026**
6. Adicionar o ângulo máximo à regra de postura (faixa mínimo–máximo) (`add_angulo_maximo`).

**23/11/2026 — Autenticação e vínculos**
7. Status do usuário (PENDENTE/ATIVO) e senha com hash bcrypt (`usuario_status_senha_hash`).
8. Tarefa W5b: script único para converter as senhas antigas em texto para hash.
9. Remover a coluna de senha em texto puro (`remove_senha_texto`).
10. Vínculo médico–paciente (tabela `medico_paciente`), com um só vínculo ativo por trabalhador.

**Até 26/11/2026 (entregue na versão inicial, sem data exata)**
11. API: login com JWT e controle de acesso por perfil em todas as rotas.
12. Primeiro acesso: troca da senha temporária e aceite da Política de Privacidade (LGPD).
13. Regra de senha D6: mínimo de 6 caracteres, com letra e número.
14. Regra D2: só o trabalhador tem setor.
15. Gestor: pré-cadastro de médico e trabalhador com senha temporária; lista de pessoas.
16. Gestor: criar, listar e encerrar vínculos médico–trabalhador.
17. Gestor: resumo por setor (participantes, alertas, score) por semana e mês.
18. Gestor: página de relatório por setor com gráfico e exportação CSV.
19. Médico: lista de pacientes vinculados com score por período.
20. Médico: emitir, listar, ver e assinar laudos AET (20 a 5 000 caracteres).
21. Regras: tela da regra vigente e histórico de versões.
22. App: login e primeiro acesso.
23. App: iniciar sessão, conectar ao dispositivo por Bluetooth, mostrar ângulo e status em tempo real.
24. App: enviar leituras e alertas em lotes a cada 30 s, com reenvio em caso de falha.
25. App: histórico de sessões e tela de laudos do trabalhador.
26. Firmware: leitura do MPU6050 a 100 Hz com filtro complementar.
27. Firmware: calibração da postura de referência pelo botão BOOT.
28. Firmware: lógica de vibração (30 s fora → vibra 2 s, pausa 5 s, vibra 2 s).
29. Firmware: transmissão por Bluetooth (BLE) a 10 Hz, com MTU de até 185 bytes.
30. Carga inicial do banco (seed) com setores, usuários de teste, regra, sessão e laudo de exemplo.

**26/11/2026 — Migração para a nuvem e correções**
31. Migrar o banco de MySQL local para PostgreSQL no Supabase (adaptador, migrations novas, seed).
32. Ligar RLS (Row Level Security) em todas as tabelas do Supabase.
33. Gravar e buscar e-mails em minúsculas (login sem diferenciar maiúsculas).
34. Configurar o deploy da API no Render (render.yaml).
35. Preparar o painel para a Vercel (endereço da API por variável, rotas do React).
36. Liberar CORS na API para o domínio do painel.
37. Tornar a regra de postura fixa (0°–20°, 30 s, igual ao firmware): remover criação/edição na API e no painel.
38. App: registrar alerta só a cada ciclo de vibração (como o firmware), e não a cada leitura.
39. API + app: encerrar a sessão no servidor (grava o fim) sem perder o último lote.
40. Mudar o score para "% de leituras dentro da faixa" e mostrar o total de alertas separado.
41. Documento-base do levantamento de requisitos.

## Tarefas pendentes

**Infraestrutura e deploy**
- Publicar a API no Render e testar a URL pública (/health e login).
- Publicar o painel na Vercel e configurar o endereço da API.
- Configurar o CORS da API com a URL da Vercel.
- Gerar o APK novo do app apontando para a API do Render.

**Firmware e hardware**
- Definir na bancada a intensidade da vibração (PWM_DUTY, hoje 0 = motor desligado).
- Medir a corrente do motor ligado direto no GPIO19 e verificar reinícios (brownout) e falhas de I2C/BLE.
- Medir a tensão de 3,3 V funcionando só com a bateria LiPo (Bluetooth e motor ligados).
- Testar no celular se o MTU negociado é 185 (mensagens acima de 20 bytes).

**Funcionalidades**
- Médico: tela com as sessões detalhadas de um paciente (a API já tem a rota).
- Encerrar automaticamente sessões abandonadas (app fechado à força).
- Recuperação de senha ("esqueci minha senha").
- Gestor: editar e desativar usuários.
- App: mostrar ao trabalhador o histórico de alertas e gráficos da própria postura.
- Notificar o médico quando um paciente acumular alertas.

**Documentação**
- Atualizar o diagrama do banco (incluir medico_paciente e angulo_maximo; nota MySQL → PostgreSQL).
- Finalizar o documento de levantamento de requisitos.

## Informações que eu vou completar

- Sprints e datas de cada sprint: [preencher ou "não usamos sprints"]
- Responsáveis por tarefa: [preencher ou deixar "a definir"]
- Cards do Trello que não aparecem acima: [colar aqui]
- Prazo de entrega: [preencher]
