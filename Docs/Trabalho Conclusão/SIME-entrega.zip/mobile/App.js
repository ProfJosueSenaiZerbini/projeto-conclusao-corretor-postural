import 'react-native-gesture-handler'
import AppNavigator from './src/navigation/AppNavigator.js'

export default function App() {
  return <AppNavigator />
}
