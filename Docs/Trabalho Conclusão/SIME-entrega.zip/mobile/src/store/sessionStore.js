import { create } from 'zustand'

export const useSessionStore = create((set) => ({
  sessaoAtiva: null,
  leituras: [],
  eventos: [],
  sequencia: 0,

  iniciarSessao: (sessao) =>
    set({ sessaoAtiva: sessao, leituras: [], eventos: [], sequencia: 0 }),

  adicionarLeitura: (leitura) =>
    set((state) => ({ leituras: [...state.leituras, leitura] })),

  adicionarEvento: (evento) =>
    set((state) => ({ eventos: [...state.eventos, evento] })),

  incrementarSequencia: () =>
    set((state) => ({ sequencia: state.sequencia + 1 })),

  // Remove só o que foi enviado: leituras e eventos que chegaram durante o envio continuam
  limparLote: (qtdLeituras, qtdEventos) =>
    set((state) => ({
      leituras: state.leituras.slice(qtdLeituras),
      eventos: state.eventos.slice(qtdEventos),
    })),

  encerrarSessao: () =>
    set({ sessaoAtiva: null, leituras: [], eventos: [], sequencia: 0 }),
}))
