import { BleManager } from 'react-native-ble-plx'
import { Platform, PermissionsAndroid } from 'react-native'

export const SERVICE_UUID = '4fafc201-1fb5-459e-8fcc-c5c9c331914b'
export const CHARACTERISTIC_UUID = 'beb5483e-36e1-4688-b7f5-ea07361b26a8'

const DEVICE_NAME = 'SIME-WEARABLE'

// O JSON {"t":…,"a":…} passa de 20 bytes (MTU padrão 23 − 3); o firmware aceita até 185
const MTU_DESEJADO = 185

const manager = new BleManager()

let subscription = null

async function requestPermissions() {
  if (Platform.OS !== 'android') return

  const result = await PermissionsAndroid.requestMultiple([
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
    PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
  ])

  const denied = Object.entries(result).filter(
    ([, v]) => v !== PermissionsAndroid.RESULTS.GRANTED,
  )

  if (denied.length > 0) {
    throw new Error('Permissões BLE negadas')
  }
}

function waitForPoweredOn() {
  return new Promise((resolve, reject) => {
    const sub = manager.onStateChange((state) => {
      if (state === 'PoweredOn') {
        sub.remove()
        resolve()
      } else if (state === 'PoweredOff') {
        sub.remove()
        reject(new Error('Bluetooth desligado'))
      }
    }, true)
  })
}

async function scan(onDevice) {
  await requestPermissions()
  await waitForPoweredOn()

  manager.startDeviceScan(null, null, (error, device) => {
    if (error) {
      console.log('[BLE] Erro no scan:', error.message)
      return
    }
    if (device && device.name === DEVICE_NAME) {
      onDevice(device)
    }
  })
}

function stopScan() {
  manager.stopDeviceScan()
}

async function connect(deviceId) {
  const device = await manager.connectToDevice(deviceId)
  try {
    const comMtu = await manager.requestMTUForDevice(device.id, MTU_DESEJADO)
    console.log('[BLE] MTU negociado:', comMtu.mtu)
  } catch (err) {
    console.log('[BLE] Falha ao pedir MTU:', err.message)
  }
  await device.discoverAllServicesAndCharacteristics()
  return device
}

async function disconnect(deviceId) {
  await manager.cancelDeviceConnection(deviceId)
}

function startReading(device, onReading) {
  subscription = manager.monitorCharacteristicForDevice(
    device.id,
    SERVICE_UUID,
    CHARACTERISTIC_UUID,
    (error, characteristic) => {
      if (error) {
        console.log('[BLE] Erro na leitura:', error.message)
        return
      }
      if (!characteristic?.value) return

      try {
        const decoded = atob(characteristic.value)
        const packet = JSON.parse(decoded)
        onReading({ t_ms: packet.t, angulo: packet.a })
      } catch (err) {
        console.log('[BLE] Erro ao parsear pacote:', err.message)
      }
    },
  )
}

function stopReading() {
  if (subscription) {
    subscription.remove()
    subscription = null
  }
}

const bleService = {
  manager,
  scan,
  stopScan,
  connect,
  disconnect,
  startReading,
  stopReading,
}

export default bleService
