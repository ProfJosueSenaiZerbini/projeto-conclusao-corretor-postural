import { useAuthStore } from '../store/authStore.js'

export const BASE_URL = process.env.EXPO_PUBLIC_API_URL ?? 'http://10.0.2.2:3000'

export async function apiFetch(path, options = {}) {
  const token = useAuthStore.getState().user?.token

  const response = await fetch(BASE_URL + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    const err = new Error(body.erros?.[0] || `Erro ${response.status}`)
    err.status = response.status
    err.body = body
    throw err
  }

  return response.json()
}
