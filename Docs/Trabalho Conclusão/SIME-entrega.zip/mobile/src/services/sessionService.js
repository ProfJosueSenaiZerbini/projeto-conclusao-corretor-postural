import { apiFetch } from './api.js'

export async function criarSessao(trabalhadorId, versaoRegraId) {
  return apiFetch('/sessoes', {
    method: 'POST',
    body: JSON.stringify({
      trabalhador_id: trabalhadorId,
      versao_regra_id: versaoRegraId,
      data_inicio: new Date().toISOString(),
    }),
  })
}

export async function enviarLote(sessaoId, sequencia, leituras, eventos) {
  return apiFetch(`/sessoes/${sessaoId}/lotes`, {
    method: 'POST',
    body: JSON.stringify({
      sequencia,
      leituras,
      eventos,
      lacunas: [],
    }),
  })
}

export async function encerrarSessaoNaApi(sessaoId) {
  return apiFetch(`/sessoes/${sessaoId}/encerrar`, { method: 'PATCH' })
}

export async function buscarRegrasAtivas() {
  return apiFetch('/regras?ativo=true')
}
