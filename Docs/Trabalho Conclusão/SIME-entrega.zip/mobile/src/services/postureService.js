export function classificarPostura(angulo, regra) {
  if (angulo >= regra.angulo_minimo && angulo <= regra.angulo_maximo) {
    return 'CORRETA'
  }
  return 'INCORRETA'
}

export function criarEvento(t_ms, regraId, vibrou) {
  return { t_ms, regra_id: regraId, vibrou }
}

// Ciclo de vibração do firmware depois de cada alerta: vibra 2 s, pausa 5 s, vibra 2 s
// (firmware/sime_wearable/config.h: DURACAO_VIBRACAO_MS, PAUSA_MS, DURACAO_VIBRACAO_MS).
const CICLO_VIBRACAO_MS = 2000 + 5000 + 2000

// Conta os alertas como o firmware (vibracao.cpp): fora da faixa por tempo_minimo_segundos
// seguidos → 1 alerta (o motor vibra); ainda fora, a contagem recomeça quando o ciclo de
// vibração termina; de volta à faixa, zera. Um alerta = um ciclo de vibração sentido.
// Criar um detector novo a cada conexão BLE: o t_ms do firmware recomeça em cada conexão.
export function criarDetectorAlerta(regra) {
  const tempoForaMs = regra.tempo_minimo_segundos * 1000
  let contandoDesde = null // t_ms em que a contagem atual começou; null = dentro da faixa

  return function registrarLeitura(t_ms, angulo) {
    if (classificarPostura(angulo, regra) === 'CORRETA') {
      contandoDesde = null
      return null
    }
    if (contandoDesde === null) {
      contandoDesde = t_ms
    }
    if (t_ms - contandoDesde >= tempoForaMs) {
      contandoDesde = t_ms + CICLO_VIBRACAO_MS
      return criarEvento(t_ms, regra.id, true)
    }
    return null
  }
}
