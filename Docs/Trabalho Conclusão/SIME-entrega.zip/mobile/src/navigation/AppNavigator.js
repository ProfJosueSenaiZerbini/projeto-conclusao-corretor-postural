import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'

import { useAuthStore } from '../store/authStore.js'

import LoginScreen from '../screens/LoginScreen.js'
import PrimeiroAcessoScreen from '../screens/PrimeiroAcessoScreen.js'
import MainScreen from '../screens/MainScreen.js'
import SessionHistoryScreen from '../screens/SessionHistoryScreen.js'
import LaudosScreen from '../screens/LaudosScreen.js'
import LaudoDetailScreen from '../screens/LaudoDetailScreen.js'

const Stack = createStackNavigator()
const Tab = createBottomTabNavigator()

function HomeTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Main" component={MainScreen} options={{ title: 'Início' }} />
      <Tab.Screen name="SessionHistory" component={SessionHistoryScreen} options={{ title: 'Histórico' }} />
      <Tab.Screen name="Laudos" component={LaudosScreen} options={{ title: 'Laudos' }} />
    </Tab.Navigator>
  )
}

export default function AppNavigator() {
  const user = useAuthStore((state) => state.user)

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <>
            <Stack.Screen name="HomeTabs" component={HomeTabs} />
            <Stack.Screen
              name="LaudoDetail"
              component={LaudoDetailScreen}
              options={{ headerShown: true, title: 'Detalhe do Laudo' }}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="PrimeiroAcesso" component={PrimeiroAcessoScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  )
}
