import { useEffect, useState } from 'react'
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Switch,
  ActivityIndicator,
  StyleSheet,
} from 'react-native'
import { apiFetch } from '../services/api.js'
import { useAuthStore } from '../store/authStore.js'

// Primeiro acesso: troca da senha temporária e aceite da Política de Privacidade.
// Chega aqui pelo login (403 PRIMEIRO_ACESSO), com e-mail e senha temporária preenchidos.
export default function PrimeiroAcessoScreen({ route }) {
  const setUser = useAuthStore((state) => state.setUser)
  const [email, setEmail] = useState(route.params?.email ?? '')
  const [senhaTemporaria, setSenhaTemporaria] = useState(route.params?.senha ?? '')
  const [novaSenha, setNovaSenha] = useState('')
  const [aceite, setAceite] = useState(false)
  const [politica, setPolitica] = useState(null)
  const [erroPolitica, setErroPolitica] = useState('')
  const [erro, setErro] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    let ativo = true
    apiFetch('/auth/politica')
      .then((body) => ativo && setPolitica(body.texto))
      .catch(() => ativo && setErroPolitica('Não foi possível carregar a Política de Privacidade.'))
    return () => {
      ativo = false
    }
  }, [])

  async function handleConfirmar() {
    setErro('')
    setLoading(true)

    try {
      const user = await apiFetch('/auth/primeiro-acesso', {
        method: 'POST',
        body: JSON.stringify({
          email: email.trim(),
          senha_temporaria: senhaTemporaria,
          nova_senha: novaSenha,
          aceite,
        }),
      })
      setUser(user)
    } catch (err) {
      // Com resposta da API, mostra a primeira mensagem de { erros }; sem resposta, erro de conexão
      setErro(err.status ? err.message : 'Erro ao conectar com o servidor')
    } finally {
      setLoading(false)
    }
  }

  const podeConfirmar = aceite && !loading

  return (
    <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>Primeiro acesso</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        placeholderTextColor="#999"
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        value={email}
        onChangeText={setEmail}
        editable={!loading}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha temporária"
        placeholderTextColor="#999"
        secureTextEntry
        value={senhaTemporaria}
        onChangeText={setSenhaTemporaria}
        editable={!loading}
      />

      <TextInput
        style={styles.input}
        placeholder="Nova senha"
        placeholderTextColor="#999"
        secureTextEntry
        value={novaSenha}
        onChangeText={setNovaSenha}
        editable={!loading}
      />

      <View style={styles.politica}>
        {politica !== null ? (
          <ScrollView nestedScrollEnabled>
            <Text style={styles.politicaTexto}>{politica}</Text>
          </ScrollView>
        ) : erroPolitica !== '' ? (
          <Text style={styles.erro}>{erroPolitica}</Text>
        ) : (
          <ActivityIndicator color="#1976d2" />
        )}
      </View>

      <View style={styles.aceite}>
        <Switch
          value={aceite}
          onValueChange={setAceite}
          disabled={politica === null || loading}
        />
        <Text style={styles.aceiteTexto}>Li e concordo com a Política de Privacidade</Text>
      </View>

      {erro !== '' && <Text style={styles.erro}>{erro}</Text>}

      <Pressable
        style={[styles.botao, !podeConfirmar && styles.botaoDesabilitado]}
        onPress={handleConfirmar}
        disabled={!podeConfirmar}
      >
        <Text style={styles.botaoTexto}>{loading ? 'Enviando...' : 'Confirmar'}</Text>
      </Pressable>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingVertical: 48,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    marginBottom: 16,
    color: '#333',
  },
  politica: {
    height: 220,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    justifyContent: 'center',
  },
  politicaTexto: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
  aceite: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  aceiteTexto: {
    flex: 1,
    fontSize: 14,
    color: '#333',
    marginLeft: 8,
  },
  erro: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  botao: {
    backgroundColor: '#1976d2',
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  botaoDesabilitado: {
    backgroundColor: '#90caf9',
  },
  botaoTexto: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
})
