import { useState, useEffect, useCallback } from 'react'
import { View, Text, FlatList, ActivityIndicator, Pressable, StyleSheet } from 'react-native'
import { useAuthStore } from '../store/authStore.js'
import { apiFetch } from '../services/api.js'

export default function SessionHistoryScreen() {
  const user = useAuthStore((s) => s.user)
  const [sessoes, setSessoes] = useState([])
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const carregarSessoes = useCallback(async () => {
    setErro(false)
    try {
      const data = await apiFetch(`/sessoes?trabalhador_id=${user.id}`)
      setSessoes(data)
    } catch (err) {
      setErro(true)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [user.id])

  useEffect(() => {
    carregarSessoes()
  }, [carregarSessoes])

  function handleRefresh() {
    setRefreshing(true)
    carregarSessoes()
  }

  function handleTentarNovamente() {
    setLoading(true)
    carregarSessoes()
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1976d2" />
      </View>
    )
  }

  if (erro) {
    return (
      <View style={styles.center}>
        <Text style={styles.erroTexto}>Erro ao carregar sessões</Text>
        <Pressable style={styles.botao} onPress={handleTentarNovamente}>
          <Text style={styles.botaoTexto}>Tentar novamente</Text>
        </Pressable>
      </View>
    )
  }

  if (sessoes.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.vazio}>Nenhuma sessão encontrada</Text>
      </View>
    )
  }

  return (
    <FlatList
      style={styles.lista}
      data={sessoes}
      keyExtractor={(item) => String(item.id)}
      refreshing={refreshing}
      onRefresh={handleRefresh}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.data}>
            {new Date(item.data_inicio).toLocaleDateString('pt-BR')}
          </Text>
          {item.status && <Text style={styles.status}>{item.status}</Text>}
        </View>
      )}
    />
  )
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 32,
  },
  lista: {
    flex: 1,
    backgroundColor: '#fff',
  },
  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  data: {
    fontSize: 16,
    color: '#333',
  },
  status: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  erroTexto: {
    fontSize: 16,
    color: '#c62828',
    marginBottom: 16,
  },
  vazio: {
    fontSize: 16,
    color: '#999',
  },
  botao: {
    backgroundColor: '#1976d2',
    height: 44,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  botaoTexto: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
})
