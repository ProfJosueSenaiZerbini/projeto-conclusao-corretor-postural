import { useState, useEffect, useCallback } from 'react'
import { View, Text, FlatList, ActivityIndicator, Pressable, StyleSheet } from 'react-native'
import { useAuthStore } from '../store/authStore.js'
import { apiFetch } from '../services/api.js'

export default function LaudosScreen({ navigation }) {
  const user = useAuthStore((s) => s.user)
  const [laudos, setLaudos] = useState([])
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const carregarLaudos = useCallback(async () => {
    setErro(false)
    try {
      const data = await apiFetch(`/laudos?trabalhador_id=${user.id}`)
      setLaudos(data)
    } catch (err) {
      setErro(true)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [user.id])

  useEffect(() => {
    carregarLaudos()
  }, [carregarLaudos])

  function handleRefresh() {
    setRefreshing(true)
    carregarLaudos()
  }

  function handleTentarNovamente() {
    setLoading(true)
    carregarLaudos()
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1976d2" />
      </View>
    )
  }

  if (erro) {
    return (
      <View style={styles.center}>
        <Text style={styles.erroTexto}>Erro ao carregar laudos</Text>
        <Pressable style={styles.botao} onPress={handleTentarNovamente}>
          <Text style={styles.botaoTexto}>Tentar novamente</Text>
        </Pressable>
      </View>
    )
  }

  if (laudos.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.vazio}>Nenhum laudo encontrado</Text>
      </View>
    )
  }

  return (
    <FlatList
      style={styles.lista}
      data={laudos}
      keyExtractor={(item) => String(item.id)}
      refreshing={refreshing}
      onRefresh={handleRefresh}
      renderItem={({ item }) => (
        <Pressable
          style={styles.card}
          onPress={() => navigation.navigate('LaudoDetail', { laudo: item })}
        >
          <Text style={styles.data}>
            {new Date(item.criado_em).toLocaleDateString('pt-BR')}
          </Text>
          <Text style={item.assinado ? styles.assinado : styles.pendente}>
            {item.assinado ? '✓ Assinado' : 'Pendente'}
          </Text>
        </Pressable>
      )}
    />
  )
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 32,
  },
  lista: {
    flex: 1,
    backgroundColor: '#fff',
  },
  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  data: {
    fontSize: 16,
    color: '#333',
  },
  assinado: {
    fontSize: 14,
    color: '#2e7d32',
    fontWeight: '600',
  },
  pendente: {
    fontSize: 14,
    color: '#999',
    fontWeight: '600',
  },
  erroTexto: {
    fontSize: 16,
    color: '#c62828',
    marginBottom: 16,
  },
  vazio: {
    fontSize: 16,
    color: '#999',
  },
  botao: {
    backgroundColor: '#1976d2',
    height: 44,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  botaoTexto: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
})
