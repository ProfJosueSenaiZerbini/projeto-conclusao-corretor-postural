import { useState, useEffect, useRef, useCallback } from 'react'
import { View, Text, Pressable, ActivityIndicator, StyleSheet, Alert } from 'react-native'
import { useFocusEffect } from '@react-navigation/native'
import { useAuthStore } from '../store/authStore.js'
import { useSessionStore } from '../store/sessionStore.js'
import bleService from '../services/bleService.js'
import { apiFetch } from '../services/api.js'
import {
  criarSessao,
  enviarLote,
  encerrarSessaoNaApi,
  buscarRegrasAtivas,
} from '../services/sessionService.js'
import { classificarPostura, criarDetectorAlerta } from '../services/postureService.js'

const LOTE_INTERVAL_MS = 30_000

// Faixa completa da regra, somente leitura: "0° a 20° · 30 s"
function formatarRegra(regra) {
  return `${regra.angulo_minimo}° a ${regra.angulo_maximo}° · ${regra.tempo_minimo_segundos} s`
}

export default function MainScreen() {
  const user = useAuthStore((s) => s.user)
  const sessaoAtiva = useSessionStore((s) => s.sessaoAtiva)
  const iniciarSessao = useSessionStore((s) => s.iniciarSessao)
  const adicionarLeitura = useSessionStore((s) => s.adicionarLeitura)
  const adicionarEvento = useSessionStore((s) => s.adicionarEvento)
  const incrementarSequencia = useSessionStore((s) => s.incrementarSequencia)
  const limparLote = useSessionStore((s) => s.limparLote)
  const encerrarSessao = useSessionStore((s) => s.encerrarSessao)

  const [bleConectado, setBleConectado] = useState(false)
  const [anguloAtual, setAnguloAtual] = useState(null)
  const [statusPostura, setStatusPostura] = useState(null)
  const [loading, setLoading] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [encerrando, setEncerrando] = useState(false)

  // Regra ativa exibida antes da sessão: undefined = carregando; null = nenhuma regra ativa
  const [regraAtiva, setRegraAtiva] = useState(undefined)
  const [erroRegra, setErroRegra] = useState('')

  const deviceRef = useRef(null)
  const regraRef = useRef(null)
  const loteTimerRef = useRef(null)

  // true = nada pendente ou lote enviado; false = falhou (o lote fica para a próxima tentativa)
  const enviarLoteAtual = useCallback(async () => {
    const state = useSessionStore.getState()
    if (!state.sessaoAtiva || state.leituras.length === 0) return true

    const { leituras, eventos } = state
    try {
      await enviarLote(state.sessaoAtiva.id, state.sequencia, leituras, eventos)
      limparLote(leituras.length, eventos.length)
      incrementarSequencia()
      return true
    } catch (err) {
      console.log('[MainScreen] Erro ao enviar lote:', err.message)
      return false
    }
  }, [limparLote, incrementarSequencia])

  function iniciarTimerLote() {
    pararTimerLote()
    loteTimerRef.current = setInterval(enviarLoteAtual, LOTE_INTERVAL_MS)
  }

  function pararTimerLote() {
    if (loteTimerRef.current) {
      clearInterval(loteTimerRef.current)
      loteTimerRef.current = null
    }
  }

  useEffect(() => {
    return () => {
      pararTimerLote()
    }
  }, [])

  const carregarRegraAtiva = useCallback(async () => {
    setErroRegra('')
    setRegraAtiva(undefined)
    try {
      // A API devolve as ativas da mais recente para a mais antiga; vale a primeira
      const regrasAtivas = await buscarRegrasAtivas()
      setRegraAtiva(regrasAtivas[0] ?? null)
    } catch (err) {
      setErroRegra('Não foi possível carregar a regra ativa.')
    }
  }, [])

  // Recarrega a regra sempre que a aba Início volta a ficar visível sem sessão em andamento
  useFocusEffect(
    useCallback(() => {
      if (!useSessionStore.getState().sessaoAtiva) {
        carregarRegraAtiva()
      }
    }, [carregarRegraAtiva]),
  )

  async function handleIniciarSessao() {
    if (!regraAtiva) return

    setLoading(true)
    try {
      const sessao = await criarSessao(user.id, regraAtiva.id)

      // A API usa sempre a regra ativa; se ela mudou depois de exibida, usa a da sessão
      let regraDaSessao = regraAtiva
      if (sessao.versao_regra_id !== regraAtiva.id) {
        regraDaSessao = await apiFetch(`/regras/${sessao.versao_regra_id}`)
        setRegraAtiva(regraDaSessao)
      }

      regraRef.current = regraDaSessao
      iniciarSessao(sessao)
      iniciarScan()
    } catch (err) {
      if (err.status === 409) {
        // Sem regra ativa na API: mostra o motivo e atualiza a regra exibida
        Alert.alert('Erro', err.message)
        carregarRegraAtiva()
      } else {
        Alert.alert('Erro', 'Não foi possível criar sessão.')
      }
    } finally {
      setLoading(false)
    }
  }

  function iniciarScan() {
    setScanning(true)
    bleService.scan((device) => {
      bleService.stopScan()
      setScanning(false)
      conectarDispositivo(device.id)
    })
  }

  async function conectarDispositivo(deviceId) {
    try {
      const device = await bleService.connect(deviceId)
      deviceRef.current = device
      setBleConectado(true)
      iniciarTimerLote()

      const regra = regraRef.current
      // Novo a cada conexão: o t_ms do firmware recomeça em cada conexão BLE
      const registrarLeitura = criarDetectorAlerta(regra)

      bleService.startReading(device, (reading) => {
        setAnguloAtual(reading.angulo)
        setStatusPostura(classificarPostura(reading.angulo, regra))
        adicionarLeitura(reading)

        // Alerta só quando o firmware vibraria (fora da faixa por 30 s seguidos)
        const evento = registrarLeitura(reading.t_ms, reading.angulo)
        if (evento) {
          adicionarEvento(evento)
        }
      })
    } catch (err) {
      Alert.alert('Erro BLE', 'Não foi possível conectar ao dispositivo.')
      setScanning(false)
    }
  }

  // Envia o último lote e grava o fim da sessão na API; false se algum dos dois falhar
  async function finalizarNoServidor() {
    if (!(await enviarLoteAtual())) return false
    try {
      await encerrarSessaoNaApi(useSessionStore.getState().sessaoAtiva.id)
      return true
    } catch (err) {
      console.log('[MainScreen] Erro ao encerrar sessão na API:', err.message)
      return false
    }
  }

  async function handleEncerrarSessao() {
    pararTimerLote()
    bleService.stopScan()
    bleService.stopReading() // para de juntar leituras: o último lote fica fechado

    setEncerrando(true)
    const ok = await finalizarNoServidor()
    setEncerrando(false)

    if (!ok) {
      // A sessão e o lote pendente continuam no aparelho até o trabalhador decidir
      Alert.alert(
        'Não foi possível encerrar',
        'As últimas leituras ou o encerramento não chegaram ao servidor. Verifique a internet e tente de novo.',
        [
          { text: 'Tentar de novo', onPress: handleEncerrarSessao },
          { text: 'Encerrar sem enviar', style: 'destructive', onPress: limparSessaoLocal },
        ],
      )
      return
    }

    await limparSessaoLocal()
  }

  async function limparSessaoLocal() {
    if (deviceRef.current) {
      try {
        await bleService.disconnect(deviceRef.current.id)
      } catch (err) {
        console.log('[MainScreen] Erro ao desconectar:', err.message)
      }
      deviceRef.current = null
    }

    setBleConectado(false)
    setAnguloAtual(null)
    setStatusPostura(null)
    setScanning(false)
    encerrarSessao()
    carregarRegraAtiva()
  }

  // Estado inicial — sem sessão: mostra a regra ativa (somente leitura)
  if (!sessaoAtiva) {
    const podeIniciar = Boolean(regraAtiva) && !loading

    let regraConteudo
    if (erroRegra !== '') {
      regraConteudo = <Text style={styles.aviso}>{erroRegra}</Text>
    } else if (regraAtiva === undefined) {
      regraConteudo = <ActivityIndicator color="#1976d2" />
    } else if (regraAtiva === null) {
      regraConteudo = (
        <Text style={styles.aviso}>
          Nenhuma regra ativa. Não é possível iniciar a sessão.
        </Text>
      )
    } else {
      regraConteudo = <Text style={styles.regraValor}>{formatarRegra(regraAtiva)}</Text>
    }

    return (
      <View style={styles.container}>
        <Text style={styles.nome}>{user.nome}</Text>
        <Text style={styles.role}>{user.role}</Text>

        <View style={styles.regra}>
          <Text style={styles.regraTitulo}>Regra de postura</Text>
          {regraConteudo}
        </View>

        {erroRegra !== '' && (
          <Pressable style={[styles.botao, styles.botaoSecundario]} onPress={carregarRegraAtiva}>
            <Text style={styles.botaoSecundarioTexto}>Tentar novamente</Text>
          </Pressable>
        )}

        <Pressable
          style={[styles.botao, styles.botaoIniciar, !podeIniciar && styles.botaoDesabilitado]}
          onPress={handleIniciarSessao}
          disabled={!podeIniciar}
        >
          <Text style={styles.botaoTexto}>
            {loading ? 'Carregando...' : 'Iniciar Sessão'}
          </Text>
        </Pressable>
      </View>
    )
  }

  // Sessão ativa + BLE desconectado
  if (!bleConectado) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#1976d2" />
        <Text style={styles.scanning}>Procurando SIME-WEARABLE...</Text>

        <Pressable
          style={[styles.botao, styles.botaoEncerrar]}
          onPress={handleEncerrarSessao}
          disabled={encerrando}
        >
          <Text style={styles.botaoTexto}>{encerrando ? 'Encerrando...' : 'Encerrar Sessão'}</Text>
        </Pressable>
      </View>
    )
  }

  // Sessão ativa + BLE conectado
  const correta = statusPostura === 'CORRETA'

  return (
    <View style={[styles.container, correta ? styles.bgCorreta : styles.bgIncorreta]}>
      <Text style={styles.angulo}>
        {anguloAtual != null ? `${anguloAtual.toFixed(1)}°` : '--'}
      </Text>

      <Text style={[styles.status, correta ? styles.statusCorreta : styles.statusIncorreta]}>
        {correta ? '✓ Postura correta' : '⚠ Postura incorreta'}
      </Text>

      <Pressable
        style={[styles.botao, styles.botaoEncerrar]}
        onPress={handleEncerrarSessao}
        disabled={encerrando}
      >
        <Text style={styles.botaoTexto}>{encerrando ? 'Encerrando...' : 'Encerrar Sessão'}</Text>
      </Pressable>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    backgroundColor: '#fff',
  },
  nome: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  role: {
    fontSize: 16,
    color: '#666',
    marginBottom: 32,
  },
  regra: {
    alignItems: 'center',
    marginBottom: 24,
  },
  regraTitulo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  regraValor: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  aviso: {
    fontSize: 16,
    color: '#c62828',
    textAlign: 'center',
  },
  scanning: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
    marginBottom: 40,
  },
  angulo: {
    fontSize: 48,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  status: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 40,
  },
  statusCorreta: {
    color: '#2e7d32',
  },
  statusIncorreta: {
    color: '#c62828',
  },
  bgCorreta: {
    backgroundColor: '#e8f5e9',
  },
  bgIncorreta: {
    backgroundColor: '#ffebee',
  },
  botao: {
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    marginTop: 16,
  },
  botaoIniciar: {
    backgroundColor: '#1976d2',
  },
  botaoEncerrar: {
    backgroundColor: '#c62828',
  },
  botaoDesabilitado: {
    backgroundColor: '#90caf9',
  },
  botaoSecundario: {
    borderWidth: 1,
    borderColor: '#1976d2',
  },
  botaoSecundarioTexto: {
    color: '#1976d2',
    fontSize: 16,
    fontWeight: 'bold',
  },
  botaoTexto: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
})
