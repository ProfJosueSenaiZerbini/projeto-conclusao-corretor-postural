import { useState } from 'react'
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native'
import { apiFetch } from '../services/api.js'
import { useAuthStore } from '../store/authStore.js'

export default function LoginScreen({ navigation }) {
  const setUser = useAuthStore((state) => state.setUser)
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleLogin() {
    setErro('')
    setLoading(true)

    try {
      const user = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: email.trim(), senha }),
      })
      setUser(user)
    } catch (err) {
      if (err.status === 403 && err.body?.codigo === 'PRIMEIRO_ACESSO') {
        // Usuário pendente: segue para o primeiro acesso com e-mail e senha temporária preenchidos
        navigation.navigate('PrimeiroAcesso', { email: email.trim(), senha })
      } else if (err.status === 401) {
        setErro('E-mail ou senha inválidos')
      } else {
        setErro('Erro ao conectar com o servidor')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SIME</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        placeholderTextColor="#999"
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        value={email}
        onChangeText={setEmail}
        editable={!loading}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        placeholderTextColor="#999"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        editable={!loading}
      />

      {erro !== '' && <Text style={styles.erro}>{erro}</Text>}

      <Pressable
        style={[styles.botao, loading && styles.botaoDesabilitado]}
        onPress={handleLogin}
        disabled={loading}
      >
        <Text style={styles.botaoTexto}>{loading ? 'Entrando...' : 'Entrar'}</Text>
      </Pressable>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 32,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 40,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    marginBottom: 16,
    color: '#333',
  },
  erro: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  botao: {
    backgroundColor: '#1976d2',
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  botaoDesabilitado: {
    backgroundColor: '#90caf9',
  },
  botaoTexto: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
})
