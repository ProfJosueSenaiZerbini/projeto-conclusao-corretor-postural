import { View, Text, ScrollView, StyleSheet } from 'react-native'

export default function LaudoDetailScreen({ route }) {
  const { laudo } = route.params

  const dataFormatada = new Date(laudo.criado_em).toLocaleDateString('pt-BR')

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.label}>Laudo</Text>
      <Text style={styles.data}>{dataFormatada}</Text>

      <View style={[styles.statusBox, laudo.assinado ? styles.assinadoBg : styles.pendenteBg]}>
        <Text style={laudo.assinado ? styles.assinadoTexto : styles.pendenteTexto}>
          {laudo.assinado
            ? `✓ Assinado em ${new Date(laudo.assinado_em).toLocaleDateString('pt-BR')}`
            : 'Aguardando assinatura'}
        </Text>
      </View>

      <Text style={styles.conteudoLabel}>Conteúdo</Text>
      <Text style={styles.conteudo}>{laudo.conteudo}</Text>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    padding: 20,
  },
  label: {
    fontSize: 14,
    color: '#999',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  data: {
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 4,
    marginBottom: 20,
    color: '#333',
  },
  statusBox: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 24,
  },
  assinadoBg: {
    backgroundColor: '#e8f5e9',
  },
  pendenteBg: {
    backgroundColor: '#f5f5f5',
  },
  assinadoTexto: {
    fontSize: 15,
    color: '#2e7d32',
    fontWeight: '600',
  },
  pendenteTexto: {
    fontSize: 15,
    color: '#999',
    fontWeight: '600',
  },
  conteudoLabel: {
    fontSize: 14,
    color: '#999',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 8,
  },
  conteudo: {
    fontSize: 16,
    lineHeight: 24,
    color: '#333',
  },
})
