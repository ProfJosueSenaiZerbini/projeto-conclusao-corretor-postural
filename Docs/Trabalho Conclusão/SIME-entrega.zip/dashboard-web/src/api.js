// Em produção (Vercel): VITE_API_URL = URL da API no Render, ex.: https://sime-api.onrender.com
// Vazio em desenvolvimento: o proxy do Vite repassa as rotas da API (vite.config.js)
export const BASE_URL = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '')

const STORAGE_KEY = 'sime_user'

function lerToken() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY))?.token ?? null
  } catch {
    return null
  }
}

export async function apiFetch(path, options = {}) {
  const token = lerToken()

  const res = await fetch(BASE_URL + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  })
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    // body fica no erro para quem precisa de campos além da mensagem (ex.: codigo PRIMEIRO_ACESSO)
    throw Object.assign(new Error(body.erros?.[0] ?? 'Erro na requisição'), {
      status: res.status,
      body,
    })
  }
  return res.json()
}
