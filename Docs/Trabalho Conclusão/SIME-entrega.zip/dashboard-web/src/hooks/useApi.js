import { useEffect, useState } from 'react'
import { apiFetch } from '../api.js'

// Cópia do hook da DashboardPage (mesma assinatura e comportamento).
// Busca `path` e refaz quando ele muda; ignora respostas de buscas antigas.
// "carregando" é derivado: enquanto a resposta guardada não for do path atual.
export function useApi(path) {
  const [resposta, setResposta] = useState({ path: null, dados: null, erro: '' })

  useEffect(() => {
    let ativo = true
    apiFetch(path)
      .then((dados) => ativo && setResposta({ path, dados, erro: '' }))
      .catch((err) => ativo && setResposta({ path, dados: null, erro: err.message }))
    return () => {
      ativo = false
    }
  }, [path])

  if (resposta.path !== path) {
    return { dados: null, erro: '', carregando: true }
  }
  return { dados: resposta.dados, erro: resposta.erro, carregando: false }
}
