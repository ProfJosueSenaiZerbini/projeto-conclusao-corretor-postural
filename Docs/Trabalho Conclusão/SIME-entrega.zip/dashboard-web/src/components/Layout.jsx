import { useLocation, useNavigate } from 'react-router-dom'
import {
  AppBar,
  Box,
  Button,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
} from '@mui/material'
import HealthAndSafety from '@mui/icons-material/HealthAndSafety'
import DashboardOutlined from '@mui/icons-material/DashboardOutlined'
import PeopleOutlined from '@mui/icons-material/PeopleOutlined'
import TuneOutlined from '@mui/icons-material/TuneOutlined'
import AssessmentOutlined from '@mui/icons-material/AssessmentOutlined'
import AssignmentOutlined from '@mui/icons-material/AssignmentOutlined'
import GroupOutlined from '@mui/icons-material/GroupOutlined'
import LinkOutlined from '@mui/icons-material/LinkOutlined'
import LogoutOutlined from '@mui/icons-material/LogoutOutlined'
import { useAuth } from '../contexts/AuthContext.jsx'

const DRAWER_WIDTH = 240
const AZUL = '#0D47A1'

const ITENS = [
  { label: 'Início', path: '/dashboard', icon: DashboardOutlined, roles: ['MEDICO', 'GESTOR'] },
  { label: 'Pacientes', path: '/pacientes', icon: PeopleOutlined, roles: ['MEDICO'] },
  { label: 'Laudos', path: '/laudos', icon: AssignmentOutlined, roles: ['MEDICO'] },
  { label: 'Relatório', path: '/relatorio', icon: AssessmentOutlined, roles: ['GESTOR'] },
  { label: 'Pessoas', path: '/pessoas', icon: GroupOutlined, roles: ['GESTOR'] },
  { label: 'Vínculos', path: '/vinculos', icon: LinkOutlined, roles: ['GESTOR'] },
  { label: 'Regras', path: '/regras', icon: TuneOutlined, roles: ['MEDICO', 'GESTOR'] },
]

const TITULOS = {
  '/dashboard': 'Início',
  '/laudos': 'Laudos',
  '/pacientes': 'Pacientes',
  '/regras': 'Regras',
  '/relatorio': 'Relatório',
  '/pessoas': 'Pessoas',
  '/vinculos': 'Vínculos',
}

export default function Layout({ children }) {
  const { user, logout } = useAuth()
  const { pathname } = useLocation()
  const navigate = useNavigate()

  const itensVisiveis = ITENS.filter((item) => item.roles.includes(user?.role))

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar
        position="fixed"
        sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, bgcolor: AZUL }}
      >
        <Toolbar>
          <Typography variant="h6" noWrap>
            {TITULOS[pathname] ?? ''}
          </Typography>
        </Toolbar>
      </AppBar>

      <Drawer
        variant="permanent"
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: DRAWER_WIDTH,
            boxSizing: 'border-box',
            bgcolor: AZUL,
            color: '#fff',
            display: 'flex',
            flexDirection: 'column',
          },
        }}
      >
        <Toolbar sx={{ gap: 1 }}>
          <HealthAndSafety sx={{ color: '#fff' }} />
          <Typography variant="h6">SIME</Typography>
        </Toolbar>

        <List>
          {itensVisiveis.map(({ label, path, icon: Icon }) => {
            const ativo = pathname === path
            return (
              <ListItemButton
                key={path}
                onClick={() => navigate(path)}
                sx={{
                  mx: 1,
                  borderRadius: '8px',
                  color: ativo ? AZUL : '#fff',
                  bgcolor: ativo ? '#fff' : 'transparent',
                  '&:hover': { bgcolor: ativo ? '#fff' : 'rgba(255, 255, 255, 0.12)' },
                }}
              >
                <ListItemIcon sx={{ color: 'inherit', minWidth: 40 }}>
                  <Icon />
                </ListItemIcon>
                <ListItemText primary={label} />
              </ListItemButton>
            )
          })}
        </List>

        <Box sx={{ mt: 'auto', p: 2 }}>
          <Typography variant="body2" sx={{ mb: 1 }}>
            {user?.nome}
          </Typography>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<LogoutOutlined />}
            onClick={logout}
            sx={{ color: '#fff', borderColor: 'rgba(255, 255, 255, 0.5)' }}
          >
            Sair
          </Button>
        </Box>
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Toolbar />
        {children}
      </Box>
    </Box>
  )
}
