import { createBrowserRouter, Navigate, RouterProvider } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import Layout from './components/Layout.jsx'
import LoginPage from './pages/LoginPage.jsx'
import PrimeiroAcessoPage from './pages/PrimeiroAcessoPage.jsx'
import DashboardPage from './pages/DashboardPage.jsx'
import LaudosPage from './pages/LaudosPage.jsx'
import PacientesPage from './pages/PacientesPage.jsx'
import PessoasPage from './pages/PessoasPage.jsx'
import RegrasPage from './pages/RegrasPage.jsx'
import RelatorioPage from './pages/RelatorioPage.jsx'
import VinculosPage from './pages/VinculosPage.jsx'

const router = createBrowserRouter([
  { path: '/login', element: <LoginPage /> },
  { path: '/primeiro-acesso', element: <PrimeiroAcessoPage /> },
  {
    path: '/',
    element: <ProtectedRoute roles={['MEDICO', 'GESTOR']} />,
    children: [
      { index: true, element: <Navigate to="/dashboard" replace /> },
      { path: 'dashboard', element: <Layout><DashboardPage /></Layout> },
      { path: 'regras', element: <Layout><RegrasPage /></Layout> },
      {
        path: 'pacientes',
        element: <ProtectedRoute roles={['MEDICO']} />,
        children: [{ index: true, element: <Layout><PacientesPage /></Layout> }],
      },
      {
        path: 'laudos',
        element: <ProtectedRoute roles={['MEDICO']} />,
        children: [{ index: true, element: <Layout><LaudosPage /></Layout> }],
      },
      {
        path: 'relatorio',
        element: <ProtectedRoute roles={['GESTOR']} />,
        children: [{ index: true, element: <Layout><RelatorioPage /></Layout> }],
      },
      {
        path: 'pessoas',
        element: <ProtectedRoute roles={['GESTOR']} />,
        children: [{ index: true, element: <Layout><PessoasPage /></Layout> }],
      },
      {
        path: 'vinculos',
        element: <ProtectedRoute roles={['GESTOR']} />,
        children: [{ index: true, element: <Layout><VinculosPage /></Layout> }],
      },
    ],
  },
  { path: '*', element: <Navigate to="/dashboard" replace /> },
])

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  )
}
