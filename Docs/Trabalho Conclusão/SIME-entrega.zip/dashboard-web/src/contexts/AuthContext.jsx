import { createContext, useContext, useState } from 'react'
import { apiFetch } from '../api.js'

const STORAGE_KEY = 'sime_user'

// Mesma mensagem no login e no primeiro acesso de TRABALHADOR
export const MSG_ACESSO_RESTRITO = 'Acesso restrito a médicos e gestores.'

export const AuthContext = createContext(null)

function carregarUsuario() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY))
  } catch {
    return null
  }
}

export function AuthProvider({ children }) {
  // user = { id, nome, email, role, setor_id, token } | null
  const [user, setUser] = useState(carregarUsuario)

  function guardarUsuario(usuario) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(usuario))
    setUser(usuario)
  }

  async function login(email, senha) {
    const usuario = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, senha }),
    })

    if (usuario.role === 'TRABALHADOR') {
      throw new Error(MSG_ACESSO_RESTRITO)
    }

    guardarUsuario(usuario)
  }

  // Troca a senha temporária e registra o aceite; a resposta tem o formato do login.
  // TRABALHADOR: a conta é ativada na API, mas o usuário não é guardado (contaAtivada no erro).
  async function primeiroAcesso(email, senhaTemporaria, novaSenha) {
    const usuario = await apiFetch('/auth/primeiro-acesso', {
      method: 'POST',
      body: JSON.stringify({
        email,
        senha_temporaria: senhaTemporaria,
        nova_senha: novaSenha,
        aceite: true,
      }),
    })

    if (usuario.role === 'TRABALHADOR') {
      throw Object.assign(new Error(MSG_ACESSO_RESTRITO), { contaAtivada: true })
    }

    guardarUsuario(usuario)
  }

  // Sem redirecionar aqui: o AuthProvider fica fora do router. Com user null,
  // o ProtectedRoute leva para /login.
  function logout() {
    localStorage.removeItem(STORAGE_KEY)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, primeiroAcesso, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
