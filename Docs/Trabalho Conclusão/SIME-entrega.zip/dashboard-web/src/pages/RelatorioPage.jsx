import { useEffect, useState } from 'react'
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material'
import FileDownloadOutlined from '@mui/icons-material/FileDownloadOutlined'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { apiFetch } from '../api.js'

// Apenas dados agregados por setor; nunca dados individuais de colaborador.

const AVISO_PRIVACIDADE =
  'Este painel exibe apenas dados agregados por setor. Nenhum dado individual de colaborador é exibido.'
const SEM_DADOS = 'Setor ainda sem dados disponíveis'

// Junta as respostas de semana e mês por setor_id, na ordem recebida da API.
function combinarPeriodos(semana, mes) {
  const mesPorSetor = new Map(mes.map((s) => [s.setor_id, s]))
  const ids = [...semana.map((s) => s.setor_id), ...mes.map((s) => s.setor_id)]
  const semanaPorSetor = new Map(semana.map((s) => [s.setor_id, s]))

  return [...new Set(ids)].map((id) => {
    const s = semanaPorSetor.get(id)
    const m = mesPorSetor.get(id)
    const semDados = (s?.score_medio ?? null) === null && (m?.score_medio ?? null) === null
    return {
      setor_id: id,
      nome: s?.nome ?? m?.nome,
      score_semana: s?.score_medio ?? null,
      score_mes: m?.score_medio ?? null,
      participantes_semana: s?.participantes_ativos ?? 0,
      participantes_mes: m?.participantes_ativos ?? 0,
      alertas_semana: s?.total_alertas ?? 0,
      alertas_mes: m?.total_alertas ?? 0,
      semDados,
    }
  })
}

function formatarScore(score) {
  return score === null ? '—' : Math.round(score)
}

// ── CSV ────────────────────────────────────────────────

function celulaCsv(valor) {
  const texto = valor === null || valor === undefined ? '' : String(valor)
  return /[;"\n]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto
}

function exportarCsv(setores) {
  const cabecalho = [
    'setor',
    'score_semana',
    'score_mes',
    'participantes_semana',
    'participantes_mes',
    'alertas_semana',
    'alertas_mes',
  ]
  const linhas = setores.map((s) => [
    s.nome,
    s.score_semana === null ? null : Math.round(s.score_semana),
    s.score_mes === null ? null : Math.round(s.score_mes),
    s.participantes_semana,
    s.participantes_mes,
    s.alertas_semana,
    s.alertas_mes,
  ])
  const csv = [cabecalho, ...linhas].map((linha) => linha.map(celulaCsv).join(';')).join('\r\n')

  // BOM UTF-8 para o Excel pt-BR abrir acentos corretamente
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)

  const hoje = new Date()
  const data = [
    hoje.getFullYear(),
    String(hoje.getMonth() + 1).padStart(2, '0'),
    String(hoje.getDate()).padStart(2, '0'),
  ].join('-')

  const link = document.createElement('a')
  link.href = url
  link.download = `relatorio-setores-${data}.csv`
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}

// ── Página ─────────────────────────────────────────────

export default function RelatorioPage() {
  const [setores, setSetores] = useState(null)
  const [erro, setErro] = useState('')
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    let ativo = true
    Promise.all([
      apiFetch('/setores/resumo?periodo=semana'),
      apiFetch('/setores/resumo?periodo=mes'),
    ])
      .then(([semana, mes]) => ativo && setSetores(combinarPeriodos(semana, mes)))
      .catch((err) => ativo && setErro(err.message))
      .finally(() => ativo && setCarregando(false))
    return () => {
      ativo = false
    }
  }, [])

  let conteudo
  if (carregando) {
    conteudo = (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    )
  } else if (erro) {
    conteudo = <Alert severity="error">{erro}</Alert>
  } else if (!setores || setores.length === 0) {
    conteudo = <Typography color="text.secondary">Nenhum dado encontrado.</Typography>
  } else {
    const comDados = setores.filter((s) => !s.semDados)
    const semDados = setores.filter((s) => s.semDados)
    const dadosGrafico = comDados.map((s) => ({
      nome: s.nome,
      Semana: s.score_semana === null ? null : Math.round(s.score_semana),
      Mês: s.score_mes === null ? null : Math.round(s.score_mes),
    }))

    conteudo = (
      <>
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 1 }}>
            Score médio por setor
          </Typography>

          {comDados.length > 0 && (
            <Box sx={{ height: 320 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dadosGrafico}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="nome" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Semana" fill="#1565C0" />
                  <Bar dataKey="Mês" fill="#90CAF9" />
                </BarChart>
              </ResponsiveContainer>
            </Box>
          )}

          {semDados.map((s) => (
            <Typography key={s.setor_id} variant="body2" color="text.secondary">
              {s.nome}: {SEM_DADOS}
            </Typography>
          ))}
        </Paper>

        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Setor</TableCell>
                <TableCell align="right">Score (semana)</TableCell>
                <TableCell align="right">Score (mês)</TableCell>
                <TableCell align="right">Participantes (semana)</TableCell>
                <TableCell align="right">Participantes (mês)</TableCell>
                <TableCell align="right">Alertas (semana)</TableCell>
                <TableCell align="right">Alertas (mês)</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {setores.map((s) => (
                <TableRow key={s.setor_id}>
                  <TableCell>{s.nome}</TableCell>
                  {s.semDados ? (
                    <TableCell colSpan={6} sx={{ color: 'text.secondary' }}>
                      {SEM_DADOS}
                    </TableCell>
                  ) : (
                    <>
                      <TableCell align="right">{formatarScore(s.score_semana)}</TableCell>
                      <TableCell align="right">{formatarScore(s.score_mes)}</TableCell>
                      <TableCell align="right">{s.participantes_semana}</TableCell>
                      <TableCell align="right">{s.participantes_mes}</TableCell>
                      <TableCell align="right">{s.alertas_semana}</TableCell>
                      <TableCell align="right">{s.alertas_mes}</TableCell>
                    </>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </>
    )
  }

  const podeExportar = !carregando && !erro && setores && setores.length > 0

  return (
    <>
      <Alert severity="info" sx={{ mb: 3 }}>
        {AVISO_PRIVACIDADE}
      </Alert>

      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Relatório por setor</Typography>
        <Button
          variant="outlined"
          startIcon={<FileDownloadOutlined />}
          onClick={() => exportarCsv(setores)}
          disabled={!podeExportar}
        >
          Exportar CSV
        </Button>
      </Box>

      {conteudo}
    </>
  )
}
