import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from '@mui/material'
import { apiFetch } from '../api.js'
import { useApi } from '../hooks/useApi.js'

// Vínculos médico–trabalhador (só GESTOR).
// Política do projeto: aqui aparecem só o nome do médico e o nome e o setor do trabalhador;
// o e-mail aparece apenas na tela de Pessoas.

const FILTROS = [
  { valor: 'ativos', rotulo: 'Ativos', query: '?ativo=true' },
  { valor: 'encerrados', rotulo: 'Encerrados', query: '?ativo=false' },
  { valor: 'todos', rotulo: 'Todos', query: '' },
]

function formatarData(iso) {
  return new Date(iso).toLocaleDateString('pt-BR')
}

function rotuloTrabalhador(t) {
  return t.setor ? `${t.nome} — ${t.setor.nome}` : t.nome
}

function mensagemErro(err) {
  // fetch lança TypeError quando não alcança o servidor (API ou proxy fora do ar)
  return err instanceof TypeError ? 'Erro de conexão com o servidor' : err.message
}

function Carregando() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
      <CircularProgress />
    </Box>
  )
}

// ── Novo vínculo ───────────────────────────────────────

function FormularioVinculo({ onCriado }) {
  const [medicoId, setMedicoId] = useState('')
  const [trabalhadorId, setTrabalhadorId] = useState('')
  const [erro, setErro] = useState('')
  const [salvando, setSalvando] = useState(false)

  const {
    dados: medicos,
    erro: erroMedicos,
    carregando: carregandoMedicos,
  } = useApi('/usuarios?role=MEDICO')
  const {
    dados: trabalhadores,
    erro: erroTrabalhadores,
    carregando: carregandoTrabalhadores,
  } = useApi('/usuarios?role=TRABALHADOR&sem_vinculo=true')

  const semTrabalhadores =
    !carregandoTrabalhadores && !erroTrabalhadores && (trabalhadores ?? []).length === 0
  const podeVincular = medicoId !== '' && trabalhadorId !== '' && !salvando

  async function handleSubmit(event) {
    event.preventDefault()
    setErro('')
    setSalvando(true)
    try {
      await apiFetch('/vinculos', {
        method: 'POST',
        body: JSON.stringify({ medico_id: medicoId, trabalhador_id: trabalhadorId }),
      })
      // A página recarrega a tabela e este formulário (com a lista de trabalhadores livres)
      onCriado()
    } catch (err) {
      setErro(mensagemErro(err))
      setSalvando(false)
    }
  }

  return (
    <Paper component="form" onSubmit={handleSubmit} sx={{ p: 3, mb: 4 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
        Novo vínculo
      </Typography>

      <Stack spacing={2} sx={{ maxWidth: 480 }}>
        <FormControl
          required
          disabled={salvando || carregandoMedicos || Boolean(erroMedicos)}
          error={Boolean(erroMedicos)}
        >
          <InputLabel id="medico-label">Médico</InputLabel>
          <Select
            labelId="medico-label"
            label="Médico"
            value={medicoId}
            onChange={(e) => setMedicoId(e.target.value)}
          >
            {(medicos ?? []).map((m) => (
              <MenuItem key={m.id} value={m.id}>
                {m.nome}
              </MenuItem>
            ))}
          </Select>
          {erroMedicos && <FormHelperText>{erroMedicos}</FormHelperText>}
        </FormControl>

        <FormControl
          required
          disabled={
            salvando || carregandoTrabalhadores || Boolean(erroTrabalhadores) || semTrabalhadores
          }
          error={Boolean(erroTrabalhadores)}
        >
          <InputLabel id="trabalhador-label">Trabalhador</InputLabel>
          <Select
            labelId="trabalhador-label"
            label="Trabalhador"
            value={trabalhadorId}
            onChange={(e) => setTrabalhadorId(e.target.value)}
          >
            {(trabalhadores ?? []).map((t) => (
              <MenuItem key={t.id} value={t.id}>
                {rotuloTrabalhador(t)}
              </MenuItem>
            ))}
          </Select>
          {erroTrabalhadores && <FormHelperText>{erroTrabalhadores}</FormHelperText>}
          {semTrabalhadores && (
            <FormHelperText>Nenhum trabalhador sem vínculo ativo.</FormHelperText>
          )}
        </FormControl>

        {erro && <Alert severity="error">{erro}</Alert>}

        <Box>
          <Button type="submit" variant="contained" disabled={!podeVincular}>
            {salvando ? <CircularProgress size={24} color="inherit" /> : 'Vincular'}
          </Button>
        </Box>
      </Stack>
    </Paper>
  )
}

// ── Tabela + encerramento ──────────────────────────────

function TabelaVinculos({ query, onEncerrado }) {
  const { dados: vinculos, erro, carregando } = useApi(`/vinculos${query}`)

  // Vínculo aguardando confirmação de encerramento (null = diálogo fechado)
  const [encerrando, setEncerrando] = useState(null)
  const [erroDialogo, setErroDialogo] = useState('')
  const [processando, setProcessando] = useState(false)

  function abrirDialogo(vinculo) {
    setErroDialogo('')
    setEncerrando(vinculo)
  }

  function fecharDialogo() {
    if (!processando) setEncerrando(null)
  }

  async function confirmarEncerramento() {
    setErroDialogo('')
    setProcessando(true)
    try {
      await apiFetch(`/vinculos/${encerrando.id}/encerrar`, { method: 'PATCH' })
      // A página recarrega esta tabela (o diálogo some) e a lista de trabalhadores livres
      onEncerrado()
    } catch (err) {
      setErroDialogo(mensagemErro(err))
      setProcessando(false)
    }
  }

  let conteudo
  if (carregando) {
    conteudo = <Carregando />
  } else if (erro) {
    conteudo = <Alert severity="error">{erro}</Alert>
  } else if (!vinculos || vinculos.length === 0) {
    conteudo = <Typography color="text.secondary">Nenhum vínculo encontrado.</Typography>
  } else {
    conteudo = (
      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Médico</TableCell>
              <TableCell>Trabalhador</TableCell>
              <TableCell>Setor</TableCell>
              <TableCell>Vinculado em</TableCell>
              <TableCell>Encerrado em</TableCell>
              <TableCell />
            </TableRow>
          </TableHead>
          <TableBody>
            {vinculos.map((v) => (
              <TableRow key={v.id}>
                <TableCell>{v.medico.nome}</TableCell>
                <TableCell>{v.trabalhador.nome}</TableCell>
                <TableCell>{v.trabalhador.setor?.nome ?? '—'}</TableCell>
                <TableCell>{formatarData(v.vinculado_em)}</TableCell>
                <TableCell>{v.encerrado_em ? formatarData(v.encerrado_em) : '—'}</TableCell>
                <TableCell align="right">
                  {!v.encerrado_em && (
                    <Button size="small" color="error" onClick={() => abrirDialogo(v)}>
                      Encerrar
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    )
  }

  return (
    <>
      {conteudo}

      <Dialog open={encerrando !== null} onClose={fecharDialogo}>
        <DialogTitle>Encerrar vínculo</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Encerrar o vínculo entre {encerrando?.medico.nome} e {encerrando?.trabalhador.nome}?
          </DialogContentText>
          {erroDialogo && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {erroDialogo}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={fecharDialogo} disabled={processando}>
            Cancelar
          </Button>
          <Button color="error" onClick={confirmarEncerramento} disabled={processando}>
            {processando ? <CircularProgress size={24} color="inherit" /> : 'Encerrar'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}

// ── Página ─────────────────────────────────────────────

export default function VinculosPage() {
  const [filtro, setFiltro] = useState('ativos')
  // Muda a cada criação ou encerramento: remonta formulário e tabela, que buscam de novo na API
  const [versao, setVersao] = useState(0)
  const recarregar = () => setVersao((v) => v + 1)

  const { query } = FILTROS.find((f) => f.valor === filtro)

  return (
    <>
      <FormularioVinculo key={`formulario-${versao}`} onCriado={recarregar} />

      <ToggleButtonGroup
        exclusive
        size="small"
        value={filtro}
        // Clicar no botão já selecionado manda null; mantém o filtro atual
        onChange={(_e, valor) => valor && setFiltro(valor)}
        sx={{ mb: 3 }}
      >
        {FILTROS.map(({ valor, rotulo }) => (
          <ToggleButton key={valor} value={valor}>
            {rotulo}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>

      <TabelaVinculos key={`tabela-${versao}`} query={query} onEncerrado={recarregar} />
    </>
  )
}
