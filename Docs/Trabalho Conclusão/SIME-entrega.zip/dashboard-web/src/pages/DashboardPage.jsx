import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Grid,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from '@mui/material'
import { useAuth } from '../contexts/AuthContext.jsx'
import { apiFetch } from '../api.js'

// Busca `path` e refaz quando ele muda; ignora respostas de buscas antigas.
// "carregando" é derivado: enquanto a resposta guardada não for do path atual.
function useApi(path) {
  const [resposta, setResposta] = useState({ path: null, dados: null, erro: '' })

  useEffect(() => {
    let ativo = true
    apiFetch(path)
      .then((dados) => ativo && setResposta({ path, dados, erro: '' }))
      .catch((err) => ativo && setResposta({ path, dados: null, erro: err.message }))
    return () => {
      ativo = false
    }
  }, [path])

  if (resposta.path !== path) {
    return { dados: null, erro: '', carregando: true }
  }
  return { dados: resposta.dados, erro: resposta.erro, carregando: false }
}

function Carregando() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
      <CircularProgress />
    </Box>
  )
}

function NenhumDado() {
  return <Typography color="text.secondary">Nenhum dado encontrado.</Typography>
}

// ── MEDICO ─────────────────────────────────────────────

function PainelMedico() {
  const { dados: laudos, erro, carregando } = useApi('/laudos')

  if (carregando) return <Carregando />
  if (erro) return <Alert severity="error">{erro}</Alert>
  if (!laudos || laudos.length === 0) return <NenhumDado />

  const cards = [
    { rotulo: 'Laudos para assinar', valor: laudos.filter((l) => !l.assinado).length },
    { rotulo: 'Laudos assinados', valor: laudos.filter((l) => l.assinado).length },
    { rotulo: 'Total de laudos', valor: laudos.length },
  ]

  return (
    <Grid container spacing={3}>
      {cards.map(({ rotulo, valor }) => (
        <Grid key={rotulo} size={{ xs: 12, md: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h3">{valor}</Typography>
              <Typography variant="body2" color="text.secondary">
                {rotulo}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  )
}

// ── GESTOR ─────────────────────────────────────────────
// Apenas dados agregados por setor; nunca dados individuais.

function PainelGestor() {
  const navigate = useNavigate()
  const [periodo, setPeriodo] = useState('semana')
  const { dados: setores, erro, carregando } = useApi(`/setores/resumo?periodo=${periodo}`)

  let conteudo
  if (carregando) {
    conteudo = <Carregando />
  } else if (erro) {
    conteudo = <Alert severity="error">{erro}</Alert>
  } else if (!setores || setores.length === 0) {
    conteudo = <NenhumDado />
  } else {
    conteudo = (
      <Grid container spacing={3}>
        {setores.map((setor) => (
          <Grid key={setor.setor_id} size={{ xs: 12, md: 6 }}>
            <Card>
              <CardContent>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                  {setor.nome}
                </Typography>
                <Typography variant="h4">
                  {setor.score_medio === null ? '—' : Math.round(setor.score_medio)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {setor.participantes_ativos} participantes
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {setor.total_alertas} alertas
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    )
  }

  return (
    <>
      <ToggleButtonGroup
        exclusive
        size="small"
        value={periodo}
        // Clicar no botão já selecionado manda null; mantém o período atual
        onChange={(_e, valor) => valor && setPeriodo(valor)}
        sx={{ mb: 3 }}
      >
        <ToggleButton value="semana">Última semana</ToggleButton>
        <ToggleButton value="mes">Último mês</ToggleButton>
      </ToggleButtonGroup>

      {conteudo}

      <Box sx={{ mt: 3 }}>
        <Button variant="outlined" onClick={() => navigate('/relatorio')}>
          Ver relatório completo
        </Button>
      </Box>
    </>
  )
}

// ── Página ─────────────────────────────────────────────

export default function DashboardPage() {
  const { user } = useAuth()

  // Calculada uma vez ao montar a página
  const [hoje] = useState(() =>
    new Date().toLocaleDateString('pt-BR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }),
  )

  return (
    <>
      <Typography variant="h5">Olá, {user.nome}</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        {hoje}
      </Typography>

      {user.role === 'GESTOR' ? <PainelGestor /> : <PainelMedico />}
    </>
  )
}
