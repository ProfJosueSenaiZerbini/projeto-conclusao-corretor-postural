import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material'
import { apiFetch } from '../api.js'
import { useApi } from '../hooks/useApi.js'

// Pessoas (só GESTOR): lista de médicos e trabalhadores e pré-cadastro com senha temporária.
// Não há edição nem exclusão de pessoa (a API não tem).

const PERFIS = [
  { valor: 'MEDICO', rotulo: 'Médico' },
  { valor: 'TRABALHADOR', rotulo: 'Trabalhador' },
]
const ROTULO_PERFIL = Object.fromEntries(PERFIS.map(({ valor, rotulo }) => [valor, rotulo]))

const SITUACAO = {
  PENDENTE: { rotulo: 'Pendente', cor: 'warning' },
  ATIVO: { rotulo: 'Ativo', cor: 'success' },
}

const FORMULARIO_VAZIO = { nome: '', email: '', role: '', setor_id: '', senha_temporaria: '' }

function Carregando() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
      <CircularProgress />
    </Box>
  )
}

// ── Pré-cadastro ───────────────────────────────────────

function FormularioPessoa({ onCadastrada }) {
  const [valores, setValores] = useState(FORMULARIO_VAZIO)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [salvando, setSalvando] = useState(false)

  // Lista de setores para o seletor (só setor_id e nome são usados)
  const {
    dados: setores,
    erro: erroSetores,
    carregando: carregandoSetores,
  } = useApi('/setores/resumo')

  const ehTrabalhador = valores.role === 'TRABALHADOR'

  function alterar(campo, valor) {
    setValores((v) => ({ ...v, [campo]: valor }))
    setSucesso('')
  }

  // Médico não tem setor: trocar o perfil limpa o setor escolhido
  function alterarPerfil(role) {
    setValores((v) => ({ ...v, role, setor_id: '' }))
    setSucesso('')
  }

  async function handleSubmit(event) {
    event.preventDefault()
    setErro('')
    setSucesso('')
    setSalvando(true)

    const corpo = {
      nome: valores.nome,
      email: valores.email,
      role: valores.role,
      senha_temporaria: valores.senha_temporaria,
      ...(ehTrabalhador && { setor_id: Number(valores.setor_id) }),
    }

    try {
      await apiFetch('/usuarios', { method: 'POST', body: JSON.stringify(corpo) })
      setValores(FORMULARIO_VAZIO)
      setSucesso('Pessoa cadastrada.')
      onCadastrada()
    } catch (err) {
      // fetch lança TypeError quando não alcança o servidor (API ou proxy fora do ar)
      setErro(err instanceof TypeError ? 'Erro de conexão com o servidor' : err.message)
    } finally {
      setSalvando(false)
    }
  }

  return (
    <Paper component="form" onSubmit={handleSubmit} sx={{ p: 3, mb: 4 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
        Pré-cadastrar pessoa
      </Typography>

      <Stack spacing={2} sx={{ maxWidth: 480 }}>
        <TextField
          label="Nome"
          value={valores.nome}
          onChange={(e) => alterar('nome', e.target.value)}
          disabled={salvando}
          required
        />
        <TextField
          label="E-mail"
          type="email"
          value={valores.email}
          onChange={(e) => alterar('email', e.target.value)}
          disabled={salvando}
          required
        />

        <FormControl required disabled={salvando}>
          <InputLabel id="perfil-label">Perfil</InputLabel>
          <Select
            labelId="perfil-label"
            label="Perfil"
            value={valores.role}
            onChange={(e) => alterarPerfil(e.target.value)}
          >
            {PERFIS.map(({ valor, rotulo }) => (
              <MenuItem key={valor} value={valor}>
                {rotulo}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {ehTrabalhador && (
          <FormControl
            required
            disabled={salvando || carregandoSetores || Boolean(erroSetores)}
            error={Boolean(erroSetores)}
          >
            <InputLabel id="setor-label">Setor</InputLabel>
            <Select
              labelId="setor-label"
              label="Setor"
              value={valores.setor_id}
              onChange={(e) => alterar('setor_id', e.target.value)}
            >
              {(setores ?? []).map((s) => (
                <MenuItem key={s.setor_id} value={s.setor_id}>
                  {s.nome}
                </MenuItem>
              ))}
            </Select>
            {erroSetores && <FormHelperText>{erroSetores}</FormHelperText>}
          </FormControl>
        )}

        <TextField
          label="Senha temporária"
          type="text"
          value={valores.senha_temporaria}
          onChange={(e) => alterar('senha_temporaria', e.target.value)}
          disabled={salvando}
          helperText="Mínimo de 6 caracteres, com letra e número."
          required
        />

        {erro && <Alert severity="error">{erro}</Alert>}
        {sucesso && <Alert severity="success">{sucesso}</Alert>}

        <Box>
          <Button type="submit" variant="contained" disabled={salvando}>
            {salvando ? <CircularProgress size={24} color="inherit" /> : 'Cadastrar'}
          </Button>
        </Box>
      </Stack>
    </Paper>
  )
}

// ── Lista ──────────────────────────────────────────────

function ListaPessoas() {
  const { dados: pessoas, erro, carregando } = useApi('/usuarios')

  if (carregando) return <Carregando />
  if (erro) return <Alert severity="error">{erro}</Alert>
  if (!pessoas || pessoas.length === 0) {
    return <Typography color="text.secondary">Nenhuma pessoa cadastrada.</Typography>
  }

  return (
    <TableContainer component={Paper}>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Nome</TableCell>
            <TableCell>E-mail</TableCell>
            <TableCell>Perfil</TableCell>
            <TableCell>Setor</TableCell>
            <TableCell>Situação</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {pessoas.map((p) => {
            const situacao = SITUACAO[p.status]
            return (
              <TableRow key={p.id}>
                <TableCell>{p.nome}</TableCell>
                <TableCell>{p.email}</TableCell>
                <TableCell>{ROTULO_PERFIL[p.role] ?? p.role}</TableCell>
                <TableCell>{p.setor?.nome ?? '—'}</TableCell>
                <TableCell>
                  <Chip
                    size="small"
                    label={situacao?.rotulo ?? p.status}
                    color={situacao?.cor ?? 'default'}
                  />
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </TableContainer>
  )
}

// ── Página ─────────────────────────────────────────────

export default function PessoasPage() {
  // Muda a cada cadastro: remonta a lista, que busca de novo na API
  const [versao, setVersao] = useState(0)

  return (
    <>
      <FormularioPessoa onCadastrada={() => setVersao((v) => v + 1)} />

      <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
        Pessoas cadastradas
      </Typography>
      <ListaPessoas key={versao} />
    </>
  )
}
