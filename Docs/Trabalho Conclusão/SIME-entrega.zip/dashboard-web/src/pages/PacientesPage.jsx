import { useState } from 'react'
import {
  Alert,
  Box,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from '@mui/material'
import { useApi } from '../hooks/useApi.js'

// Pacientes do médico logado (vínculo ativo), com o score de postura no período.

const PERIODOS = [
  { valor: 'semana', rotulo: 'Última semana' },
  { valor: 'mes', rotulo: 'Último mês' },
  { valor: 'geral', rotulo: 'Geral' },
]

function formatarData(iso) {
  return new Date(iso).toLocaleDateString('pt-BR')
}

export default function PacientesPage() {
  const [periodo, setPeriodo] = useState('semana')
  const { dados: pacientes, erro, carregando } = useApi(`/pacientes?periodo=${periodo}`)

  let conteudo
  if (carregando) {
    conteudo = (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    )
  } else if (erro) {
    conteudo = <Alert severity="error">{erro}</Alert>
  } else if (!pacientes || pacientes.length === 0) {
    conteudo = <Typography color="text.secondary">Nenhum paciente vinculado.</Typography>
  } else {
    conteudo = (
      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Nome</TableCell>
              <TableCell>Setor</TableCell>
              <TableCell>Vinculado em</TableCell>
              <TableCell align="right">Score</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pacientes.map((p) => (
              <TableRow key={p.id}>
                <TableCell>{p.nome}</TableCell>
                <TableCell>{p.setor?.nome ?? '—'}</TableCell>
                <TableCell>{formatarData(p.vinculado_em)}</TableCell>
                <TableCell
                  align="right"
                  sx={p.score === null ? { color: 'text.secondary' } : undefined}
                >
                  {p.score === null ? 'Sem dados' : p.score}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    )
  }

  return (
    <>
      <ToggleButtonGroup
        exclusive
        size="small"
        value={periodo}
        // Clicar no botão já selecionado manda null; mantém o período atual
        onChange={(_e, valor) => valor && setPeriodo(valor)}
        sx={{ mb: 3 }}
      >
        {PERIODOS.map(({ valor, rotulo }) => (
          <ToggleButton key={valor} value={valor}>
            {rotulo}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>

      {conteudo}
    </>
  )
}
