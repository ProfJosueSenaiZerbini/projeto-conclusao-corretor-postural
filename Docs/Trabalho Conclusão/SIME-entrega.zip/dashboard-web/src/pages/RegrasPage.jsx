import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material'
import { useApi } from '../hooks/useApi.js'

// Regra de postura vigente (a ativa) e histórico de versões, só leitura para todos os perfis.
// A regra é fixa (0° a 20°, 30 s) e aplicada pelo firmware do dispositivo; não é editável aqui.

const AVISO_REGRA_FIXA =
  'Regra fixa, aplicada pelo próprio dispositivo vestível. Não é possível alterá-la pelo sistema.'

function numero(valor) {
  return valor.toLocaleString('pt-BR')
}

// Faixa completa: "0° a 20° · 30 s"
function formatarFaixa(regra) {
  return `${numero(regra.angulo_minimo)}° a ${numero(regra.angulo_maximo)}° · ${numero(regra.tempo_minimo_segundos)} s`
}

function formatarDataHora(iso) {
  return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
}

function Carregando() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
      <CircularProgress />
    </Box>
  )
}

// ── Regra vigente ──────────────────────────────────────

function RegraVigente() {
  // A API devolve as ativas da mais recente para a mais antiga; vale a primeira
  const { dados: ativas, erro, carregando } = useApi('/regras?ativo=true')

  if (carregando) return <Carregando />
  if (erro) return <Alert severity="error">{erro}</Alert>

  const regra = ativas?.[0] ?? null

  if (!regra) {
    return <Typography color="text.secondary">Nenhuma regra ativa.</Typography>
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="subtitle2" color="text.secondary">
        Regra vigente
      </Typography>
      <Typography variant="h4" sx={{ mb: 2 }}>
        {formatarFaixa(regra)}
      </Typography>

      <Stack direction={{ xs: 'column', md: 'row' }} spacing={{ xs: 1, md: 4 }}>
        <Typography>
          <strong>Ângulo mínimo:</strong> {numero(regra.angulo_minimo)}°
        </Typography>
        <Typography>
          <strong>Ângulo máximo:</strong> {numero(regra.angulo_maximo)}°
        </Typography>
        <Typography>
          <strong>Tempo:</strong> {numero(regra.tempo_minimo_segundos)} s
        </Typography>
      </Stack>

      <Alert severity="info" sx={{ mt: 3 }}>
        {AVISO_REGRA_FIXA}
      </Alert>
    </Paper>
  )
}

// ── Histórico ──────────────────────────────────────────

function HistoricoRegras() {
  const { dados: regras, erro, carregando } = useApi('/regras')

  if (carregando) return <Carregando />
  if (erro) return <Alert severity="error">{erro}</Alert>
  if (!regras || regras.length === 0) {
    return <Typography color="text.secondary">Nenhuma regra cadastrada.</Typography>
  }

  return (
    <TableContainer component={Paper}>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Criada em</TableCell>
            <TableCell>Faixa</TableCell>
            <TableCell>Situação</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {regras.map((r) => (
            <TableRow key={r.id}>
              <TableCell>{formatarDataHora(r.criado_em)}</TableCell>
              <TableCell>{formatarFaixa(r)}</TableCell>
              <TableCell>
                <Chip
                  size="small"
                  label={r.ativo ? 'Ativa' : 'Inativa'}
                  color={r.ativo ? 'success' : 'default'}
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  )
}

// ── Página ─────────────────────────────────────────────

export default function RegrasPage() {
  const [mostrarHistorico, setMostrarHistorico] = useState(false)

  return (
    <>
      <RegraVigente />

      <Box sx={{ mt: 4 }}>
        <Button variant="outlined" onClick={() => setMostrarHistorico((m) => !m)} sx={{ mb: 2 }}>
          {mostrarHistorico ? 'Ocultar histórico' : 'Ver histórico'}
        </Button>
        {mostrarHistorico && <HistoricoRegras />}
      </Box>
    </>
  )
}
