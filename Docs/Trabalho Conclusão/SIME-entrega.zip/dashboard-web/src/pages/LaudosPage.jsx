import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from '@mui/material'
import { apiFetch } from '../api.js'
import { useApi } from '../hooks/useApi.js'

// Laudos do médico logado (só MEDICO). A API devolve apenas os laudos que ele emitiu;
// criar exige vínculo ativo com o paciente e só o autor assina.

const FILTROS = [
  { valor: 'todos', rotulo: 'Todos', query: '' },
  { valor: 'para-assinar', rotulo: 'Para assinar', query: '?assinado=false' },
  { valor: 'assinados', rotulo: 'Assinados', query: '?assinado=true' },
]

function formatarDataHora(iso) {
  return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
}

function nomePaciente(laudo) {
  return laudo.trabalhador?.nome ?? '—'
}

function mensagemErro(err) {
  // fetch lança TypeError quando não alcança o servidor (API ou proxy fora do ar)
  return err instanceof TypeError ? 'Erro de conexão com o servidor' : err.message
}

function Carregando() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
      <CircularProgress />
    </Box>
  )
}

function ConteudoLaudo({ texto }) {
  return (
    <Box
      sx={{
        border: 1,
        borderColor: 'divider',
        borderRadius: 1,
        p: 2,
        maxHeight: 320,
        overflowY: 'auto',
      }}
    >
      <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
        {texto}
      </Typography>
    </Box>
  )
}

// ── Novo laudo ─────────────────────────────────────────

// Limites do conteúdo, contados depois do trim. Devem coincidir com a API (api/src/routes/laudos.js).
const CONTEUDO_MINIMO = 20
const CONTEUDO_MAXIMO = 5000

function FormularioLaudo({ onCriado }) {
  const [trabalhadorId, setTrabalhadorId] = useState('')
  const [conteudo, setConteudo] = useState('')
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [salvando, setSalvando] = useState(false)

  // Pacientes com vínculo ativo com o médico (só id e nome são usados)
  const {
    dados: pacientes,
    erro: erroPacientes,
    carregando: carregandoPacientes,
  } = useApi('/pacientes?periodo=geral')

  const semPacientes = !carregandoPacientes && !erroPacientes && (pacientes ?? []).length === 0
  // Mesmo critério da API: tamanho depois do trim
  const tamanho = conteudo.trim().length
  const conteudoValido = tamanho >= CONTEUDO_MINIMO && tamanho <= CONTEUDO_MAXIMO
  const podeCriar = trabalhadorId !== '' && conteudoValido && !salvando

  async function handleSubmit(event) {
    event.preventDefault()
    setErro('')
    setSucesso('')
    setSalvando(true)
    try {
      await apiFetch('/laudos', {
        method: 'POST',
        body: JSON.stringify({ trabalhador_id: trabalhadorId, conteudo }),
      })
      setTrabalhadorId('')
      setConteudo('')
      setSucesso('Laudo criado.')
      onCriado()
    } catch (err) {
      setErro(mensagemErro(err))
    } finally {
      setSalvando(false)
    }
  }

  return (
    <Paper component="form" onSubmit={handleSubmit} sx={{ p: 3, mb: 4 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2 }}>
        Novo laudo
      </Typography>

      <Stack spacing={2} sx={{ maxWidth: 640 }}>
        <FormControl
          required
          disabled={salvando || carregandoPacientes || Boolean(erroPacientes) || semPacientes}
          error={Boolean(erroPacientes)}
        >
          <InputLabel id="paciente-label">Paciente</InputLabel>
          <Select
            labelId="paciente-label"
            label="Paciente"
            value={trabalhadorId}
            onChange={(e) => {
              setTrabalhadorId(e.target.value)
              setSucesso('')
            }}
          >
            {(pacientes ?? []).map((p) => (
              <MenuItem key={p.id} value={p.id}>
                {p.nome}
              </MenuItem>
            ))}
          </Select>
          {erroPacientes && <FormHelperText>{erroPacientes}</FormHelperText>}
          {semPacientes && <FormHelperText>Nenhum paciente vinculado.</FormHelperText>}
        </FormControl>

        <TextField
          label="Conteúdo"
          multiline
          minRows={4}
          value={conteudo}
          onChange={(e) => {
            setConteudo(e.target.value)
            setSucesso('')
          }}
          disabled={salvando}
          error={tamanho > CONTEUDO_MAXIMO}
          helperText={`${tamanho}/${CONTEUDO_MAXIMO} — mínimo de ${CONTEUDO_MINIMO} caracteres`}
          required
        />

        {erro && <Alert severity="error">{erro}</Alert>}
        {sucesso && <Alert severity="success">{sucesso}</Alert>}

        <Box>
          <Button type="submit" variant="contained" disabled={!podeCriar}>
            {salvando ? <CircularProgress size={24} color="inherit" /> : 'Criar laudo'}
          </Button>
        </Box>
      </Stack>
    </Paper>
  )
}

// ── Lista + ver + assinar ──────────────────────────────

function ListaLaudos({ query, onAssinado }) {
  const { dados: laudos, erro, carregando } = useApi(`/laudos${query}`)

  // Laudo aberto em cada diálogo (null = fechado)
  const [vendo, setVendo] = useState(null)
  const [assinando, setAssinando] = useState(null)
  const [erroDialogo, setErroDialogo] = useState('')
  const [processando, setProcessando] = useState(false)

  function abrirAssinatura(laudo) {
    setErroDialogo('')
    setAssinando(laudo)
  }

  function fecharAssinatura() {
    if (!processando) setAssinando(null)
  }

  async function confirmarAssinatura() {
    setErroDialogo('')
    setProcessando(true)
    try {
      await apiFetch(`/laudos/${assinando.id}/assinar`, { method: 'PATCH' })
      // A página recarrega esta lista (o diálogo some junto)
      onAssinado()
    } catch (err) {
      setErroDialogo(mensagemErro(err))
      setProcessando(false)
    }
  }

  let conteudo
  if (carregando) {
    conteudo = <Carregando />
  } else if (erro) {
    conteudo = <Alert severity="error">{erro}</Alert>
  } else if (!laudos || laudos.length === 0) {
    conteudo = <Typography color="text.secondary">Nenhum laudo encontrado.</Typography>
  } else {
    conteudo = (
      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Paciente</TableCell>
              <TableCell>Emitido em</TableCell>
              <TableCell>Situação</TableCell>
              <TableCell>Assinado em</TableCell>
              <TableCell align="right">Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {laudos.map((l) => (
              <TableRow key={l.id}>
                <TableCell>{nomePaciente(l)}</TableCell>
                <TableCell>{formatarDataHora(l.criado_em)}</TableCell>
                <TableCell>
                  <Chip
                    size="small"
                    label={l.assinado ? 'Assinado' : 'Para assinar'}
                    color={l.assinado ? 'success' : 'warning'}
                  />
                </TableCell>
                <TableCell>{l.assinado_em ? formatarDataHora(l.assinado_em) : '—'}</TableCell>
                <TableCell align="right">
                  <Button size="small" onClick={() => setVendo(l)}>
                    Ver
                  </Button>
                  {!l.assinado && (
                    <Button size="small" onClick={() => abrirAssinatura(l)}>
                      Assinar
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    )
  }

  return (
    <>
      {conteudo}

      {/* Ver: somente leitura */}
      <Dialog open={vendo !== null} onClose={() => setVendo(null)} fullWidth maxWidth="sm">
        <DialogTitle>Laudo de {vendo && nomePaciente(vendo)}</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Emitido em {vendo && formatarDataHora(vendo.criado_em)}
          </DialogContentText>
          <ConteudoLaudo texto={vendo?.conteudo} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setVendo(null)}>Fechar</Button>
        </DialogActions>
      </Dialog>

      {/* Assinar: confirmação com o conteúdo completo */}
      <Dialog open={assinando !== null} onClose={fecharAssinatura} fullWidth maxWidth="sm">
        <DialogTitle>Assinar laudo</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Assinar o laudo de {assinando && nomePaciente(assinando)} emitido em{' '}
            {assinando && formatarDataHora(assinando.criado_em)}?
          </DialogContentText>
          <ConteudoLaudo texto={assinando?.conteudo} />
          {erroDialogo && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {erroDialogo}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={fecharAssinatura} disabled={processando}>
            Cancelar
          </Button>
          <Button variant="contained" onClick={confirmarAssinatura} disabled={processando}>
            {processando ? <CircularProgress size={24} color="inherit" /> : 'Assinar'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}

// ── Página ─────────────────────────────────────────────

export default function LaudosPage() {
  const [filtro, setFiltro] = useState('todos')
  // Muda a cada criação ou assinatura: remonta só a lista, que busca de novo na API
  const [versao, setVersao] = useState(0)
  const recarregar = () => setVersao((v) => v + 1)

  const { query } = FILTROS.find((f) => f.valor === filtro)

  return (
    <>
      <FormularioLaudo onCriado={recarregar} />

      <ToggleButtonGroup
        exclusive
        size="small"
        value={filtro}
        // Clicar no botão já selecionado manda null; mantém o filtro atual
        onChange={(_e, valor) => valor && setFiltro(valor)}
        sx={{ mb: 3 }}
      >
        {FILTROS.map(({ valor, rotulo }) => (
          <ToggleButton key={valor} value={valor}>
            {rotulo}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>

      <ListaLaudos key={`lista-${versao}`} query={query} onAssinado={recarregar} />
    </>
  )
}
