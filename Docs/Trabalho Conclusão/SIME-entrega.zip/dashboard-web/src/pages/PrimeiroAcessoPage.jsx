import { useEffect, useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import {
  Alert,
  Box,
  Button,
  Card,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  TextField,
  Typography,
} from '@mui/material'
import MonitorHeart from '@mui/icons-material/MonitorHeart'
import { MSG_ACESSO_RESTRITO, useAuth } from '../contexts/AuthContext.jsx'
import { useApi } from '../hooks/useApi.js'

export default function PrimeiroAcessoPage() {
  const { user, primeiroAcesso } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  // E-mail e senha temporária vindos do login (state do router), lidos uma vez ao montar
  const [email, setEmail] = useState(() => location.state?.email ?? '')
  const [senhaTemporaria, setSenhaTemporaria] = useState(() => location.state?.senha ?? '')
  const [novaSenha, setNovaSenha] = useState('')
  const [aceite, setAceite] = useState(false)
  const [erro, setErro] = useState('')
  const [contaAtivada, setContaAtivada] = useState(false)
  const [carregando, setCarregando] = useState(false)

  const {
    dados: politica,
    erro: erroPolitica,
    carregando: carregandoPolitica,
  } = useApi('/auth/politica')
  const politicaCarregada = Boolean(politica?.texto)

  // Depois de copiados, tira e-mail e senha do histórico do navegador
  useEffect(() => {
    if (location.state) {
      navigate(location.pathname, { replace: true, state: null })
    }
  }, [location.state, location.pathname, navigate])

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  async function handleSubmit(event) {
    event.preventDefault()
    setErro('')
    setCarregando(true)
    try {
      // Sucesso: o usuário é guardado e o <Navigate> acima leva ao painel
      await primeiroAcesso(email.trim(), senhaTemporaria, novaSenha)
    } catch (err) {
      if (err.contaAtivada) {
        setContaAtivada(true)
      } else {
        // fetch lança TypeError quando não alcança o servidor (API ou proxy fora do ar)
        setErro(err instanceof TypeError ? 'Erro de conexão com o servidor' : err.message)
      }
    } finally {
      setCarregando(false)
    }
  }

  let politicaConteudo
  if (carregandoPolitica) {
    politicaConteudo = <CircularProgress size={24} />
  } else if (erroPolitica) {
    politicaConteudo = <Alert severity="error">{erroPolitica}</Alert>
  } else {
    politicaConteudo = (
      <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>
        {politica?.texto}
      </Typography>
    )
  }

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        bgcolor: '#f5f5f5',
        py: 4,
      }}
    >
      <Card
        component="form"
        onSubmit={handleSubmit}
        sx={{
          maxWidth: 520,
          width: '100%',
          p: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <MonitorHeart sx={{ fontSize: 48, color: '#0D47A1' }} />
        <Typography variant="h5">Primeiro acesso</Typography>

        {contaAtivada ? (
          <>
            <Alert severity="error" sx={{ width: '100%' }}>
              {MSG_ACESSO_RESTRITO}
            </Alert>
            <Alert severity="success" sx={{ width: '100%' }}>
              Sua conta foi ativada.
            </Alert>
            <Button
              fullWidth
              variant="contained"
              onClick={() => navigate('/login', { replace: true })}
              sx={{ bgcolor: '#0D47A1' }}
            >
              Voltar ao login
            </Button>
          </>
        ) : (
          <>
            <TextField
              fullWidth
              label="E-mail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={carregando}
              required
            />
            <TextField
              fullWidth
              label="Senha temporária"
              type="password"
              value={senhaTemporaria}
              onChange={(e) => setSenhaTemporaria(e.target.value)}
              disabled={carregando}
              required
            />
            <TextField
              fullWidth
              label="Nova senha"
              type="password"
              value={novaSenha}
              onChange={(e) => setNovaSenha(e.target.value)}
              disabled={carregando}
              helperText="Mínimo de 6 caracteres, com letra e número."
              required
            />

            <Box sx={{ width: '100%' }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Política de Privacidade
              </Typography>
              <Box
                sx={{
                  maxHeight: 220,
                  overflowY: 'auto',
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  p: 2,
                }}
              >
                {politicaConteudo}
              </Box>
            </Box>

            <FormControlLabel
              sx={{ alignSelf: 'flex-start' }}
              control={
                <Checkbox
                  checked={aceite}
                  onChange={(e) => setAceite(e.target.checked)}
                  disabled={!politicaCarregada || carregando}
                />
              }
              label="Li e concordo com a Política de Privacidade"
            />

            <Button
              fullWidth
              type="submit"
              variant="contained"
              disabled={!politicaCarregada || !aceite || carregando}
              sx={{ bgcolor: '#0D47A1' }}
            >
              {carregando ? <CircularProgress size={24} color="inherit" /> : 'Confirmar'}
            </Button>

            {erro && (
              <Alert severity="error" sx={{ width: '100%' }}>
                {erro}
              </Alert>
            )}
          </>
        )}
      </Card>
    </Box>
  )
}
