import { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { Alert, Box, Button, Card, CircularProgress, TextField, Typography } from '@mui/material'
import MonitorHeart from '@mui/icons-material/MonitorHeart'
import { useAuth } from '../contexts/AuthContext.jsx'

export default function LoginPage() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')
  const [carregando, setCarregando] = useState(false)

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  async function handleSubmit(event) {
    event.preventDefault()
    setErro('')
    setCarregando(true)
    try {
      await login(email.trim(), senha)
    } catch (err) {
      if (err.status === 403 && err.body?.codigo === 'PRIMEIRO_ACESSO') {
        // Usuário pendente: segue para o primeiro acesso com e-mail e senha temporária preenchidos.
        // Vai pelo state do router (nunca pela URL); a página limpa o state ao abrir.
        navigate('/primeiro-acesso', { state: { email: email.trim(), senha } })
      } else {
        // fetch lança TypeError quando não alcança o servidor (API ou proxy fora do ar)
        setErro(err instanceof TypeError ? 'Erro de conexão com o servidor' : err.message)
      }
    } finally {
      setCarregando(false)
    }
  }

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        bgcolor: '#f5f5f5',
      }}
    >
      <Card
        component="form"
        onSubmit={handleSubmit}
        sx={{
          maxWidth: 400,
          width: '100%',
          p: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <MonitorHeart sx={{ fontSize: 48, color: '#0D47A1' }} />
        <Typography variant="h5">SIME</Typography>
        <Typography variant="body2" color="text.secondary">
          Painel de Monitoramento Ergonômico
        </Typography>

        <TextField
          fullWidth
          label="E-mail"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          disabled={carregando}
          required
        />
        <TextField
          fullWidth
          label="Senha"
          type="password"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          disabled={carregando}
          required
        />

        <Button
          fullWidth
          type="submit"
          variant="contained"
          disabled={carregando}
          sx={{ bgcolor: '#0D47A1' }}
        >
          {carregando ? <CircularProgress size={24} color="inherit" /> : 'Entrar'}
        </Button>

        {erro && (
          <Alert severity="error" sx={{ width: '100%' }}>
            {erro}
          </Alert>
        )}
      </Card>
    </Box>
  )
}
