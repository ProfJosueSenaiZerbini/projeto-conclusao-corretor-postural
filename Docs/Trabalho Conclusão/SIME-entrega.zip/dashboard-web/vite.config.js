import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const API_URL = 'http://localhost:3000'

// Alguns prefixos da API (/regras, /laudos, /pacientes) também são rotas de página do React.
// Quando o navegador pede HTML (F5 ou link direto), entrega o index.html em vez
// de repassar à API; chamadas do apiFetch (JSON) seguem para a API.
function apiProxy() {
  return {
    target: API_URL,
    bypass: (req) => (req.headers.accept?.includes('text/html') ? '/index.html' : undefined),
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/auth': apiProxy(),
      '/regras': apiProxy(),
      '/sessoes': apiProxy(),
      '/laudos': apiProxy(),
      '/setores': apiProxy(),
      '/usuarios': apiProxy(),
      '/vinculos': apiProxy(),
      '/pacientes': apiProxy(),
    },
  },
})
