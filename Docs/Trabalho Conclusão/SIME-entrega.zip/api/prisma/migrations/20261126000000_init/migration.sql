-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "Role" AS ENUM ('TRABALHADOR', 'MEDICO', 'GESTOR');

-- CreateEnum
CREATE TYPE "StatusUsuario" AS ENUM ('PENDENTE', 'ATIVO');

-- CreateTable
CREATE TABLE "setor" (
    "id" SERIAL NOT NULL,
    "nome" TEXT NOT NULL,

    CONSTRAINT "setor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "usuario" (
    "id" SERIAL NOT NULL,
    "nome" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "senha_hash" TEXT NOT NULL,
    "role" "Role" NOT NULL,
    "setor_id" INTEGER,
    "status" "StatusUsuario" NOT NULL DEFAULT 'PENDENTE',
    "aceite_politica_em" TIMESTAMP(3),

    CONSTRAINT "usuario_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "regra_parametrizacao" (
    "id" SERIAL NOT NULL,
    "medico_id" INTEGER NOT NULL,
    "angulo_minimo" DOUBLE PRECISION NOT NULL,
    "angulo_maximo" DOUBLE PRECISION NOT NULL DEFAULT 30.0,
    "tempo_minimo_segundos" INTEGER NOT NULL,
    "ativo" BOOLEAN NOT NULL DEFAULT true,
    "criado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "substitui_id" INTEGER,

    CONSTRAINT "regra_parametrizacao_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sessao_monitoramento" (
    "id" SERIAL NOT NULL,
    "trabalhador_id" INTEGER NOT NULL,
    "versao_regra_id" INTEGER NOT NULL,
    "iniciada_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "finalizada_em" TIMESTAMP(3),

    CONSTRAINT "sessao_monitoramento_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "leitura" (
    "id" SERIAL NOT NULL,
    "sessao_id" INTEGER NOT NULL,
    "angulo" DOUBLE PRECISION NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "leitura_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evento_feedback" (
    "id" SERIAL NOT NULL,
    "sessao_id" INTEGER NOT NULL,
    "leitura_id" INTEGER,
    "regra_id" INTEGER NOT NULL,
    "disparado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "evento_feedback_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lote_recebido" (
    "id" SERIAL NOT NULL,
    "sessao_id" INTEGER NOT NULL,
    "sequencia" INTEGER NOT NULL,
    "recebido_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "lote_recebido_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "laudo_aet" (
    "id" SERIAL NOT NULL,
    "trabalhador_id" INTEGER NOT NULL,
    "medico_id" INTEGER NOT NULL,
    "conteudo" TEXT NOT NULL,
    "assinado" BOOLEAN NOT NULL DEFAULT false,
    "assinado_em" TIMESTAMP(3),
    "criado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "laudo_aet_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "medico_paciente" (
    "id" SERIAL NOT NULL,
    "medico_id" INTEGER NOT NULL,
    "trabalhador_id" INTEGER NOT NULL,
    "vinculado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "encerrado_em" TIMESTAMP(3),

    CONSTRAINT "medico_paciente_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "usuario_email_key" ON "usuario"("email");

-- CreateIndex
CREATE UNIQUE INDEX "regra_parametrizacao_substitui_id_key" ON "regra_parametrizacao"("substitui_id");

-- CreateIndex
CREATE UNIQUE INDEX "lote_recebido_sessao_id_sequencia_key" ON "lote_recebido"("sessao_id", "sequencia");

-- AddForeignKey
ALTER TABLE "usuario" ADD CONSTRAINT "usuario_setor_id_fkey" FOREIGN KEY ("setor_id") REFERENCES "setor"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "regra_parametrizacao" ADD CONSTRAINT "regra_parametrizacao_medico_id_fkey" FOREIGN KEY ("medico_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "regra_parametrizacao" ADD CONSTRAINT "regra_parametrizacao_substitui_id_fkey" FOREIGN KEY ("substitui_id") REFERENCES "regra_parametrizacao"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sessao_monitoramento" ADD CONSTRAINT "sessao_monitoramento_trabalhador_id_fkey" FOREIGN KEY ("trabalhador_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sessao_monitoramento" ADD CONSTRAINT "sessao_monitoramento_versao_regra_id_fkey" FOREIGN KEY ("versao_regra_id") REFERENCES "regra_parametrizacao"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "leitura" ADD CONSTRAINT "leitura_sessao_id_fkey" FOREIGN KEY ("sessao_id") REFERENCES "sessao_monitoramento"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evento_feedback" ADD CONSTRAINT "evento_feedback_sessao_id_fkey" FOREIGN KEY ("sessao_id") REFERENCES "sessao_monitoramento"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evento_feedback" ADD CONSTRAINT "evento_feedback_leitura_id_fkey" FOREIGN KEY ("leitura_id") REFERENCES "leitura"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evento_feedback" ADD CONSTRAINT "evento_feedback_regra_id_fkey" FOREIGN KEY ("regra_id") REFERENCES "regra_parametrizacao"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lote_recebido" ADD CONSTRAINT "lote_recebido_sessao_id_fkey" FOREIGN KEY ("sessao_id") REFERENCES "sessao_monitoramento"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "laudo_aet" ADD CONSTRAINT "laudo_aet_trabalhador_id_fkey" FOREIGN KEY ("trabalhador_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "laudo_aet" ADD CONSTRAINT "laudo_aet_medico_id_fkey" FOREIGN KEY ("medico_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medico_paciente" ADD CONSTRAINT "medico_paciente_medico_id_fkey" FOREIGN KEY ("medico_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medico_paciente" ADD CONSTRAINT "medico_paciente_trabalhador_id_fkey" FOREIGN KEY ("trabalhador_id") REFERENCES "usuario"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
