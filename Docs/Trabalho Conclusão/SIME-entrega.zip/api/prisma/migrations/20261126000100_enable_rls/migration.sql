-- O Supabase expõe o schema "public" pela Data API (PostgREST) com a chave anon, que é pública.
-- Com RLS ligado e nenhuma policy, essas chaves não leem nem gravam nada nestas tabelas.
-- A API do SIME conecta como "postgres" (dono das tabelas), que não é afetado pelo RLS.
ALTER TABLE "setor" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "usuario" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "regra_parametrizacao" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "sessao_monitoramento" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "leitura" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "evento_feedback" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "lote_recebido" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "laudo_aet" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "medico_paciente" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "_prisma_migrations" ENABLE ROW LEVEL SECURITY;
