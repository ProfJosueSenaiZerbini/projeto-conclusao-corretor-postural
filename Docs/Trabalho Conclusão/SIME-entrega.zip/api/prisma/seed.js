import 'dotenv/config'
import { PrismaClient } from '../generated/prisma/client.ts'
import { PrismaPg } from '@prisma/adapter-pg'
import { gerarHash, validarSenha } from '../src/lib/senha.js'

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL })

const prisma = new PrismaClient({ adapter })

// Data/hora desta execução: aceite da gestora e início dos vínculos
const agora = new Date()

const stats = {
  setor: { criados: 0, pulados: 0 },
  usuario: { criados: 0, pulados: 0 },
  regra_parametrizacao: { criados: 0, pulados: 0 },
  medico_paciente: { criados: 0, pulados: 0 },
  sessao_monitoramento: { criados: 0, pulados: 0 },
  leitura: { criados: 0, pulados: 0 },
  evento_feedback: { criados: 0, pulados: 0 },
  laudo_aet: { criados: 0, pulados: 0 },
}

// ── Setores ────────────────────────────────────────────

async function seedSetores() {
  const nomes = ['Financeiro', 'Operações']
  const setores = {}

  for (const nome of nomes) {
    let setor = await prisma.setor.findFirst({ where: { nome } })
    if (setor) {
      stats.setor.pulados++
    } else {
      setor = await prisma.setor.create({ data: { nome } })
      stats.setor.criados++
    }
    setores[nome] = setor
  }

  return setores
}

// ── Usuários ───────────────────────────────────────────
// Senha de todos: SEED_SENHA (api/.env), gravada com hash. Só a gestora já está ATIVA (com aceite);
// os demais ficam PENDENTE até o primeiro acesso. Setor só para TRABALHADOR.

async function seedUsuarios(setores, senhaSeed) {
  const dados = [
    { nome: 'Dr. Carlos Silva', email: 'carlos@sime.dev', role: 'MEDICO', setor: null, status: 'PENDENTE' },
    { nome: 'Patrícia Souza', email: 'patricia@sime.dev', role: 'GESTOR', setor: null, status: 'ATIVO' },
    { nome: 'Mariana Costa', email: 'mariana@sime.dev', role: 'TRABALHADOR', setor: 'Financeiro', status: 'PENDENTE' },
    { nome: 'João Ferreira', email: 'joao@sime.dev', role: 'TRABALHADOR', setor: 'Operações', status: 'PENDENTE' },
  ]

  const usuarios = {}

  for (const d of dados) {
    const existing = await prisma.usuario.findUnique({ where: { email: d.email } })
    if (existing) {
      stats.usuario.pulados++
      usuarios[d.email] = existing
    } else {
      const usuario = await prisma.usuario.create({
        data: {
          nome: d.nome,
          email: d.email,
          senha_hash: await gerarHash(senhaSeed), // um hash (salt) por usuário
          role: d.role,
          setor_id: d.setor ? setores[d.setor].id : null,
          status: d.status,
          aceite_politica_em: d.status === 'ATIVO' ? agora : null,
        },
      })
      stats.usuario.criados++
      usuarios[d.email] = usuario
    }
  }

  return usuarios
}

// ── Regra ──────────────────────────────────────────────
// Uma única regra vigente, criada pelo médico Carlos.

async function seedRegra(usuarios) {
  const carlos = usuarios['carlos@sime.dev']
  // Igual ao firmware (firmware/sime_wearable/config.h: ANGULO_MINIMO, ANGULO_MAXIMO, TEMPO_FORA_MS).
  // A regra é fixa: não há rota para alterá-la. Se mudar aqui, mude lá também, e vice-versa.
  const dados = { angulo_minimo: 0, angulo_maximo: 20, tempo_minimo_segundos: 30 }

  let regra = await prisma.regraParametrizacao.findFirst({
    where: { medico_id: carlos.id, ...dados, substitui_id: null },
  })
  if (regra) {
    stats.regra_parametrizacao.pulados++
  } else {
    regra = await prisma.regraParametrizacao.create({
      data: { medico_id: carlos.id, ...dados, ativo: true },
    })
    stats.regra_parametrizacao.criados++
  }

  return regra
}

// ── Vínculos médico–paciente ───────────────────────────

async function seedVinculos(usuarios) {
  const carlos = usuarios['carlos@sime.dev']
  const pacientes = [usuarios['mariana@sime.dev'], usuarios['joao@sime.dev']]

  for (const trabalhador of pacientes) {
    const ativo = await prisma.medicoPaciente.findFirst({
      where: { trabalhador_id: trabalhador.id, encerrado_em: null },
    })
    if (ativo) {
      stats.medico_paciente.pulados++
    } else {
      await prisma.medicoPaciente.create({
        data: { medico_id: carlos.id, trabalhador_id: trabalhador.id, vinculado_em: agora },
      })
      stats.medico_paciente.criados++
    }
  }
}

// ── Sessão ─────────────────────────────────────────────

async function seedSessao(usuarios, regra) {
  const mariana = usuarios['mariana@sime.dev']
  const dataInicio = new Date('2024-03-15T08:00:00.000Z')

  let sessao = await prisma.sessaoMonitoramento.findFirst({
    where: {
      trabalhador_id: mariana.id,
      versao_regra_id: regra.id,
      iniciada_em: dataInicio,
    },
  })

  if (sessao) {
    stats.sessao_monitoramento.pulados++
  } else {
    sessao = await prisma.sessaoMonitoramento.create({
      data: {
        trabalhador_id: mariana.id,
        versao_regra_id: regra.id,
        iniciada_em: dataInicio,
      },
    })
    stats.sessao_monitoramento.criados++
  }

  return sessao
}

// ── Leituras ───────────────────────────────────────────

async function seedLeituras(sessao) {
  const inicioMs = new Date(sessao.iniciada_em).getTime()

  const angulos = [15, 35, 10, 40, 25, 45, 20, 50, 28, 38]

  for (let i = 0; i < 10; i++) {
    const tMs = i * 100
    const timestamp = new Date(inicioMs + tMs)
    const angulo = angulos[i]

    const existing = await prisma.leitura.findFirst({
      where: {
        sessao_id: sessao.id,
        timestamp,
      },
    })

    if (existing) {
      stats.leitura.pulados++
    } else {
      await prisma.leitura.create({
        data: {
          sessao_id: sessao.id,
          angulo,
          timestamp,
        },
      })
      stats.leitura.criados++
    }
  }
}

// ── Eventos de feedback ────────────────────────────────

async function seedEventos(sessao, regra) {
  const inicioMs = new Date(sessao.iniciada_em).getTime()

  const eventosData = [
    { t_ms: 300 },
    { t_ms: 700 },
  ]

  for (const e of eventosData) {
    const disparadoEm = new Date(inicioMs + e.t_ms)

    const existing = await prisma.eventoFeedback.findFirst({
      where: {
        sessao_id: sessao.id,
        regra_id: regra.id,
        disparado_em: disparadoEm,
      },
    })

    if (existing) {
      stats.evento_feedback.pulados++
    } else {
      await prisma.eventoFeedback.create({
        data: {
          sessao_id: sessao.id,
          leitura_id: null,
          regra_id: regra.id,
          disparado_em: disparadoEm,
        },
      })
      stats.evento_feedback.criados++
    }
  }
}

// ── Laudo ──────────────────────────────────────────────

async function seedLaudo(usuarios) {
  const carlos = usuarios['carlos@sime.dev']
  const mariana = usuarios['mariana@sime.dev']
  const conteudo = 'Trabalhadora apresentou postura inadequada em 40% da sessão.'

  let laudo = await prisma.laudoAet.findFirst({
    where: {
      medico_id: carlos.id,
      trabalhador_id: mariana.id,
      conteudo,
    },
  })

  if (laudo) {
    stats.laudo_aet.pulados++
  } else {
    laudo = await prisma.laudoAet.create({
      data: {
        medico_id: carlos.id,
        trabalhador_id: mariana.id,
        conteudo,
        assinado: true,
        assinado_em: new Date(),
      },
    })
    stats.laudo_aet.criados++
  }
}

// Senha inicial dos usuários do seed: só de SEED_SENHA (api/.env), sem valor padrão no código.
// Segue a regra de senha do sistema (mínimo de 6 caracteres, com letra e número).
function lerSenhaSeed() {
  const erros = validarSenha(process.env.SEED_SENHA, 'SEED_SENHA')
  if (erros.length > 0) {
    throw new Error(`SEED_SENHA ausente ou inválida em api/.env: ${erros.join(' ')}`)
  }
  return process.env.SEED_SENHA
}

// ── Main ───────────────────────────────────────────────

async function main() {
  console.log('Iniciando seed...\n')

  const senhaSeed = lerSenhaSeed() // antes de qualquer gravação
  const setores = await seedSetores()
  const usuarios = await seedUsuarios(setores, senhaSeed)
  const regra = await seedRegra(usuarios)
  await seedVinculos(usuarios)
  const sessao = await seedSessao(usuarios, regra)
  await seedLeituras(sessao)
  await seedEventos(sessao, regra)
  await seedLaudo(usuarios)

  console.log('\n── Resultado ──────────────────────────')
  for (const [tabela, s] of Object.entries(stats)) {
    console.log(`  ${tabela}: ${s.criados} criados, ${s.pulados} pulados`)
  }
  console.log()
}

main()
  .catch((err) => {
    console.error('Erro no seed:', err)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
