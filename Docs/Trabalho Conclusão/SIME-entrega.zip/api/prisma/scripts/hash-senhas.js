// EXECUÇÃO ÚNICA (W5b) — NÃO RODAR DE NOVO.
//
// Gera o senha_hash (bcrypt) dos usuários que existiam antes do W5b, a partir
// da coluna `senha` em texto puro. Depende dessa coluna, que é removida pela
// migration 2 (remove_senha_texto); depois dela, este script não funciona mais.
// Ordem usada: migration 1 (usuario_status_senha_hash) → este script → migration 2.
//
// Usa SQL puro ($queryRaw/$executeRaw) para não depender do client gerado.
// Só preenche quem ainda está sem hash; não imprime senhas nem hashes.

import bcrypt from 'bcryptjs'
import prisma from '../../src/lib/prisma.js'

const CUSTO_BCRYPT = 10

async function main() {
  const usuarios = await prisma.$queryRaw`
    SELECT id, email, senha FROM usuario WHERE senha_hash IS NULL ORDER BY id`

  console.log(`Usuários sem senha_hash: ${usuarios.length}`)

  for (const u of usuarios) {
    const hash = await bcrypt.hash(u.senha, CUSTO_BCRYPT)
    const alterados = await prisma.$executeRaw`
      UPDATE usuario SET senha_hash = ${hash} WHERE id = ${u.id} AND senha_hash IS NULL`
    console.log(`  id ${u.id} (${u.email}): ${alterados} linha atualizada`)
  }

  const [contagem] = await prisma.$queryRaw`
    SELECT
      CAST(SUM(senha_hash IS NOT NULL) AS SIGNED) AS com_hash,
      CAST(SUM(senha_hash IS NULL) AS SIGNED) AS sem_hash
    FROM usuario`
  console.log(`Resultado: ${contagem.com_hash} com hash, ${contagem.sem_hash} sem hash`)
}

main()
  .catch((err) => {
    console.error('Erro ao gerar hashes:', err)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
