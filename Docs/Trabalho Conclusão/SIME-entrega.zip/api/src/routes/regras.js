import { Router } from 'express'
import prisma from '../lib/prisma.js'

// Regra de postura: somente leitura. A regra é fixa (0° a 20°, 30 s) e aplicada pelo
// firmware (firmware/sime_wearable/config.h); a vigente é criada pelo seed (prisma/seed.js).
// Não há rota para criar ou editar regra: um valor diferente nunca chegaria ao dispositivo.

const router = Router()

// GET /regras — lista as regras; ?ativo=true|false filtra
router.get('/', async (req, res) => {
  const { ativo } = req.query
  const where = {}

  if (ativo !== undefined) {
    if (ativo !== 'true' && ativo !== 'false') {
      return res.status(400).json({ erros: ['ativo deve ser true ou false.'] })
    }
    where.ativo = ativo === 'true'
  }

  try {
    const regras = await prisma.regraParametrizacao.findMany({
      where,
      orderBy: { criado_em: 'desc' },
    })
    return res.json(regras)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar regras.', err.message] })
  }
})

// GET /regras/:id — busca uma regra por id
router.get('/:id', async (req, res) => {
  const id = Number(req.params.id)

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ erros: ['id deve ser um inteiro positivo.'] })
  }

  try {
    const regra = await prisma.regraParametrizacao.findUnique({ where: { id } })
    if (!regra) {
      return res.status(404).json({ erros: ['Regra não encontrada.'] })
    }
    return res.json(regra)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao buscar regra.', err.message] })
  }
})


export default router
