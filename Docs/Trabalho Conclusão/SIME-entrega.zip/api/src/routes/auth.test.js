import { describe, it, before, after } from 'node:test'
import assert from 'node:assert/strict'
import app from '../server.js'

let server
let baseUrl

before(() => {
  return new Promise((resolve) => {
    server = app.listen(0, () => {
      const { port } = server.address()
      baseUrl = `http://localhost:${port}`
      resolve()
    })
  })
})

after(() => {
  return new Promise((resolve) => server.close(resolve))
})

describe('POST /auth/login', () => {
  it('200 — credenciais válidas retornam usuário sem senha', async () => {
    const res = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'carlos@sime.dev', senha: 'se' }),
    })

    assert.equal(res.status, 200)
    const body = await res.json()
    assert.equal(body.email, 'carlos@sime.dev')
    assert.equal(body.nome, 'Dr. Carlos Silva')
    assert.equal(body.role, 'MEDICO')
    assert.ok(body.id)
    assert.ok(body.setor_id != null)
    assert.equal(body.senha, undefined)
  })

  it('401 — senha errada', async () => {
    const res = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'carlos@sime.dev', senha: 'errada' }),
    })

    assert.equal(res.status, 401)
    const body = await res.json()
    assert.ok(body.erros.some((e) => /credenciais inválidas/i.test(e)))
  })

  it('401 — email inexistente', async () => {
    const res = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ninguem@sime.dev', senha: 'se' }),
    })

    assert.equal(res.status, 401)
    const body = await res.json()
    assert.ok(body.erros.some((e) => /credenciais inválidas/i.test(e)))
  })

  it('400 — body vazio', async () => {
    const res = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    })

    assert.equal(res.status, 400)
    const body = await res.json()
    assert.ok(body.erros.length > 0)
  })
})
