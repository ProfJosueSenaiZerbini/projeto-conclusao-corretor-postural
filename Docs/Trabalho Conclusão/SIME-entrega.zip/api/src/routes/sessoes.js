import { Router } from 'express'
import prisma from '../lib/prisma.js'

const router = Router()

// Acesso (server.js + filtros abaixo):
// - TRABALHADOR cria e lê só as próprias sessões e só envia lotes para elas;
//   o trabalhador_id vem do token, nunca do corpo ou da query.
// - MEDICO lê sessões apenas de trabalhador com vínculo ativo com ele.

// POST /sessoes — cria uma sessão de monitoramento para o trabalhador do token,
// sempre com a regra ativa (versao_regra_id do corpo é ignorado; 409 se não houver regra ativa)
router.post('/', async (req, res) => {
  const { data_inicio } = req.body
  // O trabalhador vem do token; trabalhador_id do corpo é ignorado
  const trabalhador_id = req.usuario.id

  // --- Validação de campos obrigatórios ---
  const erros = []

  if (data_inicio == null) {
    erros.push('data_inicio é obrigatório.')
  } else {
    const d = new Date(data_inicio)
    if (Number.isNaN(d.getTime())) {
      erros.push('data_inicio deve ser uma data ISO 8601 válida.')
    }
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  // --- Regra ativa (a sessão sempre usa a regra vigente) ---
  let regra
  try {
    regra = await prisma.regraParametrizacao.findFirst({
      where: { ativo: true },
      orderBy: { criado_em: 'desc' },
    })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao verificar regra.', err.message] })
  }

  if (!regra) {
    return res.status(409).json({ erros: ['Não há regra ativa. Não é possível iniciar a sessão.'] })
  }

  // --- Criar sessão ---
  try {
    const sessao = await prisma.sessaoMonitoramento.create({
      data: {
        trabalhador_id,
        versao_regra_id: regra.id,
        iniciada_em: new Date(data_inicio),
      },
    })

    return res.status(201).json({
      id: sessao.id,
      trabalhador_id: sessao.trabalhador_id,
      versao_regra_id: sessao.versao_regra_id,
      data_inicio: sessao.iniciada_em,
      data_fim: sessao.finalizada_em,
    })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao criar sessão.', err.message] })
  }
})

// GET /sessoes — TRABALHADOR: as próprias (?trabalhador_id é ignorado);
// MEDICO: ?trabalhador_id=<id> obrigatório, só com vínculo ativo
router.get('/', async (req, res) => {
  let tid

  if (req.usuario.role === 'TRABALHADOR') {
    tid = req.usuario.id
  } else {
    if (req.query.trabalhador_id == null) {
      return res.status(400).json({ erros: ['trabalhador_id é obrigatório.'] })
    }

    tid = Number(req.query.trabalhador_id)
    if (!Number.isInteger(tid)) {
      return res.status(400).json({ erros: ['trabalhador_id deve ser um inteiro.'] })
    }

    try {
      const trabalhador = await prisma.usuario.findUnique({ where: { id: tid } })
      if (!trabalhador) {
        return res.status(404).json({ erros: ['Trabalhador não encontrado.'] })
      }

      const vinculo = await prisma.medicoPaciente.findFirst({
        where: { medico_id: req.usuario.id, trabalhador_id: tid, encerrado_em: null },
      })
      if (!vinculo) {
        return res.status(403).json({ erros: ['Trabalhador sem vínculo ativo com este médico.'] })
      }
    } catch (err) {
      return res.status(500).json({ erros: ['Erro ao verificar trabalhador.', err.message] })
    }
  }

  try {
    const sessoes = await prisma.sessaoMonitoramento.findMany({
      where: { trabalhador_id: tid },
      orderBy: { iniciada_em: 'desc' },
    })

    return res.json(
      sessoes.map((s) => ({
        id: s.id,
        trabalhador_id: s.trabalhador_id,
        versao_regra_id: s.versao_regra_id,
        data_inicio: s.iniciada_em,
        data_fim: s.finalizada_em,
      })),
    )
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar sessões.', err.message] })
  }
})

// PATCH /sessoes/:id/encerrar — grava o fim da sessão (só o trabalhador dono).
// Idempotente: se já estiver encerrada, devolve a data já gravada.
router.patch('/:id/encerrar', async (req, res) => {
  const sessaoId = Number(req.params.id)

  if (!Number.isInteger(sessaoId) || sessaoId <= 0) {
    return res.status(400).json({ erros: ['id de sessão deve ser um inteiro positivo.'] })
  }

  try {
    const sessao = await prisma.sessaoMonitoramento.findUnique({ where: { id: sessaoId } })

    if (!sessao) {
      return res.status(404).json({ erros: ['Sessão não encontrada.'] })
    }
    if (sessao.trabalhador_id !== req.usuario.id) {
      return res.status(403).json({ erros: ['Esta sessão não pertence ao usuário.'] })
    }

    if (sessao.finalizada_em) {
      return res.json({ id: sessao.id, data_fim: sessao.finalizada_em, ja_encerrada: true })
    }

    const encerrada = await prisma.sessaoMonitoramento.update({
      where: { id: sessaoId },
      data: { finalizada_em: new Date() },
    })
    return res.json({ id: encerrada.id, data_fim: encerrada.finalizada_em, ja_encerrada: false })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao encerrar sessão.', err.message] })
  }
})

// POST /sessoes/:id/lotes — recebe um lote de dados do mobile
router.post('/:id/lotes', async (req, res) => {
  const sessaoId = Number(req.params.id)

  if (!Number.isInteger(sessaoId) || sessaoId <= 0) {
    return res.status(400).json({ erros: ['id de sessão deve ser um inteiro positivo.'] })
  }

  const { sequencia, leituras, eventos, lacunas } = req.body

  // --- Validação ---
  const erros = []

  if (sequencia == null) {
    erros.push('sequencia é obrigatória.')
  } else if (!Number.isInteger(sequencia)) {
    erros.push('sequencia deve ser um inteiro.')
  }

  if (leituras != null && !Array.isArray(leituras)) {
    erros.push('leituras deve ser um array.')
  }

  if (eventos != null && !Array.isArray(eventos)) {
    erros.push('eventos deve ser um array.')
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  // --- Verificar sessão ---
  let sessao
  try {
    sessao = await prisma.sessaoMonitoramento.findUnique({ where: { id: sessaoId } })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao buscar sessão.', err.message] })
  }

  if (!sessao) {
    return res.status(404).json({ erros: ['Sessão não encontrada.'] })
  }

  // Só o trabalhador dono da sessão envia lotes para ela
  if (sessao.trabalhador_id !== req.usuario.id) {
    return res.status(403).json({ erros: ['Esta sessão não pertence ao usuário.'] })
  }

  // --- Deduplicação ---
  try {
    const loteExistente = await prisma.loteRecebido.findUnique({
      where: { sessao_id_sequencia: { sessao_id: sessaoId, sequencia } },
    })
    if (loteExistente) {
      return res.status(200).json({ deduplicado: true, mensagem: 'Lote já recebido.' })
    }
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao verificar deduplicação.', err.message] })
  }

  // --- Calcular timestamps absolutos ---
  const inicioMs = new Date(sessao.iniciada_em).getTime()
  const leiturasArr = leituras || []
  const eventosArr = eventos || []
  const lacunasArr = lacunas || []

  // --- Transação: inserir leituras, eventos e registrar lote ---
  try {
    await prisma.$transaction(async (tx) => {
      // a. Inserir leituras
      if (leiturasArr.length > 0) {
        await tx.leitura.createMany({
          data: leiturasArr.map((l) => ({
            sessao_id: sessaoId,
            angulo: l.angulo,
            timestamp: new Date(inicioMs + l.t_ms),
          })),
        })
      }

      // b. Inserir eventos (leitura_id: null por enquanto)
      if (eventosArr.length > 0) {
        await tx.eventoFeedback.createMany({
          data: eventosArr.map((e) => ({
            sessao_id: sessaoId,
            leitura_id: null,
            regra_id: e.regra_id,
            disparado_em: new Date(inicioMs + e.t_ms),
          })),
        })
      }

      // c. Registrar lote
      await tx.loteRecebido.create({
        data: { sessao_id: sessaoId, sequencia },
      })
    })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao processar lote.', err.message] })
  }

  // --- Lacunas: log no console, sem persistir ---
  if (lacunasArr.length > 0) {
    console.log(`[sessao=${sessaoId} seq=${sequencia}] Lacunas recebidas:`, lacunasArr)
  }

  return res.status(201).json({
    deduplicado: false,
    leituras_inseridas: leiturasArr.length,
    eventos_inseridos: eventosArr.length,
    lacunas_recebidas: lacunasArr.length,
  })
})

export default router
