import { Router } from 'express'
import prisma from '../lib/prisma.js'

const router = Router()

// Tamanho do conteúdo do laudo, contado depois do trim (o dashboard usa os mesmos limites)
const CONTEUDO_MINIMO = 20
const CONTEUDO_MAXIMO = 5000

// Acesso (server.js + filtros abaixo):
// - MEDICO cria laudo só para trabalhador com vínculo ativo com ele; lê e assina
//   apenas os laudos que ele mesmo emitiu (medico_id do token), mesmo após o fim do vínculo.
// - TRABALHADOR lê apenas os próprios laudos.
// - GESTOR não acessa /laudos.

// Vínculo ativo entre o médico e o trabalhador (encerrado_em nulo)?
async function temVinculoAtivo(medico_id, trabalhador_id) {
  const vinculo = await prisma.medicoPaciente.findFirst({
    where: { medico_id, trabalhador_id, encerrado_em: null },
  })
  return vinculo !== null
}

// POST /laudos — cria um laudo AET
router.post('/', async (req, res) => {
  const { trabalhador_id, conteudo } = req.body
  // O médico vem do token; medico_id do corpo é ignorado
  const medico_id = req.usuario.id

  // --- Validação ---
  const erros = []

  if (trabalhador_id == null) {
    erros.push('trabalhador_id é obrigatório.')
  } else if (!Number.isInteger(trabalhador_id)) {
    erros.push('trabalhador_id deve ser um inteiro.')
  }

  if (conteudo == null) {
    erros.push('conteudo é obrigatório.')
  } else if (typeof conteudo !== 'string' || conteudo.trim() === '') {
    erros.push('conteudo não pode ser vazio.')
  } else if (conteudo.trim().length < CONTEUDO_MINIMO) {
    erros.push(`conteudo deve ter no mínimo ${CONTEUDO_MINIMO} caracteres.`)
  } else if (conteudo.trim().length > CONTEUDO_MAXIMO) {
    erros.push(`conteudo deve ter no máximo ${CONTEUDO_MAXIMO} caracteres.`)
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  // --- Verificar trabalhador ---
  try {
    const trabalhador = await prisma.usuario.findUnique({ where: { id: trabalhador_id } })
    if (!trabalhador) {
      return res.status(404).json({ erros: ['Trabalhador não encontrado.'] })
    }
    if (trabalhador.role !== 'TRABALHADOR') {
      return res.status(422).json({ erros: ['O usuário informado não possui role TRABALHADOR.'] })
    }
    if (!(await temVinculoAtivo(medico_id, trabalhador_id))) {
      return res.status(403).json({ erros: ['Trabalhador sem vínculo ativo com este médico.'] })
    }
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao verificar trabalhador.', err.message] })
  }

  // --- Criar laudo ---
  try {
    const laudo = await prisma.laudoAet.create({
      data: {
        medico_id,
        trabalhador_id,
        conteudo: conteudo.trim(),
      },
    })
    return res.status(201).json(laudo)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao criar laudo.', err.message] })
  }
})

// PATCH /laudos/:id/assinar — assina um laudo
router.patch('/:id/assinar', async (req, res) => {
  const id = Number(req.params.id)

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ erros: ['id deve ser um inteiro positivo.'] })
  }

  let laudo
  try {
    laudo = await prisma.laudoAet.findUnique({ where: { id } })
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao buscar laudo.', err.message] })
  }

  if (!laudo) {
    return res.status(404).json({ erros: ['Laudo não encontrado.'] })
  }

  // Só o médico autor assina
  if (laudo.medico_id !== req.usuario.id) {
    return res.status(403).json({ erros: ['Somente o médico autor pode assinar este laudo.'] })
  }

  if (laudo.assinado) {
    return res.status(422).json({ erros: ['Laudo já foi assinado.'] })
  }

  try {
    const laudoAtualizado = await prisma.laudoAet.update({
      where: { id },
      data: {
        assinado: true,
        assinado_em: new Date(),
      },
    })
    return res.json(laudoAtualizado)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao assinar laudo.', err.message] })
  }
})

// GET /laudos — lista laudos com filtros opcionais
router.get('/', async (req, res) => {
  const where = {}

  // Os filtros de dono vêm do token, nunca da query:
  // TRABALHADOR vê os próprios laudos; MEDICO vê os laudos que emitiu (?medico_id é ignorado).
  if (req.usuario.role === 'TRABALHADOR') {
    where.trabalhador_id = req.usuario.id
  } else {
    where.medico_id = req.usuario.id
    if (req.query.trabalhador_id != null) {
      const tid = Number(req.query.trabalhador_id)
      if (!Number.isInteger(tid)) {
        return res.status(400).json({ erros: ['trabalhador_id deve ser um inteiro.'] })
      }
      where.trabalhador_id = tid
    }
  }

  if (req.query.assinado != null) {
    if (req.query.assinado === 'true') {
      where.assinado = true
    } else if (req.query.assinado === 'false') {
      where.assinado = false
    } else {
      return res.status(400).json({ erros: ['assinado deve ser "true" ou "false".'] })
    }
  }

  try {
    const laudos = await prisma.laudoAet.findMany({
      where,
      orderBy: { criado_em: 'desc' },
      include: {
        medico: { select: { id: true, nome: true } },
        trabalhador: { select: { id: true, nome: true } },
      },
    })
    return res.json(laudos)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar laudos.', err.message] })
  }
})

// GET /laudos/:id — busca um laudo por id
router.get('/:id', async (req, res) => {
  const id = Number(req.params.id)

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ erros: ['id deve ser um inteiro positivo.'] })
  }

  try {
    const laudo = await prisma.laudoAet.findUnique({
      where: { id },
      include: { medico: { select: { id: true, nome: true } } },
    })
    if (!laudo) {
      return res.status(404).json({ erros: ['Laudo não encontrado.'] })
    }
    // TRABALHADOR só abre os próprios laudos; MEDICO só os que emitiu
    const dono =
      req.usuario.role === 'TRABALHADOR'
        ? laudo.trabalhador_id === req.usuario.id
        : laudo.medico_id === req.usuario.id
    if (!dono) {
      return res.status(403).json({ erros: ['Acesso não permitido para este perfil.'] })
    }
    return res.json(laudo)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao buscar laudo.', err.message] })
  }
})

export default router
