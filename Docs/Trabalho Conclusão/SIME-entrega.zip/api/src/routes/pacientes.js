import { Router } from 'express'
import prisma from '../lib/prisma.js'
import {
  DIAS_POR_PERIODO,
  calcularScore,
  contarLeiturasNaFaixa,
  inicioDaJanela,
} from '../lib/score.js'

// Pacientes do MEDICO (controle de acesso no server.js): trabalhadores com vínculo
// ativo com o médico do token, com o score de postura (% de leituras na faixa) no período.

const router = Router()

const PERIODOS = ['semana', 'mes', 'geral']

// GET /pacientes?periodo=semana|mes|geral (sem periodo = semana)
router.get('/', async (req, res) => {
  const periodo = req.query.periodo ?? 'semana'

  if (!PERIODOS.includes(periodo)) {
    return res.status(400).json({ erros: ['periodo deve ser "semana", "mes" ou "geral".'] })
  }

  // geral = todo o histórico; semana e mes = mesma janela do /setores/resumo
  const desde = periodo === 'geral' ? null : inicioDaJanela(DIAS_POR_PERIODO[periodo])
  const contarLeituras = desde ? { where: { timestamp: { gte: desde } } } : true
  const contarEventos = desde ? { where: { disparado_em: { gte: desde } } } : true

  try {
    const vinculos = await prisma.medicoPaciente.findMany({
      where: { medico_id: req.usuario.id, encerrado_em: null },
      select: {
        vinculado_em: true,
        trabalhador: {
          select: {
            id: true,
            nome: true,
            setor: { select: { id: true, nome: true } },
            sessoes_monitoramento: {
              select: {
                id: true,
                versao_regra: { select: { angulo_minimo: true, angulo_maximo: true } },
                _count: {
                  select: { leituras: contarLeituras, eventos_feedback: contarEventos },
                },
              },
            },
          },
        },
      },
    })

    const naFaixa = await contarLeiturasNaFaixa(
      vinculos.flatMap((v) => v.trabalhador.sessoes_monitoramento),
      desde,
    )

    const pacientes = vinculos.map(({ vinculado_em, trabalhador }) => {
      let leituras = 0
      let leiturasNaFaixa = 0
      let eventos = 0
      for (const sessao of trabalhador.sessoes_monitoramento) {
        leituras += sessao._count.leituras
        leiturasNaFaixa += naFaixa.get(sessao.id) ?? 0
        eventos += sessao._count.eventos_feedback
      }

      return {
        id: trabalhador.id,
        nome: trabalhador.nome,
        setor: trabalhador.setor,
        vinculado_em,
        score: calcularScore(leituras, leiturasNaFaixa),
        total_alertas: eventos,
      }
    })

    pacientes.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))

    return res.json(pacientes)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar pacientes.', err.message] })
  }
})

export default router
