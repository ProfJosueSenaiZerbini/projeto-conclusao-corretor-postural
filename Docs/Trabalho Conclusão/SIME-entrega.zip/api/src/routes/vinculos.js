import { Router } from 'express'
import prisma from '../lib/prisma.js'

// Vínculo médico–paciente, gerido só pelo GESTOR (controle de acesso no server.js).
// O gestor vê apenas o nome do médico e o nome e o setor do trabalhador;
// nunca dados de postura, sessões, leituras, eventos ou laudos.
// Um trabalhador tem no máximo um vínculo ativo (encerrado_em nulo); o registro nunca é apagado.

const router = Router()

const CAMPOS_VINCULO = {
  id: true,
  medico: { select: { id: true, nome: true } },
  trabalhador: { select: { id: true, nome: true, setor: { select: { id: true, nome: true } } } },
  vinculado_em: true,
  encerrado_em: true,
}

// POST /vinculos — vincula um trabalhador a um médico
router.post('/', async (req, res) => {
  const { medico_id, trabalhador_id } = req.body

  // --- Validação ---
  const erros = []

  if (medico_id == null) {
    erros.push('medico_id é obrigatório.')
  } else if (!Number.isInteger(medico_id)) {
    erros.push('medico_id deve ser um inteiro.')
  }

  if (trabalhador_id == null) {
    erros.push('trabalhador_id é obrigatório.')
  } else if (!Number.isInteger(trabalhador_id)) {
    erros.push('trabalhador_id deve ser um inteiro.')
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  try {
    const medico = await prisma.usuario.findUnique({ where: { id: medico_id } })
    if (!medico) {
      return res.status(404).json({ erros: ['Médico não encontrado.'] })
    }
    if (medico.role !== 'MEDICO') {
      return res.status(400).json({ erros: ['O usuário informado não é MEDICO.'] })
    }

    const trabalhador = await prisma.usuario.findUnique({ where: { id: trabalhador_id } })
    if (!trabalhador) {
      return res.status(404).json({ erros: ['Trabalhador não encontrado.'] })
    }
    if (trabalhador.role !== 'TRABALHADOR') {
      return res.status(400).json({ erros: ['O usuário informado não é TRABALHADOR.'] })
    }

    // Um médico ativo por trabalhador (checagem na API, sem transação)
    const ativo = await prisma.medicoPaciente.findFirst({
      where: { trabalhador_id, encerrado_em: null },
    })
    if (ativo) {
      return res.status(409).json({ erros: ['Trabalhador já tem vínculo ativo com um médico.'] })
    }

    const vinculo = await prisma.medicoPaciente.create({
      data: { medico_id, trabalhador_id },
      select: CAMPOS_VINCULO,
    })
    return res.status(201).json(vinculo)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao criar vínculo.', err.message] })
  }
})

// PATCH /vinculos/:id/encerrar — encerra o vínculo (grava encerrado_em)
router.patch('/:id/encerrar', async (req, res) => {
  const id = Number(req.params.id)

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ erros: ['id deve ser um inteiro positivo.'] })
  }

  try {
    const vinculo = await prisma.medicoPaciente.findUnique({ where: { id } })
    if (!vinculo) {
      return res.status(404).json({ erros: ['Vínculo não encontrado.'] })
    }
    if (vinculo.encerrado_em !== null) {
      return res.status(409).json({ erros: ['Vínculo já encerrado.'] })
    }

    const encerrado = await prisma.medicoPaciente.update({
      where: { id },
      data: { encerrado_em: new Date() },
      select: CAMPOS_VINCULO,
    })
    return res.json(encerrado)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao encerrar vínculo.', err.message] })
  }
})

// GET /vinculos — lista vínculos; ?ativo=true|false filtra
router.get('/', async (req, res) => {
  const { ativo } = req.query
  const where = {}

  if (ativo !== undefined) {
    if (ativo !== 'true' && ativo !== 'false') {
      return res.status(400).json({ erros: ['ativo deve ser true ou false.'] })
    }
    where.encerrado_em = ativo === 'true' ? null : { not: null }
  }

  try {
    const vinculos = await prisma.medicoPaciente.findMany({
      where,
      select: CAMPOS_VINCULO,
      orderBy: [{ vinculado_em: 'desc' }, { id: 'desc' }],
    })
    return res.json(vinculos)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar vínculos.', err.message] })
  }
})

export default router
