import { Router } from 'express'
import prisma from '../lib/prisma.js'
import { gerarHash, validarSenha } from '../lib/senha.js'

// Pré-cadastro e listagem de pessoas pelo GESTOR (controle de acesso no server.js).
// O gestor vê só nome, e-mail, perfil, status e setor; nunca dados de postura/saúde
// e nunca o hash da senha.

const router = Router()

const ROLES_CADASTRAVEIS = ['MEDICO', 'TRABALHADOR']

const CAMPOS_PUBLICOS = {
  id: true,
  nome: true,
  email: true,
  role: true,
  status: true,
  setor: { select: { id: true, nome: true } },
}

// POST /usuarios — pré-cadastra MEDICO ou TRABALHADOR com senha temporária (status PENDENTE)
router.post('/', async (req, res) => {
  const { nome, email, role, setor_id, senha_temporaria } = req.body

  // --- Validação ---
  const erros = []

  if (typeof nome !== 'string' || nome.trim() === '') {
    erros.push('nome é obrigatório.')
  }
  if (typeof email !== 'string' || email.trim() === '') {
    erros.push('email é obrigatório.')
  }
  if (!ROLES_CADASTRAVEIS.includes(role)) {
    erros.push('role deve ser MEDICO ou TRABALHADOR.')
  }
  erros.push(...validarSenha(senha_temporaria, 'senha_temporaria'))

  // D2: setor só para TRABALHADOR
  if (role === 'TRABALHADOR') {
    if (setor_id == null) {
      erros.push('setor_id é obrigatório para TRABALHADOR.')
    } else if (!Number.isInteger(setor_id)) {
      erros.push('setor_id deve ser um inteiro.')
    }
  } else if (role === 'MEDICO' && setor_id != null) {
    erros.push('MEDICO não tem setor; não envie setor_id.')
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  try {
    if (role === 'TRABALHADOR') {
      const setor = await prisma.setor.findUnique({ where: { id: setor_id } })
      if (!setor) {
        return res.status(400).json({ erros: ['Setor não encontrado.'] })
      }
    }

    const existente = await prisma.usuario.findUnique({ where: { email: email.trim().toLowerCase() } })
    if (existente) {
      return res.status(409).json({ erros: ['E-mail já cadastrado.'] })
    }

    const usuario = await prisma.usuario.create({
      data: {
        nome: nome.trim(),
        email: email.trim().toLowerCase(),
        role,
        setor_id: role === 'TRABALHADOR' ? setor_id : null,
        senha_hash: await gerarHash(senha_temporaria),
        status: 'PENDENTE',
      },
      select: CAMPOS_PUBLICOS,
    })

    return res.status(201).json(usuario)
  } catch (err) {
    // Corrida entre a checagem acima e o create: índice único do e-mail
    if (err.code === 'P2002') {
      return res.status(409).json({ erros: ['E-mail já cadastrado.'] })
    }
    return res.status(500).json({ erros: ['Erro ao cadastrar usuário.', err.message] })
  }
})

// GET /usuarios — lista MEDICO e TRABALHADOR; ?role=MEDICO|TRABALHADOR filtra.
// ?sem_vinculo=true (só com role=TRABALHADOR): trabalhadores sem vínculo ativo com médico.
router.get('/', async (req, res) => {
  const { role, sem_vinculo } = req.query

  if (role !== undefined && !ROLES_CADASTRAVEIS.includes(role)) {
    return res.status(400).json({ erros: ['role deve ser MEDICO ou TRABALHADOR.'] })
  }

  if (sem_vinculo !== undefined && (sem_vinculo !== 'true' || role !== 'TRABALHADOR')) {
    return res
      .status(400)
      .json({ erros: ['sem_vinculo=true só é aceito junto com role=TRABALHADOR.'] })
  }

  const where = { role: role ?? { in: ROLES_CADASTRAVEIS } }
  if (sem_vinculo === 'true') {
    where.vinculos_como_trabalhador = { none: { encerrado_em: null } }
  }

  try {
    const usuarios = await prisma.usuario.findMany({
      where,
      select: CAMPOS_PUBLICOS,
      orderBy: { nome: 'asc' },
    })
    return res.json(usuarios)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao listar usuários.', err.message] })
  }
})

export default router
