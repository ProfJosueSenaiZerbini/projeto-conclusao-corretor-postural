import { Router } from 'express'
import prisma from '../lib/prisma.js'
import {
  DIAS_POR_PERIODO,
  calcularScore,
  contarLeiturasNaFaixa,
  inicioDaJanela,
} from '../lib/score.js'

const router = Router()

// GET /setores/resumo?periodo=semana|mes — dados agregados por setor para o Gestor
router.get('/resumo', async (req, res) => {
  const periodo = req.query.periodo ?? 'semana'
  const dias = DIAS_POR_PERIODO[periodo]

  if (!dias) {
    return res.status(400).json({ erros: ['periodo deve ser "semana" ou "mes".'] })
  }

  const desde = inicioDaJanela(dias)

  try {
    // Setores com ao menos 1 trabalhador; para cada trabalhador, contagens
    // de leituras e eventos no período, somadas sobre todas as suas sessões.
    const setores = await prisma.setor.findMany({
      where: { usuarios: { some: { role: 'TRABALHADOR' } } },
      include: {
        usuarios: {
          where: { role: 'TRABALHADOR' },
          select: {
            id: true,
            sessoes_monitoramento: {
              select: {
                id: true,
                versao_regra: { select: { angulo_minimo: true, angulo_maximo: true } },
                _count: {
                  select: {
                    leituras: { where: { timestamp: { gte: desde } } },
                    eventos_feedback: { where: { disparado_em: { gte: desde } } },
                  },
                },
              },
            },
          },
        },
      },
    })

    const naFaixa = await contarLeiturasNaFaixa(
      setores.flatMap((s) => s.usuarios.flatMap((u) => u.sessoes_monitoramento)),
      desde,
    )

    const resumo = setores.map((setor) => {
      let participantesAtivos = 0
      let totalAlertas = 0
      const scores = []

      for (const trabalhador of setor.usuarios) {
        let leituras = 0
        let leiturasNaFaixa = 0
        let eventos = 0
        for (const sessao of trabalhador.sessoes_monitoramento) {
          leituras += sessao._count.leituras
          leiturasNaFaixa += naFaixa.get(sessao.id) ?? 0
          eventos += sessao._count.eventos_feedback
        }

        totalAlertas += eventos

        if (leituras > 0) {
          participantesAtivos++
          scores.push(calcularScore(leituras, leiturasNaFaixa))
        }
      }

      const scoreMedio =
        scores.length > 0 ? scores.reduce((soma, s) => soma + s, 0) / scores.length : null

      return {
        setor_id: setor.id,
        nome: setor.nome,
        participantes_ativos: participantesAtivos,
        total_alertas: totalAlertas,
        score_medio: scoreMedio,
      }
    })

    // Maior risco (menor score) primeiro; setores sem score por último
    resumo.sort((a, b) => {
      if (a.score_medio === null) return b.score_medio === null ? 0 : 1
      if (b.score_medio === null) return -1
      return a.score_medio - b.score_medio
    })

    return res.json(resumo)
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao gerar resumo dos setores.', err.message] })
  }
})

export default router
