import { Router } from 'express'
import jwt from 'jsonwebtoken'
import prisma from '../lib/prisma.js'
import { conferirSenha, gerarHash, validarSenha } from '../lib/senha.js'
import { POLITICA_PRIVACIDADE } from '../lib/politica.js'

const router = Router()

// Mesmo formato de resposta do login para o login e o primeiro acesso.
// O token leva { id, role, setor_id }; setor_id é null para MEDICO e GESTOR.
function respostaComToken(usuario) {
  const token = jwt.sign(
    { id: usuario.id, role: usuario.role, setor_id: usuario.setor_id },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRY },
  )

  return {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    role: usuario.role,
    setor_id: usuario.setor_id,
    token,
  }
}

// Busca o usuário e confere a senha; null se e-mail ou senha não conferem.
// E-mails são gravados em minúsculas (o Postgres compara texto com distinção de caixa).
async function autenticarCredenciais(email, senha) {
  const usuario = await prisma.usuario.findUnique({
    where: { email: String(email).trim().toLowerCase() },
  })
  if (!usuario || !(await conferirSenha(senha, usuario.senha_hash))) {
    return null
  }
  return usuario
}

// POST /auth/login
router.post('/login', async (req, res) => {
  const { email, senha } = req.body

  if (!email || !senha) {
    return res.status(400).json({ erros: ['email e senha são obrigatórios.'] })
  }

  try {
    const usuario = await autenticarCredenciais(email, senha)

    if (!usuario) {
      return res.status(401).json({ erros: ['Credenciais inválidas.'] })
    }

    if (usuario.status === 'PENDENTE') {
      return res
        .status(403)
        .json({ erros: ['Primeiro acesso pendente.'], codigo: 'PRIMEIRO_ACESSO' })
    }

    return res.json(respostaComToken(usuario))
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao autenticar.', err.message] })
  }
})

// POST /auth/primeiro-acesso — troca a senha temporária e registra o aceite da política
router.post('/primeiro-acesso', async (req, res) => {
  const { email, senha_temporaria, nova_senha, aceite } = req.body

  // --- Validação do corpo ---
  const erros = []

  if (!email) {
    erros.push('email é obrigatório.')
  }
  if (!senha_temporaria) {
    erros.push('senha_temporaria é obrigatória.')
  }
  erros.push(...validarSenha(nova_senha, 'nova_senha'))
  if (nova_senha && nova_senha === senha_temporaria) {
    erros.push('nova_senha deve ser diferente da senha temporária.')
  }
  if (aceite !== true) {
    erros.push('É necessário aceitar a Política de Privacidade.')
  }

  if (erros.length > 0) {
    return res.status(400).json({ erros })
  }

  try {
    const usuario = await autenticarCredenciais(email, senha_temporaria)

    if (!usuario) {
      return res.status(401).json({ erros: ['Credenciais inválidas.'] })
    }

    if (usuario.status !== 'PENDENTE') {
      return res.status(409).json({ erros: ['Primeiro acesso já realizado.'] })
    }

    const ativado = await prisma.usuario.update({
      where: { id: usuario.id },
      data: {
        senha_hash: await gerarHash(nova_senha),
        status: 'ATIVO',
        aceite_politica_em: new Date(),
      },
    })

    return res.json(respostaComToken(ativado))
  } catch (err) {
    return res.status(500).json({ erros: ['Erro ao concluir o primeiro acesso.', err.message] })
  }
})

// GET /auth/politica — texto da Política de Privacidade (público)
router.get('/politica', (_req, res) => {
  return res.json({ texto: POLITICA_PRIVACIDADE })
})

export default router
