import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import prisma from './lib/prisma.js'
import regrasRouter from './routes/regras.js'
import sessoesRouter from './routes/sessoes.js'
import laudosRouter from './routes/laudos.js'
import authRouter from './routes/auth.js'
import setoresRouter from './routes/setores.js'
import usuariosRouter from './routes/usuarios.js'
import vinculosRouter from './routes/vinculos.js'
import pacientesRouter from './routes/pacientes.js'
import { autenticar } from './middleware/autenticar.js'
import { exigirRole } from './middleware/exigirRole.js'

const app = express()
const PORT = process.env.PORT || 3000

// CORS_ORIGIN: domínios que podem chamar a API pelo navegador, separados por vírgula
// (ex.: https://sime.vercel.app). Vazio = nenhum; o app mobile e o proxy do Vite não precisam.
const origensPermitidas = (process.env.CORS_ORIGIN ?? '')
  .split(',')
  .map((o) => o.trim().replace(/\/$/, ''))
  .filter(Boolean)
app.use(cors({ origin: origensPermitidas }))

app.use(express.json())

app.get('/health', async (_req, res) => {
  try {
    const count = await prisma.usuario.count()
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      db: { connected: true, usuarios: count },
    })
  } catch (err) {
    res.status(500).json({
      status: 'error',
      timestamp: new Date().toISOString(),
      db: { connected: false, error: err.message },
    })
  }
})

// ── Rotas ──────────────────────────────────────────────
// Cada grupo exige autenticação em todas as suas rotas (app.use + autenticar);
// restrições de perfil por método ficam em linha antes de montar o router.

app.use('/auth', authRouter) // público: POST /auth/login, POST /auth/primeiro-acesso, GET /auth/politica

// Só leitura (GET /regras e GET /regras/:id), qualquer perfil: a regra é fixa no firmware
app.use('/regras', autenticar, regrasRouter)

app.use('/laudos', autenticar) // GESTOR não acessa /laudos (só dados agregados por setor)
app.get('/laudos', exigirRole('MEDICO', 'TRABALHADOR'))
app.get('/laudos/:id', exigirRole('MEDICO', 'TRABALHADOR'))
app.post('/laudos', exigirRole('MEDICO'))
app.patch('/laudos/:id/assinar', exigirRole('MEDICO'))
app.use('/laudos', laudosRouter)

app.use('/sessoes', autenticar)
app.get('/sessoes', exigirRole('TRABALHADOR', 'MEDICO'))
app.post('/sessoes', exigirRole('TRABALHADOR'))
app.post('/sessoes/:id/lotes', exigirRole('TRABALHADOR'))
app.patch('/sessoes/:id/encerrar', exigirRole('TRABALHADOR'))
app.use('/sessoes', sessoesRouter)

app.use('/setores', autenticar, exigirRole('GESTOR'), setoresRouter)

app.use('/usuarios', autenticar, exigirRole('GESTOR'), usuariosRouter)

app.use('/vinculos', autenticar, exigirRole('GESTOR'), vinculosRouter)

app.use('/pacientes', autenticar, exigirRole('MEDICO'), pacientesRouter)

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`SIME API rodando em http://localhost:${PORT}`)
  })
}

export default app
