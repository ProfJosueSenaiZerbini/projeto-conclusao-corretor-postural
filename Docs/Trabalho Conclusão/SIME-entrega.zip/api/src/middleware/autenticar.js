import jwt from 'jsonwebtoken'

// Exige header Authorization: Bearer <token> válido e popula req.usuario
export function autenticar(req, res, next) {
  const [tipo, token] = (req.headers.authorization ?? '').split(' ')

  if (tipo !== 'Bearer' || !token) {
    return res.status(401).json({ erros: ['Token inválido ou expirado.'] })
  }

  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET)
    return next()
  } catch {
    return res.status(401).json({ erros: ['Token inválido ou expirado.'] })
  }
}

export default autenticar
