// Permite a requisição apenas se req.usuario.role estiver entre os roles informados.
// Deve ser usado depois de autenticar.
export function exigirRole(...roles) {
  return (req, res, next) => {
    if (!req.usuario || !roles.includes(req.usuario.role)) {
      return res.status(403).json({ erros: ['Acesso não permitido para este perfil.'] })
    }
    return next()
  }
}

export default exigirRole
